# Import all required packages
import pandas as pd
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.preprocessing import LabelBinarizer

# Load the training and test datasets
train_data = pd.read_csv('../../../data/cmc/cmc_train.csv')
test_data = pd.read_csv('../../../data/cmc/cmc_test.csv')

# Perform feature processing
# Define the columns to be scaled and encoded
scale_cols = ['Number_of_children_ever_born', 'Wifes_education', 'Standard-of-living_index', 'Husbands_occupation', 'Husbands_education', 'Wifes_age']
encode_cols = ['Wifes_education', 'Standard-of-living_index', 'Husbands_occupation', 'Husbands_education', 'Media_exposure', 'Wifes_religion', 'Wifes_now_working%3F']

# Define the preprocessing steps
preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), scale_cols),
        ('cat', OneHotEncoder(), encode_cols)])

# Define the target variable
target = 'Contraceptive_method_used'

# Define the classifier
classifier = RandomForestClassifier(n_jobs=-1)

# Combine preprocessing and classifier into a pipeline
pipeline = Pipeline(steps=[('preprocessor', preprocessor),
                           ('classifier', classifier)])

# Train the model
X_train = train_data.drop(target, axis=1)
y_train = train_data[target]
pipeline.fit(X_train, y_train)

# Evaluate the model
X_test = test_data.drop(target, axis=1)
y_test = test_data[target]

# Predict the target for the training and test data
y_train_pred = pipeline.predict(X_train)
y_test_pred = pipeline.predict(X_test)

# Calculate the accuracy and log loss for the training data
Train_Accuracy = accuracy_score(y_train, y_train_pred)

# Binarize the output
lb = LabelBinarizer()
y_train = lb.fit_transform(y_train)
y_train_pred = lb.transform(y_train_pred)
Train_Log_loss = log_loss(y_train, y_train_pred)

# Calculate the accuracy and log loss for the test data
Test_Accuracy = accuracy_score(y_test, y_test_pred)

# Binarize the output
y_test = lb.transform(y_test)
y_test_pred = lb.transform(y_test_pred)
Test_Log_loss = log_loss(y_test, y_test_pred)

# Print the results
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_Log_loss:{Train_Log_loss}") 
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_Log_loss:{Test_Log_loss}")