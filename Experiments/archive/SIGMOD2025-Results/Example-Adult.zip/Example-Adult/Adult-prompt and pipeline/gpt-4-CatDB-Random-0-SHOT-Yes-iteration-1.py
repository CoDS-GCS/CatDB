# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.model_selection import train_test_split

train_data = pd.read_csv('../../../data/Adult/Adult_train.csv')
test_data = pd.read_csv('../../../data/Adult/Adult_test.csv')

for column in train_data.columns:
    train_data[column].fillna(train_data[column].mode()[0], inplace=True)
for column in test_data.columns:
    test_data[column].fillna(test_data[column].mode()[0], inplace=True)

encoder = OneHotEncoder()
train_encoded = pd.DataFrame(encoder.fit_transform(train_data[['native-country', 'race', 'relationship', 'sex', 'workclass', 'education-num', 'education', 'occupation', 'marital-status']]).toarray())
test_encoded = pd.DataFrame(encoder.transform(test_data[['native-country', 'race', 'relationship', 'sex', 'workclass', 'education-num', 'education', 'occupation', 'marital-status']]).toarray())

train_data = pd.concat([train_data, train_encoded], axis=1)
test_data = pd.concat([test_data, test_encoded], axis=1)

train_data.drop(columns=['native-country', 'race', 'relationship', 'sex', 'workclass', 'education-num', 'education', 'occupation', 'marital-status'], inplace=True)
test_data.drop(columns=['native-country', 'race', 'relationship', 'sex', 'workclass', 'education-num', 'education', 'occupation', 'marital-status'], inplace=True)

X_train = train_data.drop(columns=['class'])
y_train = train_data['class']
X_test = test_data.drop(columns=['class'])
y_test = test_data['class']

X_train.columns = X_train.columns.astype(str)
X_test.columns = X_test.columns.astype(str)

clf = RandomForestClassifier(max_leaf_nodes=500)
clf.fit(X_train, y_train)

y_train_pred = clf.predict(X_train)
y_test_pred = clf.predict(X_test)

Train_Accuracy = accuracy_score(y_train, y_train_pred)
Test_Accuracy = accuracy_score(y_test, y_test_pred)

Train_F1_score = f1_score(y_train, y_train_pred, average='weighted')
Test_F1_score = f1_score(y_test, y_test_pred, average='weighted')

Train_AUC = roc_auc_score(y_train, clf.predict_proba(X_train)[:, 1])
Test_AUC = roc_auc_score(y_test, clf.predict_proba(X_test)[:, 1])

print(f"Train_AUC:{Train_AUC}")
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_F1_score:{Train_F1_score}")
print(f"Test_AUC:{Test_AUC}")
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_F1_score:{Test_F1_score}") 
# ```