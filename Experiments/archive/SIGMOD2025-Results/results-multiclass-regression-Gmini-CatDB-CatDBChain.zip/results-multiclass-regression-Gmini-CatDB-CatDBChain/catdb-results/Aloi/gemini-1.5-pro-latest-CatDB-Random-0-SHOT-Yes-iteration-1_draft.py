# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
import numpy as np

train_data = pd.read_csv("../../../data/Aloi/Aloi_train.csv")
test_data = pd.read_csv("../../../data/Aloi/Aloi_test.csv")


def augment_data(df, n_samples):
    """
    Augments the dataset by creating synthetic samples.

    Args:
        df: The original DataFrame.
        n_samples: The number of synthetic samples to generate.

    Returns:
        The augmented DataFrame.
    """
    augmented_df = df.sample(n=n_samples, replace=True)
    for col in augmented_df.columns:
        if augmented_df[col].dtype == 'int':
            augmented_df[col] += np.random.randint(-1, 2, size=n_samples)
    return pd.concat([df, augmented_df])

train_data = augment_data(train_data, n_samples=5000)

ohe = OneHotEncoder(handle_unknown='ignore')
ohe.fit(train_data[['1', '4']])
train_encoded = pd.DataFrame(ohe.transform(train_data[['1', '4']]).toarray())
test_encoded = pd.DataFrame(ohe.transform(test_data[['1', '4']]).toarray())
train_data = train_data.join(train_encoded, lsuffix='_original')
test_data = test_data.join(test_encoded, lsuffix='_original')

train_data.drop(columns=['1', '4'], inplace=True)
test_data.drop(columns=['1', '4'], inplace=True)


X_train = train_data.drop(columns=['target'])
y_train = train_data['target']
X_test = test_data.drop(columns=['target'])
y_test = test_data['target']

X_train.columns = X_train.columns.astype(str)
X_test.columns = X_test.columns.astype(str)

trn = RandomForestRegressor(max_leaf_nodes=500)
trn.fit(X_train, y_train)

Train_R_Squared = r2_score(y_train, trn.predict(X_train))
Test_R_Squared = r2_score(y_test, trn.predict(X_test))

Train_RMSE = mean_squared_error(y_train, trn.predict(X_train), squared=False)
Test_RMSE = mean_squared_error(y_test, trn.predict(X_test), squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")
# ```end