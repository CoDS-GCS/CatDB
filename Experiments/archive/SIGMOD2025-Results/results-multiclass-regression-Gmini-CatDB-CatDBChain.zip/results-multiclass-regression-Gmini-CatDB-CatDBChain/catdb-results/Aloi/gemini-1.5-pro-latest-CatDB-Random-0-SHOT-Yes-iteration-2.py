# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error

train_data = pd.read_csv("../../../data/Aloi/Aloi_train.csv")
test_data = pd.read_csv("../../../data/Aloi/Aloi_test.csv")



ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
feature_cols = ['1', '4']
ohe.fit(train_data[feature_cols])
train_ohe = pd.DataFrame(ohe.transform(train_data[feature_cols]))
train_ohe = train_ohe.add_prefix('ohe_')
train_data = pd.concat([train_data, train_ohe], axis=1)
test_ohe = pd.DataFrame(ohe.transform(test_data[feature_cols]))
test_ohe = test_ohe.add_prefix('ohe_')
test_data = pd.concat([test_data, test_ohe], axis=1)


train_data.drop(columns=['1'], inplace=True)
test_data.drop(columns=['1'], inplace=True)
train_data.drop(columns=['4'], inplace=True)
test_data.drop(columns=['4'], inplace=True)

X_train = train_data.drop('target', axis=1)
y_train = train_data['target']
X_test = test_data.drop('target', axis=1)
y_test = test_data['target']

trn = RandomForestRegressor(max_leaf_nodes=500, n_jobs=-1)
trn.fit(X_train, y_train)

Train_R_Squared= r2_score(y_train, trn.predict(X_train))
Train_RMSE= mean_squared_error(y_train, trn.predict(X_train), squared=False)
print(f"Train_R_Squared:{Train_R_Squared}")   
print(f"Train_RMSE:{Train_RMSE}") 
Test_R_Squared= r2_score(y_test, trn.predict(X_test))
Test_RMSE= mean_squared_error(y_test, trn.predict(X_test), squared=False)
print(f"Test_R_Squared:{Test_R_Squared}")   
print(f"Test_RMSE:{Test_RMSE}") 
# ```end