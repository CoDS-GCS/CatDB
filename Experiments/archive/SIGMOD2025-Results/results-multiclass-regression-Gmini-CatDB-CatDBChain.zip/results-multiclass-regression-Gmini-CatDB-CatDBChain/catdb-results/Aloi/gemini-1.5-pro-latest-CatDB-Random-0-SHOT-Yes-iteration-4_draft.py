# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error

train_data = pd.read_csv("../../../data/Aloi/Aloi_train.csv")
test_data = pd.read_csv("../../../data/Aloi/Aloi_test.csv")



ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
train_data_ohe = pd.DataFrame(ohe.fit_transform(train_data[['1', '4']]))
test_data_ohe = pd.DataFrame(ohe.transform(test_data[['1', '4']]))
train_data_ohe.columns = [f'ohe_{str(col)}' for col in train_data_ohe.columns]
test_data_ohe.columns = [f'ohe_{str(col)}' for col in test_data_ohe.columns]
train_data = pd.concat([train_data, train_data_ohe], axis=1)
test_data = pd.concat([test_data, test_data_ohe], axis=1)

train_data.drop(columns=['1'], inplace=True)
train_data.drop(columns=['4'], inplace=True)
test_data.drop(columns=['1'], inplace=True)
test_data.drop(columns=['4'], inplace=True)

X_train = train_data.drop(columns=['target'])
y_train = train_data['target']
X_test = test_data.drop(columns=['target'])
y_test = test_data['target']

trn = RandomForestRegressor(max_leaf_nodes=500)
trn.fit(X_train, y_train)

Train_R_Squared = r2_score(y_train, trn.predict(X_train))
Test_R_Squared = r2_score(y_test, trn.predict(X_test))
Train_RMSE = mean_squared_error(y_train, trn.predict(X_train), squared=False)
Test_RMSE = mean_squared_error(y_test, trn.predict(X_test), squared=False)
print(f"Train_R_Squared:{Train_R_Squared}")   
print(f"Train_RMSE:{Train_RMSE}") 
print(f"Test_R_Squared:{Test_R_Squared}")   
print(f"Test_RMSE:{Test_RMSE}") 
# ```end