# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error

train_data = pd.read_csv("../../../data/Aloi/Aloi_train.csv")
test_data = pd.read_csv("../../../data/Aloi/Aloi_test.csv")



ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
combined_data = pd.concat([train_data, test_data], axis=0)
for column in [1, 4]:
    ohe.fit(combined_data[[str(column)]])
    temp_train = ohe.transform(train_data[[str(column)]])
    temp_test = ohe.transform(test_data[[str(column)]])
    temp_train_df = pd.DataFrame(temp_train, columns=[f"col_{column}_{i}" for i in range(temp_train.shape[1])])
    temp_test_df = pd.DataFrame(temp_test, columns=[f"col_{column}_{i}" for i in range(temp_test.shape[1])])
    train_data = pd.concat([train_data, temp_train_df], axis=1)
    test_data = pd.concat([test_data, temp_test_df], axis=1)

X_train = train_data.drop(columns=['target'])
y_train = train_data['target']
X_test = test_data.drop(columns=['target'])
y_test = test_data['target']


trn = RandomForestRegressor(max_leaf_nodes=500)
trn.fit(X_train, y_train)

Train_R_Squared = r2_score(y_train, trn.predict(X_train))
Train_RMSE = mean_squared_error(y_train, trn.predict(X_train), squared=False)
Test_R_Squared = r2_score(y_test, trn.predict(X_test))
Test_RMSE = mean_squared_error(y_test, trn.predict(X_test), squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")
# ```end