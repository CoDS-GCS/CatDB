# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
import numpy as np

train_data = pd.read_csv("../../../data/Aloi/Aloi_train.csv", header=None)
test_data = pd.read_csv("../../../data/Aloi/Aloi_test.csv", header=None)

for df in [train_data, test_data]:
    for col in df.columns[:-1]:
        df[col] += np.random.normal(0, 0.1 * df[col].std(), len(df))

combined_data = pd.concat([train_data, test_data], axis=0, ignore_index=True)

ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=True)
ohe_features = ohe.fit_transform(combined_data[[1, 4]])
ohe_df = pd.DataFrame.sparse.from_spmatrix(ohe_features)
combined_data = pd.concat([combined_data, ohe_df], axis=1)

train_data = combined_data.iloc[:len(train_data)]
test_data = combined_data.iloc[len(train_data):]

X_train = train_data.drop(columns=[train_data.columns[-1]], inplace=False)
y_train = train_data[train_data.columns[-1]]
X_test = test_data.drop(columns=[test_data.columns[-1]], inplace=False)
y_test = test_data[test_data.columns[-1]]

trn = RandomForestRegressor(max_leaf_nodes=500)
trn.fit(X_train, y_train)

Train_R_Squared = r2_score(y_train, trn.predict(X_train))
Train_RMSE = mean_squared_error(y_train, trn.predict(X_train), squared=False)
print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")

Test_R_Squared = r2_score(y_test, trn.predict(X_test))
Test_RMSE = mean_squared_error(y_test, trn.predict(X_test), squared=False)
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")
# ```end