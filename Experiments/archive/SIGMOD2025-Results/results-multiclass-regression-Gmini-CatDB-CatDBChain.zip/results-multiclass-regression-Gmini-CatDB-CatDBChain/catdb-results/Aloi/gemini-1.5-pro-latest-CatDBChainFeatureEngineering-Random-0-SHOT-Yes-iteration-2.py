# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

categorical_features = [1, 4]

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(), categorical_features)
    ],
    remainder='passthrough'  # Keep other columns unchanged
)

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    # Add other pipeline steps here, e.g., feature scaling, model training
])
# ```end