# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

def feature_engineering_pipeline(data):
    # Select the target variable
    y = data['target']

    # Select features and drop irrelevant columns
    features_to_drop = ['target']
    X = data.drop(columns=features_to_drop)

    # Define categorical features for one-hot encoding
    categorical_features = [1, 4]

    # Create a column transformer for preprocessing
    preprocessor = ColumnTransformer(
        transformers=[
            ('onehot', OneHotEncoder(handle_unknown='ignore'), categorical_features),
        ],
        remainder='passthrough'  # Keep remaining columns as they are
    )
    return X, y, preprocessor
# ```end