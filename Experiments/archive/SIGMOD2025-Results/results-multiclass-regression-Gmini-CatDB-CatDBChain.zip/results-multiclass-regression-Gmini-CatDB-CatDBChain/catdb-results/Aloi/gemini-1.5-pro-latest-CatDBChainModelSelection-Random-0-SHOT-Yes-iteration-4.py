# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error


categorical_features = ['1', '4'] 
numerical_features = ['71', '5', '83', '24', '34', '109', '39', '100', '104', '29', '85', '36', '103', '19', '112', '35', '98', '50', '67', '101', '113', '60', '63', '15', '81', '64', '99', '23', '87', '40', '28', '92', '46', '4', '18', '8', '123', '114', '80', '27', '120', '49', '38', '94', '22', '126', '26', '33', '76', '116', '17', '79', '11', '61', '37', '10', '59', '96', '127', '53', '110', '82', '51', '62', '9', '124', '48', '89', '108', '21', '95', '65', '41', '91', '25', '66', '32', '58', '121', '45', '118', '107', '73', '111', '84', '90', '125', '57', '102', '93', '72', '6', '12', '75', '117', '44', '54', '55', '3', '74', '31', '0', '13', '20', '43', '52', '97', '88', '69', '47', '2', '122', '7', '70', '105', '115', '78', '16', '30', '119', '77', '86', '56', '68', '42', '106', '14']

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median'))
])

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ])

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('regressor', RandomForestRegressor(n_jobs=-1, max_leaf_nodes=500))
])

# ```end