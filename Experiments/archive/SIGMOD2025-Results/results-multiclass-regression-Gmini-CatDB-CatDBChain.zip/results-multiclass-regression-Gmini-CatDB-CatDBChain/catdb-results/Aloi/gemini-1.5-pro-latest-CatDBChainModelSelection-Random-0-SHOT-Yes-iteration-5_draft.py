# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
from multiprocessing import Pool

categorical_features = [str(i) for i in range(128)]
numerical_features = []

target = 'target'

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), categorical_features)
    ],
    remainder='passthrough'
)

def process_chunk(chunk):
    # Apply preprocessing pipeline to the chunk
    X_processed = preprocessor.fit_transform(chunk)
    return X_processed

model = RandomForestRegressor(max_leaf_nodes=500, random_state=42)

def main():
    # Load the dataset (replace 'dataset.csv' with the actual file name)
    df = pd.read_csv('dataset.csv', header=None)

    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(
        df.drop(columns=df.columns[-1], axis=1), df.iloc[:, -1], test_size=0.2, random_state=42
    )
    
    # Create a multiprocessing pool
    with Pool(processes=4) as pool:
        # Split the training data into chunks
        chunk_size = len(X_train) // 4
        X_train_chunks = [X_train[i:i + chunk_size] for i in range(0, len(X_train), chunk_size)]

        # Process the chunks in parallel
        results = pool.map(process_chunk, X_train_chunks)

        # Combine the processed chunks
        X_train_processed = pd.concat(results)
    # Fit the model on the training data
    model.fit(X_train_processed, y_train)

    # Make predictions on the training and testing data
    y_train_pred = model.predict(X_train_processed)
    y_test_pred = model.predict(preprocessor.transform(X_test))

    # Calculate evaluation metrics
    Train_R_Squared = r2_score(y_train, y_train_pred)
    Train_RMSE = mean_squared_error(y_train, y_train_pred, squared=False)
    Test_R_Squared = r2_score(y_test, y_test_pred)
    Test_RMSE = mean_squared_error(y_test, y_test_pred, squared=False)

    # Print the evaluation results
    print(f"Train_R_Squared:{Train_R_Squared}")
    print(f"Train_RMSE:{Train_RMSE}")
    print(f"Test_R_Squared:{Test_R_Squared}")
    print(f"Test_RMSE:{Test_RMSE}")

main()
# ```end