# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
import numpy as np
from joblib import Parallel, delayed

categorical_features = [1, 4]
numerical_features = [col for col in range(128) if col not in categorical_features and col != 'target']

def process_data(data):
    # Split data into features and target
    X = data.drop('target', axis=1)
    y = data['target']

    # Split data into train and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Define transformers
    numeric_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])

    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore'))
    ])

    # Combine transformers using ColumnTransformer
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, numerical_features),
            ('cat', categorical_transformer, categorical_features)
        ])

    # Create the final pipeline
    pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('classifier', RandomForestRegressor(n_jobs=-1, max_leaf_nodes=500))
    ])

    # Fit the pipeline to the training data
    pipeline.fit(X_train, y_train)

    # Make predictions
    y_train_pred = pipeline.predict(X_train)
    y_test_pred = pipeline.predict(X_test)

    # Evaluate the model
    Train_R_Squared = r2_score(y_train, y_train_pred)
    Train_RMSE = mean_squared_error(y_train, y_train_pred, squared=False)
    Test_R_Squared = r2_score(y_test, y_test_pred)
    Test_RMSE = mean_squared_error(y_test, y_test_pred, squared=False)

    # Report evaluation
    print(f"Train_R_Squared:{Train_R_Squared}")   
    print(f"Train_RMSE:{Train_RMSE}") 
    print(f"Test_R_Squared:{Test_R_Squared}")   
    print(f"Test_RMSE:{Test_RMSE}") 

# ```end