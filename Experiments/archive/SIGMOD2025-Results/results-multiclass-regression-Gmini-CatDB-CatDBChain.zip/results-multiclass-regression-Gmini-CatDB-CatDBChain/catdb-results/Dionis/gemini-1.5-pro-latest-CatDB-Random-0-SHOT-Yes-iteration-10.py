# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.preprocessing import OneHotEncoder

train_data = pd.read_csv("../../../data/Dionis/Dionis_train.csv")
test_data = pd.read_csv("../../../data/Dionis/Dionis_test.csv")



ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
combined_data = pd.concat([train_data, test_data], axis=0, ignore_index=True)
ohe.fit(combined_data[['V53']])
feature_array = ohe.transform(combined_data[['V53']])
feature_labels = [f"V53_{cls}" for cls in ohe.categories_[0]]
features = pd.DataFrame(feature_array, columns=feature_labels)
combined_data = pd.concat([combined_data, features], axis=1)
train_data = combined_data.iloc[:len(train_data)]
test_data = combined_data.iloc[len(train_data):]


train_data.drop(columns=['V53'], inplace=True)
test_data.drop(columns=['V53'], inplace=True)

X_train = train_data.drop(columns=['class'])
y_train = train_data['class']
X_test = test_data.drop(columns=['class'])
y_test = test_data['class']

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

trn = LinearRegression()
trn.fit(X_train, y_train)

Train_R_Squared = r2_score(y_train, trn.predict(X_train))
Test_R_Squared = r2_score(y_test, trn.predict(X_test))

Train_RMSE = mean_squared_error(y_train, trn.predict(X_train), squared=False)
Test_RMSE = mean_squared_error(y_test, trn.predict(X_test), squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")   
print(f"Train_RMSE:{Train_RMSE}") 
print(f"Test_R_Squared:{Test_R_Squared}")   
print(f"Test_RMSE:{Test_RMSE}") 
# ```end