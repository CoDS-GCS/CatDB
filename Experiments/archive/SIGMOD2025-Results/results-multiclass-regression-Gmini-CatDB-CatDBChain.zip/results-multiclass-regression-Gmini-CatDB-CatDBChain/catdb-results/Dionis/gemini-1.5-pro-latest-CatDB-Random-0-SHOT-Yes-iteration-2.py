# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.preprocessing import OneHotEncoder

train_data = pd.read_csv("../../../data/Dionis/Dionis_train.csv")
test_data = pd.read_csv("../../../data/Dionis/Dionis_test.csv")



ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
combined_data = pd.concat([train_data, test_data], axis=0)
encoded_features = ohe.fit_transform(combined_data[['V53']])
encoded_df = pd.DataFrame(encoded_features, columns=[f"V53_{i}" for i in range(encoded_features.shape[1])])
train_data = pd.concat([train_data, encoded_df.iloc[:len(train_data)]], axis=1)
test_data = pd.concat([test_data, encoded_df.iloc[len(train_data):].reset_index(drop=True)], axis=1)
train_data.drop(columns=['V53'], inplace=True)
test_data.drop(columns=['V53'], inplace=True)



trn = LinearRegression()

trn.fit(train_data.drop(columns=['class']), train_data['class'])

train_predictions = trn.predict(train_data.drop(columns=['class']))
test_predictions = trn.predict(test_data.drop(columns=['class']))

Train_R_Squared = r2_score(train_data['class'], train_predictions)
Test_R_Squared = r2_score(test_data['class'], test_predictions)

Train_RMSE = mean_squared_error(train_data['class'], train_predictions, squared=False)
Test_RMSE = mean_squared_error(test_data['class'], test_predictions, squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")
# ```end