# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.preprocessing import OneHotEncoder

train_data = pd.read_csv("../../../data/Dionis/Dionis_train.csv")
test_data = pd.read_csv("../../../data/Dionis/Dionis_test.csv")

train_data.fillna(train_data.mean(), inplace=True)
test_data.fillna(test_data.mean(), inplace=True)

from imblearn.over_sampling import SMOTE
smote = SMOTE(random_state=42)
X_train_resampled, y_train_resampled = smote.fit_resample(train_data.drop('class', axis=1), train_data['class'])
train_data = pd.concat([X_train_resampled, y_train_resampled], axis=1)

encoder = OneHotEncoder(handle_unknown='ignore')
encoder.fit(pd.concat([train_data[['V53']], test_data[['V53']]], axis=0))
train_encoded = pd.DataFrame(encoder.transform(train_data[['V53']]).toarray(), columns=encoder.get_feature_names_out(['V53']))
test_encoded = pd.DataFrame(encoder.transform(test_data[['V53']]).toarray(), columns=encoder.get_feature_names_out(['V53']))
train_data = train_data.drop('V53', axis=1).reset_index(drop=True).join(train_encoded)
test_data = test_data.drop('V53', axis=1).reset_index(drop=True).join(test_encoded)

train_data['V8_divided_by_V2'] = train_data['V8'] / (train_data['V2'] + 1e-6)
test_data['V8_divided_by_V2'] = test_data['V8'] / (test_data['V2'] + 1e-6)
train_data['V32_plus_V29'] = train_data['V32'] + train_data['V29']
test_data['V32_plus_V29'] = test_data['V32'] + test_data['V29']

train_data.drop(columns=['V2'], inplace=True)
test_data.drop(columns=['V2'], inplace=True)

X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

trn = LinearRegression() 

trn.fit(X_train, y_train)

y_pred_train = trn.predict(X_train)
y_pred_test = trn.predict(X_test)

Train_R_Squared = r2_score(y_train, y_pred_train)
Test_R_Squared = r2_score(y_test, y_pred_test)

Train_RMSE = mean_squared_error(y_train, y_pred_train, squared=False)
Test_RMSE = mean_squared_error(y_test, y_pred_test, squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")   
print(f"Train_RMSE:{Train_RMSE}") 
print(f"Test_R_Squared:{Test_R_Squared}")   
print(f"Test_RMSE:{Test_RMSE}") 
# ```end