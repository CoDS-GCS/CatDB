# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.preprocessing import OneHotEncoder
import numpy as np

train_data = pd.read_csv("../../../data/Dionis/Dionis_train.csv")
test_data = pd.read_csv("../../../data/Dionis/Dionis_test.csv")



encoder = OneHotEncoder(handle_unknown='ignore')
encoder_df = pd.DataFrame(encoder.fit_transform(pd.concat([train_data[['V53']], test_data[['V53']]])).toarray())
train_data = train_data.join(encoder_df.iloc[:len(train_data)])
test_data = test_data.join(encoder_df.iloc[len(train_data):].reset_index(drop=True))
train_data = train_data.drop(columns=['V53'])
test_data = test_data.drop(columns=['V53'])

train_data['V8_squared'] = train_data['V8'] ** 2
test_data['V8_squared'] = test_data['V8'] ** 2
train_data['V2_transformed'] = np.log1p(train_data['V2'] + 1)
test_data['V2_transformed'] = np.log1p(test_data['V2'] + 1)

train_data.drop(columns=['V3'], inplace=True)
test_data.drop(columns=['V3'], inplace=True)

X_train = train_data.drop(columns=['class'])
y_train = train_data['class']
X_test = test_data.drop(columns=['class'])
y_test = test_data['class']

X_train.columns = X_train.columns.astype(str)
X_test.columns = X_test.columns.astype(str)

for col in X_train.columns:
    if np.isinf(X_train[col]).any():
        # Replace infinite values with NaN
        X_train[col].replace([np.inf, -np.inf], np.nan, inplace=True)
        # Impute NaN values with the median of the column
        X_train[col] = X_train[col].fillna(X_train[col].median())

for col in X_test.columns:
    if np.isinf(X_test[col]).any():
        # Replace infinite values with NaN
        X_test[col].replace([np.inf, -np.inf], np.nan, inplace=True)
        # Impute NaN values with the median of the column
        X_test[col] = X_test[col].fillna(X_test[col].median())

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

trn = RandomForestRegressor(max_leaf_nodes=500, random_state=42)
trn.fit(X_train, y_train)

y_train_pred = trn.predict(X_train)
y_test_pred = trn.predict(X_test)
Train_R_Squared = r2_score(y_train, y_train_pred)
Test_R_Squared = r2_score(y_test, y_test_pred)
Train_RMSE = mean_squared_error(y_train, y_train_pred, squared=False)
Test_RMSE = mean_squared_error(y_test, y_test_pred, squared=False)
print(f"Train_R_Squared:{Train_R_Squared}")   
print(f"Train_RMSE:{Train_RMSE}") 
print(f"Test_R_Squared:{Test_R_Squared}")   
print(f"Test_RMSE:{Test_RMSE}") 
# ```end