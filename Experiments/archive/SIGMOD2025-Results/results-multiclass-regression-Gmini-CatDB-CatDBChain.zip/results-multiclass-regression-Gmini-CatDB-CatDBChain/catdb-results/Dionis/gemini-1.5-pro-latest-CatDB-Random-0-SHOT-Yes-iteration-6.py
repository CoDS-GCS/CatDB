# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer

train_data = pd.read_csv("../../../data/Dionis/Dionis_train.csv")
test_data = pd.read_csv("../../../data/Dionis/Dionis_test.csv")

combined_data = pd.concat([train_data, test_data])



ohe = OneHotEncoder(handle_unknown='ignore')
ohe_df = pd.DataFrame(ohe.fit_transform(combined_data[['V53']]).toarray())
ohe_df = ohe_df.add_prefix('V53_')
combined_data = combined_data.join(ohe_df)
combined_data.drop(columns=['V53'], inplace=True)


combined_data['V8_divided_by_V2'] = combined_data.apply(lambda row: row['V8'] / row['V2'] if row['V2'] != 0 else 0, axis=1)
train_data = combined_data[:len(train_data)]
test_data = combined_data[len(train_data):]

X_train = train_data.drop(columns=['class'])
y_train = train_data['class']
X_test = test_data.drop(columns=['class'])
y_test = test_data['class']

imputer = SimpleImputer(strategy='mean')
X_train = imputer.fit_transform(X_train)
X_test = imputer.transform(X_test)

trn = LinearRegression()
trn.fit(X_train, y_train)
Train_R_Squared = r2_score(y_train, trn.predict(X_train))
Train_RMSE = mean_squared_error(y_train, trn.predict(X_train), squared=False)
Test_R_Squared = r2_score(y_test, trn.predict(X_test))
Test_RMSE = mean_squared_error(y_test, trn.predict(X_test), squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")   
print(f"Train_RMSE:{Train_RMSE}") 
print(f"Test_R_Squared:{Test_R_Squared}")   
print(f"Test_RMSE:{Test_RMSE}") 
# ```end