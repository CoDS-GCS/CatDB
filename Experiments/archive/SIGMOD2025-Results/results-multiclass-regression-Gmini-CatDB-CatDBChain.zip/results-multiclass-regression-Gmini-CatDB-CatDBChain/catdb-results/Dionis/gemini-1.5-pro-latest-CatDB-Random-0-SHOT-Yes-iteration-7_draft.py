# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.preprocessing import OneHotEncoder

train_data = pd.read_csv("../../../data/Dionis/Dionis_train.csv")
test_data = pd.read_csv("../../../data/Dionis/Dionis_test.csv")

combined_data = pd.concat([train_data, test_data], axis=0, ignore_index=True)



ohe = OneHotEncoder(handle_unknown='ignore')
ohe.fit(combined_data[['V53']])
encoded_features = ohe.transform(combined_data[['V53']]).toarray()
encoded_df = pd.DataFrame(encoded_features, columns=[f"V53_{i}" for i in range(encoded_features.shape[1])])
combined_data = pd.concat([combined_data, encoded_df], axis=1)
combined_data.drop(columns=['V53'], inplace=True)

train_data = combined_data[:len(train_data)]
test_data = combined_data[len(train_data):]

X_train = train_data.drop(columns=['class'])
y_train = train_data['class']
X_test = test_data.drop(columns=['class'])
y_test = test_data['class']


trn = LinearRegression()

trn.fit(X_train, y_train)

Train_R_Squared = r2_score(y_train, trn.predict(X_train))
Test_R_Squared = r2_score(y_test, trn.predict(X_test))

Train_RMSE = mean_squared_error(y_train, trn.predict(X_train), squared=False)
Test_RMSE = mean_squared_error(y_test, trn.predict(X_test), squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")
# ```end