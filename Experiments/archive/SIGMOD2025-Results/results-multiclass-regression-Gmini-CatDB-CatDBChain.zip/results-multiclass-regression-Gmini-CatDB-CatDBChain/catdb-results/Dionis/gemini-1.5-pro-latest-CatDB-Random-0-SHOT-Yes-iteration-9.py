# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error

train_data = pd.read_csv("../../../data/Dionis/Dionis_train.csv")
test_data = pd.read_csv("../../../data/Dionis/Dionis_test.csv")

train_data['V8_divided_by_V2'] = train_data['V8'] / train_data['V2']
test_data['V8_divided_by_V2'] = test_data['V8'] / test_data['V2']
train_data.replace([float('inf'), float('-inf')], float('NaN'), inplace=True)
test_data.replace([float('inf'), float('-inf')], float('NaN'), inplace=True)
train_data['V8_divided_by_V2'].fillna(train_data['V8_divided_by_V2'].mean(), inplace=True)
test_data['V8_divided_by_V2'].fillna(test_data['V8_divided_by_V2'].mean(), inplace=True)

train_data['V32_plus_V29'] = train_data['V32'] + train_data['V29']
test_data['V32_plus_V29'] = test_data['V32'] + test_data['V29']

train_data['V36_multiplied_by_V16'] = train_data['V36'] * train_data['V16']
test_data['V36_multiplied_by_V16'] = test_data['V36'] * test_data['V16']

train_data.drop(columns=['V53'], inplace=True)
test_data.drop(columns=['V53'], inplace=True)

trn = RandomForestRegressor(max_leaf_nodes=500) 

combined_data = pd.concat([train_data, test_data], axis=0)
for column in combined_data.columns:
    if train_data[column].dtype == 'object':
        # Handle unseen values in categorical features
        train_data[column] = train_data[column].fillna(combined_data[column].mode()[0])
        test_data[column] = test_data[column].fillna(combined_data[column].mode()[0])
    else:
        # Handle unseen values in numerical features
        train_data[column] = train_data[column].fillna(combined_data[column].mean())
        test_data[column] = test_data[column].fillna(combined_data[column].mean())

X_train = train_data.drop("class", axis=1)
y_train = train_data["class"]
X_test = test_data.drop("class", axis=1)
y_test = test_data["class"]

trn.fit(X_train, y_train)

y_pred_train = trn.predict(X_train)
y_pred_test = trn.predict(X_test)

Train_R_Squared = r2_score(y_train, y_pred_train)
Test_R_Squared = r2_score(y_test, y_pred_test)

Train_RMSE = mean_squared_error(y_train, y_pred_train, squared=False)
Test_RMSE = mean_squared_error(y_test, y_pred_test, squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")   
print(f"Train_RMSE:{Train_RMSE}") 
print(f"Test_R_Squared:{Test_R_Squared}")   
print(f"Test_RMSE:{Test_RMSE}") 
# ```end