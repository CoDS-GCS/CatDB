# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
import multiprocessing
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error

categorical_features = ['V53']
numerical_features = ['V8', 'V2', 'V32', 'V29', 'V36', 'V16', 'V46', 'V10', 'V21', 'V9', 'V30', 'V60', 'V23', 'V45', 'V5', 'V34', 'V48', 'V26', 'V56', 'V38', 'V18', 'V15', 'V50', 'V22', 'V20', 'V43', 'V6', 'V24', 'V19', 'V59', 'V41', 'V3', 'V58', 'V28', 'V52', 'V11', 'V1', 'V17', 'V42', 'V12', 'V25', 'V57', 'V39', 'V7', 'V44', 'V4', 'V13', 'V51', 'V55', 'V49', 'V40', 'V31', 'V47']

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ])

data_pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('regressor', RandomForestRegressor(max_leaf_nodes=500, n_jobs=-1))
])





# ```end