# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

train_data = pd.read_csv("../../../data/Drug-Directory/Drug-Directory_train.csv")
test_data = pd.read_csv("../../../data/Drug-Directory/Drug-Directory_test.csv")

train_data['ACTIVE_NUMERATOR_STRENGTH_UNIT'] = train_data['ACTIVE_NUMERATOR_STRENGTH'].astype(str) + ' ' + train_data['ACTIVE_INGRED_UNIT']
test_data['ACTIVE_NUMERATOR_STRENGTH_UNIT'] = test_data['ACTIVE_NUMERATOR_STRENGTH'].astype(str) + ' ' + test_data['ACTIVE_INGRED_UNIT']

train_data['MARKETINGCATEGORYNAME_ROUTENAME'] = train_data['MARKETINGCATEGORYNAME'] + '_' + train_data['ROUTENAME']
test_data['MARKETINGCATEGORYNAME_ROUTENAME'] = test_data['MARKETINGCATEGORYNAME'] + '_' + test_data['ROUTENAME']

train_data.drop(columns=['APPLICATIONNUMBER'], inplace=True)
test_data.drop(columns=['APPLICATIONNUMBER'], inplace=True)

train_data.drop(columns=['PRODUCTNDC'], inplace=True)
test_data.drop(columns=['PRODUCTNDC'], inplace=True)

train_data.drop(columns=['PRODUCTID'], inplace=True)
test_data.drop(columns=['PRODUCTID'], inplace=True)

all_data = pd.concat([train_data, test_data])
PRODUCTTYPENAME_mapping = {value: i for i, value in enumerate(all_data['PRODUCTTYPENAME'].unique())}
train_data['PRODUCTTYPENAME'] = train_data['PRODUCTTYPENAME'].map(PRODUCTTYPENAME_mapping)
test_data['PRODUCTTYPENAME'] = test_data['PRODUCTTYPENAME'].map(PRODUCTTYPENAME_mapping)

for column in ['ACTIVE_NUMERATOR_STRENGTH', 'ACTIVE_INGRED_UNIT', 'PHARM_CLASSES', 'MARKETINGCATEGORYNAME', 'ROUTENAME', 'PROPRIETARYNAME', 'DOSAGEFORMNAME', 'NONPROPRIETARYNAME', 'LABELERNAME', 'SUBSTANCENAME', 'ACTIVE_NUMERATOR_STRENGTH_UNIT', 'MARKETINGCATEGORYNAME_ROUTENAME']:
    train_data[column] = train_data[column].fillna('Missing')
    test_data[column] = test_data[column].fillna('Missing')

categorical_cols = ['ACTIVE_NUMERATOR_STRENGTH', 'ACTIVE_INGRED_UNIT', 'PHARM_CLASSES', 'MARKETINGCATEGORYNAME', 'ROUTENAME', 'PROPRIETARYNAME', 'DOSAGEFORMNAME', 'NONPROPRIETARYNAME', 'LABELERNAME', 'SUBSTANCENAME', 'LISTING_RECORD_CERTIFIED_THROUGH', 'ACTIVE_NUMERATOR_STRENGTH_UNIT', 'MARKETINGCATEGORYNAME_ROUTENAME']
encoder = OneHotEncoder(handle_unknown='ignore')
encoder.fit(all_data[categorical_cols])

train_encoded = encoder.transform(train_data[categorical_cols]).toarray()
test_encoded = encoder.transform(test_data[categorical_cols]).toarray()

train_data = train_data.reset_index(drop=True)
test_data = test_data.reset_index(drop=True)

train_data = pd.concat([train_data, pd.DataFrame(train_encoded)], axis=1)
test_data = pd.concat([test_data, pd.DataFrame(test_encoded)], axis=1)

X_train = train_data.drop(columns=['PRODUCTTYPENAME'] + categorical_cols)
y_train = train_data['PRODUCTTYPENAME']
X_test = test_data.drop(columns=['PRODUCTTYPENAME'] + categorical_cols)
y_test = test_data['PRODUCTTYPENAME']

trn = RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1)
trn.fit(X_train, y_train)

Train_Accuracy = accuracy_score(y_train, trn.predict(X_train))
Test_Accuracy = accuracy_score(y_test, trn.predict(X_test))

Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, trn.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovr')
Test_AUC_OVO = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end