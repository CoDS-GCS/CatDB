# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.multioutput import MultiOutputClassifier
from sklearn.linear_model import LogisticRegression 
from joblib import Parallel, delayed

categorical_cols = ['LISTING_RECORD_CERTIFIED_THROUGH', 'MARKETINGCATEGORYNAME']

encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)

preprocessor = ColumnTransformer(
    transformers=[('cat', encoder, categorical_cols)],
    remainder='passthrough'
)

model = MultiOutputClassifier(LogisticRegression())

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('model', model)
])

train_data = pd.read_csv("../../../data/Drug-Directory/Drug-Directory_train.csv")
test_data = pd.read_csv("../../../data/Drug-Directory/Drug-Directory_test.csv")

X_train = train_data.drop('PRODUCTTYPENAME', axis=1)
y_train = train_data['PRODUCTTYPENAME']
X_test = test_data.drop('PRODUCTTYPENAME', axis=1)
y_test = test_data['PRODUCTTYPENAME']

def fit_model(pipeline, X, y):
    pipeline.fit(X, y)
    return pipeline

n_jobs = -1  # Use all available cores
pipelines = Parallel(n_jobs=n_jobs)(delayed(fit_model)(pipeline, X_train, y_train) for i in range(n_jobs))
# ```end