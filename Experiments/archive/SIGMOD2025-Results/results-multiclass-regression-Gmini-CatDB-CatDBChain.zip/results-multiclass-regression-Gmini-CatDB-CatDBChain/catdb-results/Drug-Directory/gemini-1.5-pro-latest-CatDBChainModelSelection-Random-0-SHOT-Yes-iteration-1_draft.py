# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.compose import make_column_selector as selector
from sklearn.ensemble import RandomForestClassifier
from sklearn.multiclass import OneVsRestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

try:
    data = data.drop(['PRODUCTNDC', 'PRODUCTID'], axis=1)  # Example: Dropping potentially irrelevant ID columns
except NameError:
    pass

categorical_cols = ['LISTING_RECORD_CERTIFIED_THROUGH', 
                   'MARKETINGCATEGORYNAME', 'ROUTENAME', 'DOSAGEFORMNAME'] 
numerical_cols = ['STARTMARKETINGDATE'] 

numerical_transformer = StandardScaler()
categorical_transformer = OneHotEncoder(handle_unknown='ignore')

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_cols),
        ('cat', categorical_transformer, categorical_cols)
    ])

from sklearn.model_selection import train_test_split
X = data.drop('PRODUCTTYPENAME', axis=1)
y = data['PRODUCTTYPENAME']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42) 

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(n_jobs=-1, max_leaf_nodes=500))
])


pipeline.fit(X_train, y_train)

train_predictions = pipeline.predict(X_train)
test_predictions = pipeline.predict(X_test)
train_proba = pipeline.predict_proba(X_train)
test_proba = pipeline.predict_proba(X_test)

Train_Accuracy = accuracy_score(y_train, train_predictions)
Test_Accuracy = accuracy_score(y_test, test_predictions)

Train_Log_loss = log_loss(y_train, train_proba)
Test_Log_loss = log_loss(y_test, test_proba)

Train_AUC_OVO = roc_auc_score(y_train, train_proba, multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, train_proba, multi_class='ovr')

Test_AUC_OVO = roc_auc_score(y_test, test_proba, multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, test_proba, multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_Log_loss:{Train_Log_loss}") 

print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_Log_loss:{Test_Log_loss}") 
# ```end