# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score
from sklearn.multiclass import OneVsRestClassifier
import numpy as np

train_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_train.csv")
test_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_test.csv")


for column in train_data.select_dtypes(include=['number']).columns:
    std = train_data[column].std()
    train_data[column] +=  np.random.normal(0, 0.1 * std, train_data.shape[0])

categorical_cols = ['protocol_type', 'flag', 'service']
encoder = OneHotEncoder(handle_unknown='ignore')
encoder.fit(pd.concat([train_data[categorical_cols], test_data[categorical_cols]]))

train_encoded = pd.DataFrame(encoder.transform(train_data[categorical_cols]).toarray(), columns=encoder.get_feature_names_out(categorical_cols))
train_data = train_data.drop(categorical_cols, axis=1).reset_index(drop=True).join(train_encoded)

test_encoded = pd.DataFrame(encoder.transform(test_data[categorical_cols]).toarray(), columns=encoder.get_feature_names_out(categorical_cols))
test_data = test_data.drop(categorical_cols, axis=1).reset_index(drop=True).join(test_encoded)



all_labels = list(set(train_data['label'].unique()) | set(test_data['label'].unique()))
label_mapping = {label: i for i, label in enumerate(all_labels)}

train_data['label'] = train_data['label'].map(label_mapping)
test_data['label'] = test_data['label'].map(label_mapping)

trn = RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1)
trn.fit(train_data.drop('label', axis=1), train_data['label'])

train_predictions = trn.predict(train_data.drop('label', axis=1))
train_proba = trn.predict_proba(train_data.drop('label', axis=1))
test_predictions = trn.predict(test_data.drop('label', axis=1))
test_proba = trn.predict_proba(test_data.drop('label', axis=1))

Train_Accuracy = accuracy_score(train_data['label'], train_predictions)
Test_Accuracy = accuracy_score(test_data['label'], test_predictions)

Train_Log_loss = log_loss(train_data['label'], train_proba)
Test_Log_loss = log_loss(test_data['label'], test_proba)

Train_AUC_OVO = roc_auc_score(train_data['label'], train_proba, multi_class='ovo')
Train_AUC_OVR = roc_auc_score(train_data['label'], train_proba, multi_class='ovr')
Test_AUC_OVO = roc_auc_score(test_data['label'], test_proba, multi_class='ovo')
Test_AUC_OVR = roc_auc_score(test_data['label'], test_proba, multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_Log_loss:{Train_Log_loss}") 
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end