# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score
from sklearn.multiclass import OneVsRestClassifier

train_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_train.csv")
test_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_test.csv")



train_data['protocol_flag'] = train_data['protocol_type'] + '_' + train_data['flag']
test_data['protocol_flag'] = test_data['protocol_type'] + '_' + test_data['flag']

train_data['service_login'] = train_data['service'] + '_' + train_data['logged_in'].astype(str)
test_data['service_login'] = test_data['service'] + '_' + test_data['logged_in'].astype(str)

train_data.drop(columns=['duration'], inplace=True)
test_data.drop(columns=['duration'], inplace=True)
train_data.drop(columns=['land'], inplace=True)
test_data.drop(columns=['land'], inplace=True)

for column in ['protocol_type', 'flag', 'service', 'protocol_flag', 'service_login']:
    combined_categories = pd.concat([train_data[column], test_data[column]]).unique()
    ohe = OneHotEncoder(handle_unknown='ignore', categories=[combined_categories])
    ohe.fit(pd.concat([train_data[column], test_data[column]]).values.reshape(-1, 1))
    train_data[column] = ohe.transform(train_data[column].values.reshape(-1, 1)).toarray()
    test_data[column] = ohe.transform(test_data[column].values.reshape(-1, 1)).toarray()

X_train = train_data.drop(columns=['label'])
y_train = train_data['label']
X_test = test_data.drop(columns=['label'])
y_test = test_data['label']

trn = RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1) 
trn.fit(X_train, y_train)

Train_Accuracy = accuracy_score(y_train, trn.predict(X_train))
Test_Accuracy = accuracy_score(y_test, trn.predict(X_test))

Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, trn.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovr')
Test_AUC_OVO = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_Log_loss:{Train_Log_loss}") 
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end