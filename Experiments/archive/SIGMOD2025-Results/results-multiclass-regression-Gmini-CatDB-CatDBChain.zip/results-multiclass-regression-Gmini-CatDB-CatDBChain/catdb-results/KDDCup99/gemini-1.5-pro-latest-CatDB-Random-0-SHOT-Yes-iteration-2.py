# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score
from sklearn.multiclass import OneVsRestClassifier
import numpy as np

train_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_train.csv")
test_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_test.csv")


for column in train_data.select_dtypes(include=['number']).columns:
    train_data[column] += np.random.normal(0, 0.1, size=len(train_data))
for column in test_data.select_dtypes(include=['number']).columns:
    test_data[column] += np.random.normal(0, 0.1, size=len(test_data))

categorical_cols = ['protocol_type', 'flag', 'service']
encoder = OneHotEncoder(handle_unknown='ignore')
encoder.fit(pd.concat([train_data[categorical_cols], test_data[categorical_cols]]))  # Fit on combined data

train_encoded = pd.DataFrame(encoder.transform(train_data[categorical_cols]).toarray())
train_encoded = train_encoded.add_prefix('encoded_')
train_data = train_data.reset_index(drop=True).join(train_encoded, lsuffix='_caller')

test_encoded = pd.DataFrame(encoder.transform(test_data[categorical_cols]).toarray())
test_encoded = test_encoded.add_prefix('encoded_')
test_data = test_data.reset_index(drop=True).join(test_encoded, lsuffix='_caller')

train_data['protocol_type_flag'] = train_data['protocol_type'] + '_' + train_data['flag']
test_data['protocol_type_flag'] = test_data['protocol_type'] + '_' + test_data['flag']

categorical_cols = ['protocol_type_flag'] 
encoder = OneHotEncoder(handle_unknown='ignore')
encoder.fit(pd.concat([train_data[categorical_cols], test_data[categorical_cols]]))

train_encoded = pd.DataFrame(encoder.transform(train_data[categorical_cols]).toarray())
train_encoded = train_encoded.add_prefix('encoded_')
train_data = train_data.reset_index(drop=True).join(train_encoded, lsuffix='_caller')

test_encoded = pd.DataFrame(encoder.transform(test_data[categorical_cols]).toarray())
test_encoded = test_encoded.add_prefix('encoded_')
test_data = test_data.reset_index(drop=True).join(test_encoded, lsuffix='_caller')

columns_to_drop = ['protocol_type', 'flag', 'service','protocol_type_flag']  # Example
train_data.drop(columns=columns_to_drop, inplace=True)
test_data.drop(columns=columns_to_drop, inplace=True)

X_train = train_data.drop(columns=['label'])
y_train = train_data['label']
X_test = test_data.drop(columns=['label'])
y_test = test_data['label']

trn = RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1)  # Using all available cores
trn.fit(X_train, y_train)

Train_Accuracy = accuracy_score(y_train, trn.predict(X_train))
Test_Accuracy = accuracy_score(y_test, trn.predict(X_test))

Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, trn.predict_proba(X_test))

ovr_classifier = OneVsRestClassifier(trn).fit(X_train, y_train)
Train_AUC_OVO = roc_auc_score(y_train, ovr_classifier.predict_proba(X_train), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, ovr_classifier.predict_proba(X_train), multi_class='ovr')
Test_AUC_OVO = roc_auc_score(y_test, ovr_classifier.predict_proba(X_test), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, ovr_classifier.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_Log_loss:{Train_Log_loss}") 
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end