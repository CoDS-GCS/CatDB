# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score
from sklearn.multiclass import OneVsRestClassifier

train_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_train.csv")
test_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_test.csv")



categorical_cols = ['protocol_type', 'flag', 'service']
enc = OneHotEncoder(handle_unknown='ignore')
enc.fit(pd.concat([train_data[categorical_cols], test_data[categorical_cols]]))
train_data_encoded = pd.DataFrame(enc.transform(train_data[categorical_cols]).toarray(), columns=enc.get_feature_names_out(categorical_cols))
test_data_encoded = pd.DataFrame(enc.transform(test_data[categorical_cols]).toarray(), columns=enc.get_feature_names_out(categorical_cols))
train_data = train_data.drop(categorical_cols, axis=1).reset_index(drop=True).join(train_data_encoded)
test_data = test_data.drop(categorical_cols, axis=1).reset_index(drop=True).join(test_data_encoded)


train_data.drop(columns=['land'], inplace=True)
test_data.drop(columns=['land'], inplace=True)

trn = RandomForestClassifier(max_leaf_nodes=500)
trn.fit(train_data.drop(columns=['label']), train_data['label'])

Train_Accuracy = accuracy_score(train_data['label'], trn.predict(train_data.drop(columns=['label'])))
Test_Accuracy = accuracy_score(test_data['label'], trn.predict(test_data.drop(columns=['label'])))

Train_Log_loss = log_loss(train_data['label'], trn.predict_proba(train_data.drop(columns=['label'])))
Test_Log_loss = log_loss(test_data['label'], trn.predict_proba(test_data.drop(columns=['label'])))

Train_AUC_OVO = roc_auc_score(train_data['label'], trn.predict_proba(train_data.drop(columns=['label'])), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(train_data['label'], trn.predict_proba(train_data.drop(columns=['label'])), multi_class='ovr')
Test_AUC_OVO = roc_auc_score(test_data['label'], trn.predict_proba(test_data.drop(columns=['label'])), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(test_data['label'], trn.predict_proba(test_data.drop(columns=['label'])), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end