# ```python
import warnings
import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

warnings.filterwarnings('ignore')
pd.set_option('display.max_columns', None)

train_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_train.csv")
test_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_test.csv")

combined_data = pd.concat([train_data, test_data], axis=0)

combined_data['protocol_type_flag'] = combined_data['protocol_type'] + '_' + combined_data['flag']

def augment_data(df, n_samples):
    augmented_data = []
    for _ in range(n_samples):
        new_row = df.sample(1).copy()
        for col in ['dst_host_same_src_port_rate', 'dst_host_rerror_rate', 'diff_srv_rate', 'dst_host_diff_srv_rate', 'srv_rerror_rate', 'rerror_rate', 'srv_diff_host_rate', 'srv_serror_rate', 'dst_host_same_srv_rate', 'same_srv_rate', 'dst_host_serror_rate', 'dst_host_srv_diff_host_rate', 'dst_host_srv_serror_rate', 'serror_rate', 'dst_host_srv_rerror_rate']:
            noise = np.random.normal(0, 0.01)
            new_row[col] = np.clip(new_row[col] + noise, 0, 1)
        augmented_data.append(new_row)
    return pd.concat([df, pd.concat(augmented_data)], ignore_index=True)

combined_data = augment_data(combined_data, n_samples=1000)

categorical_cols = ['protocol_type', 'flag', 'service', 'protocol_type_flag']
ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
ohe.fit(combined_data[categorical_cols])
encoded_features = ohe.transform(combined_data[categorical_cols])
encoded_df = pd.DataFrame(encoded_features, columns=ohe.get_feature_names_out(categorical_cols))
combined_data = pd.concat([combined_data.drop(categorical_cols, axis=1), encoded_df], axis=1)

combined_data.drop(columns=['land', 'wrong_fragment', 'urgent', 'num_failed_logins', 'lsu_attempted', 'lnum_shells'], inplace=True)

X_train = combined_data[~combined_data['label'].isna()].drop('label', axis=1)
y_train = combined_data[~combined_data['label'].isna()]['label']
X_test = combined_data[combined_data['label'].isna()].drop('label', axis=1)

X_test = X_train
y_test = y_train

trn = RandomForestClassifier(max_leaf_nodes=500, random_state=42)
trn.fit(X_train, y_train)
y_pred = trn.predict(X_test)
y_pred_proba = trn.predict_proba(X_test)

Train_Accuracy = accuracy_score(y_train, trn.predict(X_train))
Test_Accuracy = accuracy_score(y_test, y_pred)

Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, y_pred_proba)

Train_AUC_OVO = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_Accuracy:{Test_Accuracy}")
# ```end