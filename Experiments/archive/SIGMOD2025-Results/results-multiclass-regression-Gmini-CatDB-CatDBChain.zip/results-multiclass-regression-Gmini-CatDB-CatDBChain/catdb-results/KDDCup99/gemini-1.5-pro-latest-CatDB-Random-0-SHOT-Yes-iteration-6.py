# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score
from sklearn.multiclass import OneVsRestClassifier

train_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_train.csv")
test_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_test.csv")



categorical_cols = ['protocol_type', 'flag', 'service']
for col in categorical_cols:
    # Create a OneHotEncoder object, handle_unknown='ignore' to avoid unseen values in test data
    enc = OneHotEncoder(handle_unknown='ignore')
    # Fit the encoder on both train and test data
    enc.fit(pd.concat([train_data[[col]], test_data[[col]]]))
    # Transform the training data
    train_dummies = pd.DataFrame(enc.transform(train_data[[col]]).toarray(), columns=[f'{col}_{c}' for c in enc.categories_[0]])
    train_data = train_data.drop(columns=[col]).reset_index(drop=True).join(train_dummies)
    # Transform the test data
    test_dummies = pd.DataFrame(enc.transform(test_data[[col]]).toarray(), columns=[f'{col}_{c}' for c in enc.categories_[0]])
    test_data = test_data.drop(columns=[col]).reset_index(drop=True).join(test_dummies)



X_train = train_data.drop(columns=['label'])
y_train = train_data['label']
X_test = test_data.drop(columns=['label'])
y_test = test_data['label']

trn = RandomForestClassifier(max_leaf_nodes=500)
trn.fit(X_train, y_train)

y_train_pred = trn.predict(X_train)
y_train_proba = trn.predict_proba(X_train)
y_test_pred = trn.predict(X_test)
y_test_proba = trn.predict_proba(X_test)

Train_Accuracy = accuracy_score(y_train, y_train_pred)
Test_Accuracy = accuracy_score(y_test, y_test_pred)
Train_Log_loss = log_loss(y_train,  y_train_proba)
Test_Log_loss = log_loss(y_test,  y_test_proba)
Train_AUC_OVO = roc_auc_score(y_train, y_train_proba, multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, y_train_proba, multi_class='ovr')
Test_AUC_OVO = roc_auc_score(y_test, y_test_proba, multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, y_test_proba, multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end