# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score
from sklearn.multiclass import OneVsRestClassifier

train_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_train.csv")
test_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_test.csv")



categorical_cols = ['protocol_type', 'flag', 'service']
encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)

encoder.fit(pd.concat([train_data[categorical_cols], test_data[categorical_cols]]))

train_encoded = encoder.transform(train_data[categorical_cols])
test_encoded = encoder.transform(test_data[categorical_cols])

train_encoded_df = pd.DataFrame(train_encoded, columns=encoder.get_feature_names_out(categorical_cols))
test_encoded_df = pd.DataFrame(test_encoded, columns=encoder.get_feature_names_out(categorical_cols))

train_data = pd.concat([train_data, train_encoded_df], axis=1)
test_data = pd.concat([test_data, test_encoded_df], axis=1)

train_data['service_and_diff_srv_rate'] = train_data['service_http'] * train_data['diff_srv_rate']
test_data['service_and_diff_srv_rate'] = test_data['service_http'] * test_data['diff_srv_rate']

train_data.drop(columns=['land'], inplace=True)
test_data.drop(columns=['land'], inplace=True)

X_train = train_data.drop(columns=['label'])
y_train = train_data['label']
X_test = test_data.drop(columns=['label'])
y_test = test_data['label']

for col in X_train.columns:
    if X_train[col].dtype == 'object':
        try:
            X_train[col] = X_train[col].astype(float)
        except:
            X_train[col] = X_train[col].astype('category').cat.codes
    if X_test[col].dtype == 'object':
        try:
            X_test[col] = X_test[col].astype(float)
        except:
            X_test[col] = X_test[col].astype('category').cat.codes


trn = RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1)
trn.fit(X_train, y_train)

y_train_pred = trn.predict(X_train)
y_test_pred = trn.predict(X_test)

Train_Accuracy = accuracy_score(y_train, y_train_pred)
Test_Accuracy = accuracy_score(y_test, y_test_pred)

Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, trn.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovr')
Test_AUC_OVO = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_Log_loss:{Train_Log_loss}") 
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end