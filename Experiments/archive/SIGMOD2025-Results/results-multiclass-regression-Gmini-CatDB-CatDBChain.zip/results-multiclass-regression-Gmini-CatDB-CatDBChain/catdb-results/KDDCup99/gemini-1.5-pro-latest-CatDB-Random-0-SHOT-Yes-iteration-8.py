# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

train_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_train.csv")
test_data = pd.read_csv("../../../data/KDDCup99/KDDCup99_test.csv")



categorical_cols = ['protocol_type', 'flag', 'service']
numerical_cols = ['dst_host_same_src_port_rate', 'dst_host_rerror_rate', 'diff_srv_rate', 'dst_host_diff_srv_rate',
                   'srv_rerror_rate', 'rerror_rate', 'srv_diff_host_rate', 'srv_serror_rate',
                   'dst_host_same_srv_rate', 'same_srv_rate', 'dst_host_serror_rate',
                   'dst_host_srv_diff_host_rate', 'dst_host_srv_serror_rate', 'serror_rate',
                   'dst_host_srv_rerror_rate', 'dst_bytes', 'dst_host_count', 'lnum_root',
                   'src_bytes', 'wrong_fragment', 'lnum_compromised', 'lnum_access_files', 'hot',
                   'lnum_file_creations', 'count', 'num_failed_logins', 'lsu_attempted',
                   'srv_count', 'urgent', 'dst_host_srv_count', 'duration', 'lnum_shells']
boolean_cols = ['land', 'lroot_shell', 'logged_in', 'is_guest_login', 'is_host_login']

encoder = OneHotEncoder(handle_unknown='ignore')
encoder.fit(pd.concat([train_data[categorical_cols], test_data[categorical_cols]]))
train_encoded = pd.DataFrame(encoder.transform(train_data[categorical_cols]).toarray(), columns=encoder.get_feature_names_out(categorical_cols))
test_encoded = pd.DataFrame(encoder.transform(test_data[categorical_cols]).toarray(), columns=encoder.get_feature_names_out(categorical_cols))

train_data = pd.concat([train_data, train_encoded], axis=1)
test_data = pd.concat([test_data, test_encoded], axis=1)


X_train = train_data.drop(columns=['label'])
y_train = train_data['label']
X_test = test_data.drop(columns=['label'])
y_test = test_data['label']

X_train = X_train[numerical_cols + list(encoder.get_feature_names_out(categorical_cols))].astype(float)
X_test = X_test[numerical_cols + list(encoder.get_feature_names_out(categorical_cols))].astype(float)


trn = RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1)
trn.fit(X_train, y_train)

Train_Accuracy = accuracy_score(y_train, trn.predict(X_train))
Test_Accuracy = accuracy_score(y_test, trn.predict(X_test))

Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, trn.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovr')
Test_AUC_OVO = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end