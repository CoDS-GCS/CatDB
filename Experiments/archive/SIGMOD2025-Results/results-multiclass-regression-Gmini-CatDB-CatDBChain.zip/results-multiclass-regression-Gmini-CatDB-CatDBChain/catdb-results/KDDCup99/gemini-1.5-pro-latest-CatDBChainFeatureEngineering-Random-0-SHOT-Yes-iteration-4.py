# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from multiprocessing import cpu_count
from joblib import Parallel, delayed

categorical_cols = ['protocol_type', 'flag', 'service']

numerical_cols = ['duration', 'src_bytes', 'dst_bytes', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins',
                 'lnum_compromised', 'lnum_access_files', 'lnum_file_creations', 'count', 'srv_count',
                 'dst_host_count', 'dst_host_srv_count', 'lnum_root', 'lnum_shells', 
                 'dst_host_same_src_port_rate', 'dst_host_rerror_rate', 'diff_srv_rate', 
                 'dst_host_diff_srv_rate', 'srv_rerror_rate', 'rerror_rate', 'srv_diff_host_rate',
                 'srv_serror_rate', 'dst_host_same_srv_rate', 'same_srv_rate', 'dst_host_serror_rate',
                 'dst_host_srv_diff_host_rate', 'dst_host_srv_serror_rate', 'serror_rate',
                 'dst_host_srv_rerror_rate'] 

binary_cols = ['land', 'logged_in', 'root_shell', 'su_attempted', 'is_guest_login', 'is_host_login']

numeric_transformer = Pipeline(steps=[
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numerical_cols),
        ('cat', categorical_transformer, categorical_cols)
    ],
    remainder='passthrough'  # Passthrough binary columns
)

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor)
])


def process_chunk(df_chunk):
    # Apply the pipeline to the chunk of the DataFrame
    df_chunk = pipeline.fit_transform(df_chunk)
    return df_chunk

def main():
    # Load the dataset (replace 'your_dataset.csv' with the actual file name)
    df = pd.read_csv('kddcup.data_10_percent.gz', compression='gzip', header=None)

    # ... (rest of your data loading and preprocessing code)

    # Split the data into chunks
    n_cores = cpu_count()
    df_chunks = np.array_split(df, n_cores)

    # Process the chunks in parallel
    results = Parallel(n_jobs=n_cores)(delayed(process_chunk)(chunk) for chunk in df_chunks)

    # Combine the results
    df_processed = pd.concat(results)

    # ... (rest of your code)
# ```end