# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

categorical_features = ['protocol_type', 'flag', 'service']
numerical_features = ['duration', 'src_bytes', 'dst_bytes', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins',
                       'lnum_compromised', 'lnum_file_creations', 'lnum_root', 'lnum_access_files', 'count',
                       'srv_count', 'dst_host_count', 'dst_host_srv_count',
                       'dst_host_same_src_port_rate', 'dst_host_rerror_rate', 'diff_srv_rate',
                       'dst_host_diff_srv_rate', 'srv_rerror_rate', 'rerror_rate', 'srv_diff_host_rate',
                       'srv_serror_rate', 'dst_host_same_srv_rate', 'same_srv_rate', 'dst_host_serror_rate',
                       'dst_host_srv_diff_host_rate', 'dst_host_srv_serror_rate', 'serror_rate',
                       'dst_host_srv_rerror_rate']
boolean_features = ['land', 'logged_in', 'is_guest_login', 'lroot_shell', 'lsu_attempted', 'lnum_shells', 'is_host_login']

target = 'label'

categorical_transformer = OneHotEncoder(handle_unknown='ignore')
numerical_transformer = 'passthrough'  # No transformation for numerical features for now

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', categorical_transformer, categorical_features),
        ('num', numerical_transformer, numerical_features),
        ('bool', 'passthrough', boolean_features)  # Passthrough for boolean features
    ])

pipeline = Pipeline([
    ('preprocessor', preprocessor)
    # Add other steps like scaling, feature selection, and classification here
])
# ```end