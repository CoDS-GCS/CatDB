# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from multiprocessing import Pool

categorical_cols = ['protocol_type', 'flag', 'service']

numerical_cols = ['duration', 'src_bytes', 'dst_bytes', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins',
                   'lnum_compromised', 'lnum_access_files', 'lnum_file_creations', 'count', 'srv_count',
                   'dst_host_count', 'dst_host_srv_count', 'lnum_root', 'lnum_shells']

binary_cols = ['land', 'logged_in', 'is_guest_login', 'lroot_shell']

target_col = 'label'

def process_chunk(chunk):
    # Apply one-hot encoding to categorical features
    ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
    categorical_features = ohe.fit_transform(chunk[categorical_cols])
    
    # Apply standard scaling to numerical features
    scaler = StandardScaler()
    numerical_features = scaler.fit_transform(chunk[numerical_cols])
    
    # Combine all features
    features = pd.DataFrame(data=categorical_features).join(pd.DataFrame(data=numerical_features)).join(chunk[binary_cols])
    
    return features, chunk[target_col]

def main():
    # Load the dataset (replace 'your_dataset.csv' with the actual file name)
    df = pd.read_csv('your_dataset.csv')

    # Split the data into chunks
    num_processes = 4  # Adjust based on your system's capabilities
    chunk_size = len(df) // num_processes
    data_chunks = [df[i:i + chunk_size] for i in range(0, len(df), chunk_size)]

    # Create a process pool
    with Pool(processes=num_processes) as pool:
        results = pool.map(process_chunk, data_chunks)

    # Combine results from different processes
    all_features = pd.concat([result[0] for result in results])
    all_targets = pd.concat([result[1] for result in results])

    # Now you have all_features and all_targets ready for model training
    # ...
# ```end