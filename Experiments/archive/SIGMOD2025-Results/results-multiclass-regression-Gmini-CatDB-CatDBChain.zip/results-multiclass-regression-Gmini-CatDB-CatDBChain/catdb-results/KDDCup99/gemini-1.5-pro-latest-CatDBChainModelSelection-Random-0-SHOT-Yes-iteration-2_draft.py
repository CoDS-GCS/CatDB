# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from multiprocessing import Pool
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

categorical_cols = ['protocol_type', 'flag', 'service']

numerical_cols = ['duration', 'src_bytes', 'dst_bytes', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins',
                 'lnum_compromised', 'lnum_access_files', 'lnum_file_creations', 'count', 'srv_count',
                 'dst_host_count', 'dst_host_srv_count', 'lnum_root', 'lnum_shells', 
                 'dst_host_same_src_port_rate', 'dst_host_rerror_rate', 'diff_srv_rate', 
                 'dst_host_diff_srv_rate', 'srv_rerror_rate', 'rerror_rate', 'srv_diff_host_rate',
                 'srv_serror_rate', 'dst_host_same_srv_rate', 'same_srv_rate', 'dst_host_serror_rate',
                 'dst_host_srv_diff_host_rate', 'dst_host_srv_serror_rate', 'serror_rate',
                 'dst_host_srv_rerror_rate'] 

binary_cols = ['land', 'logged_in', 'is_guest_login', 'lroot_shell', 'lsu_attempted', 'is_host_login']

all_features = categorical_cols + numerical_cols + binary_cols

df = pd.read_csv('kddcup.data.gz', compression='gzip', header=None, names=['duration', 'protocol_type', 'service', 'flag', 'src_bytes', 'dst_bytes', 'land', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins', 'logged_in', 'lnum_compromised', 'lnum_root', 'lnum_file_creations', 'lnum_shells', 'lnum_access_files', 'is_guest_login', 'count', 'srv_count', 'serror_rate', 'rerror_rate', 'same_srv_rate', 'diff_srv_rate', 'srv_serror_rate', 'srv_rerror_rate', 'srv_diff_host_rate', 'dst_host_count', 'dst_host_srv_count', 'dst_host_same_srv_rate', 'dst_host_diff_srv_rate', 'dst_host_same_src_port_rate', 'dst_host_serror_rate', 'dst_host_srv_serror_rate', 'dst_host_rerror_rate', 'dst_host_srv_rerror_rate', 'dst_host_srv_diff_host_rate', 'lsu_attempted', 'is_host_login', 'label'])

X_train, X_test, y_train, y_test = train_test_split(df.drop('label', axis=1), df['label'], test_size=0.2, random_state=42)

preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numerical_cols),
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_cols)
    ],
    remainder='passthrough' 
)

model = RandomForestClassifier(max_leaf_nodes=500, random_state=42)

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('classifier', model)
])
# ```end