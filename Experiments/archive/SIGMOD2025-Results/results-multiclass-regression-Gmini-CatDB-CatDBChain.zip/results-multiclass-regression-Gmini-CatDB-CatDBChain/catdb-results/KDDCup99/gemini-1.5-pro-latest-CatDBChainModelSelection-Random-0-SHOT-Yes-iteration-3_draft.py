# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from multiprocessing import cpu_count
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

categorical_features = ['protocol_type', 'flag', 'service']
numerical_features = ['duration', 'src_bytes', 'dst_bytes', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins',
                       'lnum_compromised', 'lnum_file_creations', 'lnum_root', 'lnum_access_files', 'count', 'srv_count',
                       'dst_host_count', 'dst_host_srv_count', 'dst_host_same_src_port_rate', 'dst_host_rerror_rate',
                       'diff_srv_rate', 'dst_host_diff_srv_rate', 'srv_rerror_rate', 'rerror_rate',
                       'srv_diff_host_rate', 'srv_serror_rate', 'dst_host_same_srv_rate', 'same_srv_rate',
                       'dst_host_serror_rate', 'dst_host_srv_diff_host_rate', 'dst_host_srv_serror_rate',
                       'serror_rate', 'dst_host_srv_rerror_rate']
boolean_features = ['land', 'logged_in', 'is_guest_login', 'lroot_shell', 'lsu_attempted', 'lnum_shells', 'is_host_login']

target = 'label'

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features),
        ('bool', 'passthrough', boolean_features)  # Boolean features are directly passed through
    ],
    n_jobs=cpu_count()  # Use all available CPU cores for parallel processing
)

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(max_leaf_nodes=500, n_jobs=cpu_count()))
])

data = pd.read_csv('kddcup.data_10_percent_corrected.csv')  # Assuming the data is in a file named 'kddcup.data_10_percent_corrected.csv'

X = data.drop(target, axis=1)
y = data[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

pipeline.fit(X_train, y_train)

y_train_pred = pipeline.predict(X_train)
y_test_pred = pipeline.predict(X_test)

Train_Accuracy = accuracy_score(y_train, y_train_pred)
Test_Accuracy = accuracy_score(y_test, y_test_pred)

Train_Log_loss = log_loss(y_train, pipeline.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, pipeline.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, pipeline.predict_proba(X_train), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, pipeline.predict_proba(X_train), multi_class='ovr')

Test_AUC_OVO = roc_auc_score(y_test, pipeline.predict_proba(X_test), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, pipeline.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end