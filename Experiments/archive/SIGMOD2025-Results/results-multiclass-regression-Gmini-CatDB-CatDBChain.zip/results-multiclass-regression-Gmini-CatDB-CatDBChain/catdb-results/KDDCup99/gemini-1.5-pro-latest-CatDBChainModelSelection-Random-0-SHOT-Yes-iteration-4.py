# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from multiprocessing import cpu_count
from joblib import Parallel, delayed
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

categorical_cols = ['protocol_type', 'flag', 'service']

numerical_cols = ['duration', 'src_bytes', 'dst_bytes', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins',
                 'lnum_compromised', 'lnum_access_files', 'lnum_file_creations', 'count', 'srv_count',
                 'dst_host_count', 'dst_host_srv_count', 'lnum_root', 'lnum_shells', 
                 'dst_host_same_src_port_rate', 'dst_host_rerror_rate', 'diff_srv_rate', 
                 'dst_host_diff_srv_rate', 'srv_rerror_rate', 'rerror_rate', 'srv_diff_host_rate',
                 'srv_serror_rate', 'dst_host_same_srv_rate', 'same_srv_rate', 'dst_host_serror_rate',
                 'dst_host_srv_diff_host_rate', 'dst_host_srv_serror_rate', 'serror_rate',
                 'dst_host_srv_rerror_rate'] 

binary_cols = ['land', 'logged_in', 'root_shell', 'su_attempted', 'is_guest_login', 'is_host_login']

numeric_transformer = Pipeline(steps=[
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numerical_cols),
        ('cat', categorical_transformer, categorical_cols)
    ],
    remainder='passthrough'  # Passthrough binary columns
)

model = RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1)

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', model)
])


def process_chunk(df_chunk):
    # Separate features and target variable
    X = df_chunk.drop('"label"', axis=1)
    y = df_chunk['"label"']
    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    # Fit the pipeline to the chunk of the DataFrame
    pipeline.fit(X_train, y_train)
    # Make predictions on train and test data
    y_train_pred = pipeline.predict(X_train)
    y_test_pred = pipeline.predict(X_test)
    # Calculate metrics
    Train_Accuracy = accuracy_score(y_train, y_train_pred)
    Test_Accuracy = accuracy_score(y_test, y_test_pred)
    Train_Log_loss = log_loss(y_train, pipeline.predict_proba(X_train))
    Test_Log_loss = log_loss(y_test, pipeline.predict_proba(X_test))
    Train_AUC_OVO = roc_auc_score(y_train, pipeline.predict_proba(X_train), multi_class='ovo')
    Train_AUC_OVR = roc_auc_score(y_train, pipeline.predict_proba(X_train), multi_class='ovr')
    Test_AUC_OVO = roc_auc_score(y_test, pipeline.predict_proba(X_test), multi_class='ovo')
    Test_AUC_OVR = roc_auc_score(y_test, pipeline.predict_proba(X_test), multi_class='ovr')
    # Print the evaluation metrics
    print(f"Train_AUC_OVO:{Train_AUC_OVO}")
    print(f"Train_AUC_OVR:{Train_AUC_OVR}")
    print(f"Train_Accuracy:{Train_Accuracy}")   
    print(f"Train_Log_loss:{Train_Log_loss}") 
    print(f"Test_AUC_OVO:{Test_AUC_OVO}")
    print(f"Test_AUC_OVR:{Test_AUC_OVR}")
    print(f"Test_Accuracy:{Test_Accuracy}")   
    print(f"Test_Log_loss:{Test_Log_loss}")
    return pipeline

def main():
    # Load the dataset (replace 'your_dataset.csv' with the actual file name)
    df = pd.read_csv('kddcup.data_10_percent.gz', compression='gzip', header=None)
    # ... (rest of your data loading and preprocessing code)
    # Split the data into chunks
    n_cores = cpu_count()
    df_chunks = np.array_split(df, n_cores)
    # Process the chunks in parallel
    results = Parallel(n_jobs=n_cores)(delayed(process_chunk)(chunk) for chunk in df_chunks)
    # Combine the results
    # Note: This part depends on what you want to do with the results.
    # For example, you might want to average the metrics across chunks.
    # ...