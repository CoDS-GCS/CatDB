# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from multiprocessing import Pool
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

categorical_cols = ['protocol_type', 'flag', 'service']

numerical_cols = ['duration', 'src_bytes', 'dst_bytes', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins',
                   'lnum_compromised', 'lnum_access_files', 'lnum_file_creations', 'count', 'srv_count',
                   'dst_host_count', 'dst_host_srv_count', 'lnum_root', 'lnum_shells']

binary_cols = ['land', 'logged_in', 'is_guest_login', 'lroot_shell']

target_col = 'label'

def process_chunk(chunk):
    # Apply one-hot encoding to categorical features
    ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
    categorical_features = ohe.fit_transform(chunk[categorical_cols])
    
    # Apply standard scaling to numerical features
    scaler = StandardScaler()
    numerical_features = scaler.fit_transform(chunk[numerical_cols])
    
    # Combine all features
    features = pd.DataFrame(data=categorical_features).join(pd.DataFrame(data=numerical_features)).join(chunk[binary_cols])
    
    return features, chunk[target_col]

df = pd.read_csv('kddcup.data_10_percent_corrected', header=None)

num_processes = 4  # Adjust based on your system's capabilities
chunk_size = len(df) // num_processes
data_chunks = [df[i:i + chunk_size] for i in range(0, len(df), chunk_size)]

with Pool(processes=num_processes) as pool:
    results = pool.map(process_chunk, data_chunks)

all_features = pd.concat([result[0] for result in results])
all_targets = pd.concat([result[1] for result in results])

X_train, X_test, y_train, y_test = train_test_split(all_features, all_targets, test_size=0.2, random_state=42)

model = RandomForestClassifier(max_leaf_nodes=500, random_state=42)

model.fit(X_train, y_train)

y_train_pred = model.predict(X_train)
y_test_pred = model.predict(X_test)

Train_Accuracy = accuracy_score(y_train, y_train_pred)
Test_Accuracy = accuracy_score(y_test, y_test_pred)

Train_Log_loss = log_loss(y_train, model.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, model.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, model.predict_proba(X_train), multi_class='ovo', labels=model.classes_)
Train_AUC_OVR = roc_auc_score(y_train, model.predict_proba(X_train), multi_class='ovr', labels=model.classes_)

Test_AUC_OVO = roc_auc_score(y_test, model.predict_proba(X_test), multi_class='ovo', labels=model.classes_)
Test_AUC_OVR = roc_auc_score(y_test, model.predict_proba(X_test), multi_class='ovr', labels=model.classes_)

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end