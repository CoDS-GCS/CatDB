# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from multiprocessing import cpu_count
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score


categorical_features = ['protocol_type', 'flag', 'service']
numerical_features = ['duration', 'src_bytes', 'dst_bytes', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins',
                       'lnum_compromised', 'lnum_file_creations', 'lnum_root', 'lnum_access_files', 'count', 'srv_count',
                       'dst_host_count', 'dst_host_srv_count', 'dst_host_same_src_port_rate', 'dst_host_rerror_rate',
                       'diff_srv_rate', 'dst_host_diff_srv_rate', 'srv_rerror_rate', 'rerror_rate',
                       'srv_diff_host_rate', 'srv_serror_rate', 'dst_host_same_srv_rate', 'same_srv_rate',
                       'dst_host_serror_rate', 'dst_host_srv_diff_host_rate', 'dst_host_srv_serror_rate',
                       'serror_rate', 'dst_host_srv_rerror_rate']
boolean_features = ['land', 'logged_in', 'is_guest_login', 'lroot_shell', 'lsu_attempted', 'lnum_shells', 'is_host_login']

target = 'label'

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features),
        ('bool', 'passthrough', boolean_features)  # Passthrough boolean features
    ],
    n_jobs=cpu_count()  # Use all available CPU cores
)

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(max_leaf_nodes=500, n_jobs=cpu_count()))
])
# ```end