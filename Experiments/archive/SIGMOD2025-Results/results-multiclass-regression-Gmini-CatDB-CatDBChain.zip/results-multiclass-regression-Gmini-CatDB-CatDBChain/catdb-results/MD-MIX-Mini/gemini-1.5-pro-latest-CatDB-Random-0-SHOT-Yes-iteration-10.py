# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.impute import SimpleImputer

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

def preprocess_data(df):
    # One-hot encode categorical features
    df = pd.get_dummies(df, columns=['variable_font_weight'])
    return df

train_data = preprocess_data(train_data)
test_data = preprocess_data(test_data)

def feature_engineering(df):
    # Example feature: Ratio of outline size to original image height
    # Feature name and description: outline_size_to_image_height_ratio
    # Usefulness: This feature captures the relative size of the outline compared to the image height, which could be indicative of the complexity of the character.
    df['outline_size_to_image_height_ratio'] = df['outline_size'] / df['original_image_height_resolution']
    return df

train_data = feature_engineering(train_data)
test_data = feature_engineering(test_data)

def select_features(df):
    # Explanation why the column 'FILE_NAME' is dropped: 'FILE_NAME' is not relevant to the target variable.
    df.drop(columns=['FILE_NAME'], inplace=True)
    # Explanation why the column 'text' is dropped: 'text' is not relevant to the target variable.
    df.drop(columns=['text'], inplace=True)
    return df

train_data = select_features(train_data)
test_data = select_features(test_data)

X_train = train_data.drop(columns=['CATEGORY'])
y_train = train_data['CATEGORY']
X_test = test_data.drop(columns=['CATEGORY'])
y_test = test_data['CATEGORY']

categorical_features = X_train.select_dtypes(include=['object']).columns
numerical_features = X_train.select_dtypes(exclude=['object']).columns

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features),
        ('num', SimpleImputer(strategy='mean'), numerical_features)
    ]
)

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('model', RandomForestRegressor(max_leaf_nodes=500, n_jobs=-1))
])

pipeline.fit(X_train, y_train)

Train_R_Squared = r2_score(y_train, pipeline.predict(X_train))
Train_RMSE = mean_squared_error(y_train, pipeline.predict(X_train), squared=False)
Test_R_Squared = r2_score(y_test, pipeline.predict(X_test))
Test_RMSE = mean_squared_error(y_test, pipeline.predict(X_test), squared=False)
print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")
# ```end