# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
import numpy as np

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

combined_data = pd.concat([train_data, test_data])

def augment_data(df):
    # Example: Adding Gaussian noise to numerical features
    for col in df.select_dtypes(include=['float64', 'int64']):
        df[col + '_augmented'] = df[col] + np.random.normal(0, 0.1, len(df))
    return df

train_data = augment_data(train_data.copy())
test_data = augment_data(test_data.copy())

def encode_categorical(df, columns):
    df = pd.get_dummies(df, columns=columns, drop_first=True)
    return df

columns_to_encode = ['variable_font_weight']
train_data = encode_categorical(train_data, columns_to_encode)
test_data = encode_categorical(test_data, columns_to_encode)

def process_features(df):
    # Example: Combining features
    df['combined_shear'] = df['shear_x'] * df['shear_y']
    return df

train_data = process_features(train_data)
test_data = process_features(test_data)

columns_to_drop = ['FILE_NAME','text', 'stroke_fill', 'background_color', 'image_blending_method', 'family_name', 'style_name', 'foreground', 'perspective_params', 'background', 'outline_image_name', 'background_image_name', 'postscript_name', 'outline', 'font_file', 'foreground_image_name', 'SUPER_CATEGORY']  # Example
train_data.drop(columns=columns_to_drop, inplace=True)
test_data.drop(columns=columns_to_drop, inplace=True)

X_train = train_data.drop(columns=['CATEGORY'])
y_train = train_data['CATEGORY']
X_test = test_data.drop(columns=['CATEGORY'])
y_test = test_data['CATEGORY']

for col in X_train.columns:
    X_train[col] = pd.to_numeric(X_train[col], errors='coerce')
    X_test[col] = pd.to_numeric(X_test[col], errors='coerce')

X_train = X_train.fillna(X_train.mean())
X_test = X_test.fillna(X_test.mean())

trn = RandomForestRegressor(max_leaf_nodes=500, random_state=42)
trn.fit(X_train, y_train)

Train_R_Squared = r2_score(y_train, trn.predict(X_train))
Train_RMSE = mean_squared_error(y_train, trn.predict(X_train), squared=False)
Test_R_Squared = r2_score(y_test, trn.predict(X_test))
Test_RMSE = mean_squared_error(y_test, trn.predict(X_test), squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")
# ```end