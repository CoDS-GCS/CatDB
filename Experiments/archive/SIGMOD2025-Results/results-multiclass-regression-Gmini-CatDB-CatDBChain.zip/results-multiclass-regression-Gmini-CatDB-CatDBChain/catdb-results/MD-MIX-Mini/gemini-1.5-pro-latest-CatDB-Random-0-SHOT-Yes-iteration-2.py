# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
import numpy as np

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

combined_data = pd.concat([train_data, test_data])

def augment_data(df):
    df_augmented = df.copy()
    # Example: Adding Gaussian noise to numerical features
    for col in df.select_dtypes(include=['float64', 'int64']):
        noise = np.random.normal(0, df[col].std() * 0.1, len(df))
        df_augmented[col + '_augmented'] = df[col] + noise
    return df_augmented

train_data = augment_data(train_data)
test_data = augment_data(test_data)

def feature_engineering(df):
    # Example: One-hot encoding for 'variable_font_weight'
    df = pd.get_dummies(df, columns=['variable_font_weight'], prefix='vfw')
    return df

train_data = feature_engineering(train_data)
test_data = feature_engineering(test_data)

def drop_redundant_columns(df):
    # Example: Dropping columns that are not relevant to the target variable
    columns_to_drop = ['FILE_NAME', 'text', 'postscript_name','font_file', 'stroke_fill', 'background_color', 'image_blending_method', 'style_name', 'foreground', 'perspective_params', 'background', 'outline_image_name', 'background_image_name', 'outline', 'font_file', 'foreground_image_name', 'SUPER_CATEGORY']  # Add more columns if needed
    df.drop(columns=columns_to_drop, inplace=True)
    return df

train_data = drop_redundant_columns(train_data)
test_data = drop_redundant_columns(test_data)

X_train = train_data.drop(columns=['CATEGORY'])
y_train = train_data['CATEGORY']
X_test = test_data.drop(columns=['CATEGORY'])
y_test = test_data['CATEGORY']

X_train = X_train.apply(pd.to_numeric, errors='coerce')
X_test = X_test.apply(pd.to_numeric, errors='coerce')

X_train = X_train.fillna(X_train.mean())
X_test = X_test.fillna(X_test.mean())

model = RandomForestRegressor(max_leaf_nodes=500)
model.fit(X_train, y_train)

Train_R_Squared = r2_score(y_train, model.predict(X_train))
Train_RMSE = mean_squared_error(y_train, model.predict(X_train), squared=False)
Test_R_Squared = r2_score(y_test, model.predict(X_test))
Test_RMSE = mean_squared_error(y_test, model.predict(X_test), squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")
# ```end