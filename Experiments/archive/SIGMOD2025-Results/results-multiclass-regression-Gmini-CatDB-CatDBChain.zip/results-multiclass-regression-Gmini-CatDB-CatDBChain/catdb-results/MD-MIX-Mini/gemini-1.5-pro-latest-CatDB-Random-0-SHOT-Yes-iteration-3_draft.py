# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
import numpy as np

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

combined_data = pd.concat([train_data, test_data])

def augment_data(df):
    # Example: Adding Gaussian noise to numerical features
    for col in df.select_dtypes(include=['float64', 'int64']):
        df[col + '_augmented'] = df[col] + np.random.normal(0, 0.1, size=len(df))
    return df

train_data = augment_data(train_data.copy())
test_data = augment_data(test_data.copy())

def encode_categorical(df, columns):
    df = pd.get_dummies(df, columns=columns, drop_first=True)
    return df

columns_to_encode = ['variable_font_weight']
train_data = encode_categorical(train_data, columns_to_encode)
test_data = encode_categorical(test_data, columns_to_encode)

def feature_engineering(df):
    # Example: Combining features
    df['combined_shear'] = df['shear_x'] * df['shear_y']
    return df

train_data = feature_engineering(train_data)
test_data = feature_engineering(test_data)

X_train = train_data.drop(columns=['CATEGORY'])
y_train = train_data['CATEGORY']
X_test = test_data.drop(columns=['CATEGORY'])
y_test = test_data['CATEGORY']

X_train.drop(columns=['FILE_NAME'], inplace=True)
X_test.drop(columns=['FILE_NAME'], inplace=True)

for col in X_train.columns:
    if X_train[col].dtype == 'object':
        try:
            X_train[col] = X_train[col].astype(float)
        except:
            X_train[col] = X_train[col].astype('category').cat.codes
            
for col in X_test.columns:
    if X_test[col].dtype == 'object':
        try:
            X_test[col] = X_test[col].astype(float)
        except:
            X_test[col] = X_test[col].astype('category').cat.codes

trn = RandomForestRegressor(max_leaf_nodes=500)
trn.fit(X_train, y_train)

Train_R_Squared = r2_score(y_train, trn.predict(X_train))
Test_R_Squared = r2_score(y_test, trn.predict(X_test))

Train_RMSE = mean_squared_error(y_train, trn.predict(X_train), squared=False)
Test_RMSE = mean_squared_error(y_test, trn.predict(X_test), squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")
# ```end