# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
import numpy as np

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

combined_data = pd.concat([train_data, test_data])

numerical_features = ['brightness', 'contrast', 'rotation', 'color_enhance', 'shear_x', 'shear_y']
for feature in numerical_features:
    combined_data[feature] += combined_data[feature].std() * 0.1 * np.random.randn(len(combined_data))

combined_data = pd.get_dummies(combined_data, columns=['variable_font_weight'], prefix='font_weight')

combined_data['offset_magnitude'] = np.sqrt(combined_data['offset_vertical']**2 + combined_data['offset_horizontal']**2)

combined_data.drop(columns=['FILE_NAME','text', 'font_file'], inplace=True)

train_data = combined_data[:len(train_data)]
test_data = combined_data[len(train_data):]

features = train_data.drop(columns=['CATEGORY'])
target = train_data['CATEGORY']

features = pd.get_dummies(features)
test_features = pd.get_dummies(test_data.drop(columns=['CATEGORY']))

features, test_features = features.align(test_features, join='outer', axis=1, fill_value=0)

scaler = StandardScaler()
features[numerical_features] = scaler.fit_transform(features[numerical_features])

trn = RandomForestRegressor(max_leaf_nodes=500, random_state=42)
trn.fit(features, target)

test_features[numerical_features] = scaler.transform(test_features[numerical_features])
predictions = trn.predict(test_features)

Train_R_Squared= r2_score(target, trn.predict(features))
Train_RMSE= mean_squared_error(target, trn.predict(features), squared=False)
Test_R_Squared= r2_score(test_data['CATEGORY'], predictions)
Test_RMSE= mean_squared_error(test_data['CATEGORY'], predictions, squared=False)
print(f"Train_R_Squared:{Train_R_Squared}")   
print(f"Train_RMSE:{Train_RMSE}") 
print(f"Test_R_Squared:{Test_R_Squared}")   
print(f"Test_RMSE:{Test_RMSE}") 
# ```end