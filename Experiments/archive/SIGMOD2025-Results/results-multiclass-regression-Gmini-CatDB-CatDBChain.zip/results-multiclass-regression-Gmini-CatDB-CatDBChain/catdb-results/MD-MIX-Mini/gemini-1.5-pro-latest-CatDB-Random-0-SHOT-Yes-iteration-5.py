# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
import numpy as np

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

combined_data = pd.concat([train_data, test_data], axis=0)


train_data['is_rotated'] = np.where(abs(train_data['rotation']) > 5, 1, 0)
test_data['is_rotated'] = np.where(abs(test_data['rotation']) > 5, 1, 0)
train_data['image_complexity'] = train_data['brightness'] * train_data['contrast'] * train_data['color_enhance']
test_data['image_complexity'] = test_data['brightness'] * test_data['contrast'] * test_data['color_enhance']
train_data['has_outline'] = np.where(train_data['outline'] == 'image', 1, 0)
test_data['has_outline'] = np.where(test_data['outline'] == 'image', 1, 0)
ohe = OneHotEncoder(handle_unknown='ignore')
feature_array = ohe.fit_transform(combined_data[['variable_font_weight']]).toarray()
feature_labels = np.array(ohe.categories_).ravel()
features = pd.DataFrame(feature_array, columns=feature_labels)
train_data = pd.concat([train_data, features[:len(train_data)]], axis=1)
test_data = pd.concat([test_data, features[len(train_data):].reset_index(drop=True)], axis=1)

train_data.drop(columns=['FILE_NAME'], inplace=True)
test_data.drop(columns=['FILE_NAME'], inplace=True)
train_data.drop(columns=['text'], inplace=True)
test_data.drop(columns=['text'], inplace=True)

for column in train_data.columns:
    if train_data[column].dtype == 'object':
        # Apply one-hot encoding to categorical features
        combined_data = pd.concat([train_data, test_data], axis=0)
        ohe = OneHotEncoder(handle_unknown='ignore')
        feature_array = ohe.fit_transform(combined_data[[column]]).toarray()
        feature_labels = [f"{column}_{value}" for value in np.array(ohe.categories_).ravel()]
        features = pd.DataFrame(feature_array, columns=feature_labels)
        train_data = pd.concat([train_data, features[:len(train_data)]], axis=1)
        test_data = pd.concat([test_data, features[len(train_data):].reset_index(drop=True)], axis=1)
        train_data.drop(columns=[column], inplace=True)
        test_data.drop(columns=[column], inplace=True)

X_train = train_data.drop(columns=['CATEGORY'])
y_train = train_data['CATEGORY']
X_test = test_data.drop(columns=['CATEGORY'])
y_test = test_data['CATEGORY']

X_train.columns = X_train.columns.astype(str)
X_test.columns = X_test.columns.astype(str)

trn = RandomForestRegressor(max_leaf_nodes=500)
trn.fit(X_train, y_train)
Train_R_Squared = r2_score(y_train, trn.predict(X_train))
Test_R_Squared = r2_score(y_test, trn.predict(X_test))

Train_RMSE = np.sqrt(mean_squared_error(y_train, trn.predict(X_train)))
Test_RMSE = np.sqrt(mean_squared_error(y_test, trn.predict(X_test)))

print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")