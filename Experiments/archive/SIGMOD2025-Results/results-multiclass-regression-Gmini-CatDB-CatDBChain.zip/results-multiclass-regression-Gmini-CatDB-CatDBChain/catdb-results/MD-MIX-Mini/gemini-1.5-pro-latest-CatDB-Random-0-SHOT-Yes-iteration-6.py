# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
import numpy as np

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

combined_data = pd.concat([train_data, test_data])

train_data = combined_data.iloc[:len(train_data)]
test_data = combined_data.iloc[len(train_data):]

for column in train_data.select_dtypes(include=['float64']).columns:
    noise = np.random.normal(0, 0.1, len(train_data))  # Adjust noise parameters as needed
    train_data[column] = train_data[column] + noise

train_data = pd.get_dummies(train_data, columns=['variable_font_weight'], drop_first=True)
test_data = pd.get_dummies(test_data, columns=['variable_font_weight'], drop_first=True)

train_data.drop(columns=['FILE_NAME'], inplace=True)
test_data.drop(columns=['FILE_NAME'], inplace=True)

X_train = train_data.drop(columns=['CATEGORY'])
y_train = train_data['CATEGORY']
X_test = test_data.drop(columns=['CATEGORY'])
y_test = test_data['CATEGORY']

X_train = X_train.apply(pd.to_numeric, errors='coerce')
X_test = X_test.apply(pd.to_numeric, errors='coerce')

X_train = X_train.fillna(X_train.mean())
X_test = X_test.fillna(X_test.mean())

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

trn = RandomForestRegressor(max_leaf_nodes=500)
trn.fit(X_train, y_train)

Train_R_Squared = r2_score(y_train, trn.predict(X_train))
Test_R_Squared = r2_score(y_test, trn.predict(X_test))
Train_RMSE = mean_squared_error(y_train, trn.predict(X_train), squared=False)
Test_RMSE = mean_squared_error(y_test, trn.predict(X_test), squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")
# ```end