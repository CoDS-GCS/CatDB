# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")



ohe = OneHotEncoder(handle_unknown='ignore')
feature_array = ohe.fit_transform(train_data[['variable_font_weight']].to_numpy()).toarray()
feature_labels = [f"variable_font_weight_{str(cls).replace(' ', '_').replace('(', '').replace(')', '')}" for cls in ohe.categories_[0]]
features = pd.DataFrame(feature_array, columns=feature_labels)
train_data = pd.concat([train_data, features], axis=1)
feature_array = ohe.transform(test_data[['variable_font_weight']].to_numpy()).toarray()
feature_labels = [f"variable_font_weight_{str(cls).replace(' ', '_').replace('(', '').replace(')', '')}" for cls in ohe.categories_[0]]
features = pd.DataFrame(feature_array, columns=feature_labels)
test_data = pd.concat([test_data, features], axis=1)


train_data.drop(columns=['stroke_fill'], inplace=True)
test_data.drop(columns=['stroke_fill'], inplace=True)
train_data.drop(columns=['background_color'], inplace=True)
test_data.drop(columns=['background_color'], inplace=True)
train_data.drop(columns=['image_blending_method'], inplace=True)
test_data.drop(columns=['image_blending_method'], inplace=True)
train_data.drop(columns=['family_name'], inplace=True)
test_data.drop(columns=['family_name'], inplace=True)
train_data.drop(columns=['style_name'], inplace=True)
test_data.drop(columns=['style_name'], inplace=True)
train_data.drop(columns=['foreground'], inplace=True)
test_data.drop(columns=['foreground'], inplace=True)
train_data.drop(columns=['perspective_params'], inplace=True)
test_data.drop(columns=['perspective_params'], inplace=True)
train_data.drop(columns=['background'], inplace=True)
test_data.drop(columns=['background'], inplace=True)
train_data.drop(columns=['outline_image_name'], inplace=True)
test_data.drop(columns=['outline_image_name'], inplace=True)
train_data.drop(columns=['background_image_name'], inplace=True)
test_data.drop(columns=['background_image_name'], inplace=True)
train_data.drop(columns=['postscript_name'], inplace=True)
test_data.drop(columns=['postscript_name'], inplace=True)
train_data.drop(columns=['text'], inplace=True)
test_data.drop(columns=['text'], inplace=True)
train_data.drop(columns=['FILE_NAME'], inplace=True)
test_data.drop(columns=['FILE_NAME'], inplace=True)
train_data.drop(columns=['outline'], inplace=True)
test_data.drop(columns=['outline'], inplace=True)
train_data.drop(columns=['font_file'], inplace=True)
test_data.drop(columns=['font_file'], inplace=True)
train_data.drop(columns=['foreground_image_name'], inplace=True)
test_data.drop(columns=['foreground_image_name'], inplace=True)
train_data.drop(columns=['SUPER_CATEGORY'], inplace=True)
test_data.drop(columns=['SUPER_CATEGORY'], inplace=True)
train_data.drop(columns=['variable_font_weight'], inplace=True)
test_data.drop(columns=['variable_font_weight'], inplace=True)

X_train = train_data.drop(columns=['CATEGORY'])
y_train = train_data['CATEGORY']
X_test = test_data.drop(columns=['CATEGORY'])
y_test = test_data['CATEGORY']

for column in X_train.columns:
    X_train[column] = pd.to_numeric(X_train[column], errors='coerce')
for column in X_test.columns:
    X_test[column] = pd.to_numeric(X_test[column], errors='coerce')

X_train = X_train.fillna(X_train.mean())
X_test = X_test.fillna(X_test.mean())

trn = RandomForestRegressor(max_leaf_nodes=500)
trn.fit(X_train, y_train)

Train_R_Squared = r2_score(y_train, trn.predict(X_train))
Test_R_Squared = r2_score(y_test, trn.predict(X_test))

Train_RMSE = mean_squared_error(y_train, trn.predict(X_train), squared=False)
Test_RMSE = mean_squared_error(y_test, trn.predict(X_test), squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")
# ```end