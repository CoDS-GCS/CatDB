# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
import numpy as np

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

combined_data = pd.concat([train_data, test_data])

def augment_data(df):
    df_augmented = df.copy()
    # Example: Adding Gaussian noise to numerical features
    for col in df.select_dtypes(include=['float64', 'int64']):
        noise = np.random.normal(0, df[col].std(), len(df))
        df_augmented[col + '_augmented'] = df[col] + noise
    return df_augmented

train_data = augment_data(train_data)
test_data = augment_data(test_data)

def encode_categorical(df, columns):
    df_encoded = pd.get_dummies(df, columns=columns, drop_first=True)
    return df_encoded

columns_to_encode = ['variable_font_weight']
train_data = encode_categorical(train_data, columns_to_encode)
test_data = encode_categorical(test_data, columns_to_encode)

def add_features(df):
    # (Feature name and description) 
    # ratio_of_image_dimensions
    # Usefulness: (The ratio of original image width and height could contain information about the category of the character.) 
    df['ratio_of_image_dimensions'] = df['original_image_width_resolution'] / df['original_image_height_resolution']
    return df

train_data = add_features(train_data)
test_data = add_features(test_data)

train_data.drop(columns=['FILE_NAME'], inplace=True)
test_data.drop(columns=['FILE_NAME'], inplace=True)

X_train = train_data.drop(columns=['CATEGORY', 'text', 'stroke_fill', 'background_color', 'image_blending_method', 'family_name', 'style_name', 'foreground', 'perspective_params', 'background', 'outline_image_name', 'background_image_name', 'postscript_name', 'outline', 'font_file', 'foreground_image_name', 'SUPER_CATEGORY'])
y_train = train_data['CATEGORY']
X_test = test_data.drop(columns=['CATEGORY', 'text', 'stroke_fill', 'background_color', 'image_blending_method', 'family_name', 'style_name', 'foreground', 'perspective_params', 'background', 'outline_image_name', 'background_image_name', 'postscript_name', 'outline', 'font_file', 'foreground_image_name', 'SUPER_CATEGORY'])
y_test = test_data['CATEGORY']

X_train = X_train.apply(pd.to_numeric, errors='coerce')
X_test = X_test.apply(pd.to_numeric, errors='coerce')

X_train.fillna(X_train.median(), inplace=True)
X_test.fillna(X_test.median(), inplace=True)






trn = RandomForestRegressor(max_leaf_nodes=500, random_state=42)
trn.fit(X_train, y_train)

Train_R_Squared = r2_score(y_train, trn.predict(X_train))
Train_RMSE = mean_squared_error(y_train, trn.predict(X_train), squared=False)
Test_R_Squared = r2_score(y_test, trn.predict(X_test))
Test_RMSE = mean_squared_error(y_test, trn.predict(X_test), squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")   
print(f"Train_RMSE:{Train_RMSE}") 
print(f"Test_R_Squared:{Test_R_Squared}")   
print(f"Test_RMSE:{Test_RMSE}") 
# ```end