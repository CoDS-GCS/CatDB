# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

combined_data = pd.concat([train_data, test_data])

def encode_boolean_features(df, column_name):
    """
    # Feature name and description: Encoded {column_name}
    # Usefulness: One-hot encoding converts boolean features into a format suitable for machine learning algorithms.
    """
    df[column_name] = df[column_name].astype(int)
    return df

combined_data = encode_boolean_features(combined_data, 'variable_font_weight')

train_data = combined_data.iloc[:len(train_data)]
test_data = combined_data.iloc[len(train_data):]

features = ['variable_font_weight']
target = 'CATEGORY'

X_train = train_data[features]
y_train = train_data[target]
X_test = test_data[features]
y_test = test_data[target]

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

trn = RandomForestRegressor(max_leaf_nodes=500, n_jobs=-1)
trn.fit(X_train, y_train)

y_pred_train = trn.predict(X_train)
y_pred_test = trn.predict(X_test)

Train_R_Squared = r2_score(y_train, y_pred_train)
Train_RMSE = mean_squared_error(y_train, y_pred_train, squared=False)
Test_R_Squared = r2_score(y_test, y_pred_test)
Test_RMSE = mean_squared_error(y_test, y_pred_test, squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")
# ```end