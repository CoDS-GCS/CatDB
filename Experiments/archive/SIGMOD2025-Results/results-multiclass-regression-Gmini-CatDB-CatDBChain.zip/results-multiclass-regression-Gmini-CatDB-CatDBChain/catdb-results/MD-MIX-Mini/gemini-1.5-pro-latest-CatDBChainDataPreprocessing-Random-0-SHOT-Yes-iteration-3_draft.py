# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.compose import make_column_transformer
from sklearn.impute import SimpleImputer

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

categorical_features = ['image_blending_method', 'style_name', 'foreground', 'background', 'outline_image_name', 'background_image_name', 'outline', 'foreground_image_name', 'SUPER_CATEGORY', 'variable_font_weight']
numerical_features = ['brightness', 'contrast', 'rotation', 'color_enhance', 'shear_x', 'shear_y', 'offset_vertical', 'background_image_resized_height', 'foreground_image_crop_x_plus_width', 'offset_horizontal', 'outline_image_crop_x_plus_width', 'original_image_height_resolution', 'outline_image_crop_y_plus_height', 'foreground_image_crop_x', 'outline_image_resized_width', 'background_image_crop_y', 'outline_size', 'background_image_resized_width', 'background_image_crop_x', 'background_image_crop_x_plus_width', 'foreground_image_crop_y', 'outline_image_crop_x', 'foreground_image_resized_height', 'background_image_original_width', 'foreground_image_original_height', 'original_image_width_resolution', 'outline_image_original_width', 'outline_image_original_height', 'foreground_image_original_width', 'foreground_image_resized_width', 'foreground_image_crop_y_plus_height', 'background_image_original_height', 'outline_image_crop_y', 'background_image_crop_y_plus_height', 'outline_image_resized_height']

preprocessor = make_column_transformer(
    (OneHotEncoder(handle_unknown='ignore'), categorical_features),
    (SimpleImputer(), numerical_features),
    remainder='passthrough'
)

pipeline = Pipeline(
    steps=[
        ('preprocessor', preprocessor)
    ],
    verbose=True,
)
# ```end