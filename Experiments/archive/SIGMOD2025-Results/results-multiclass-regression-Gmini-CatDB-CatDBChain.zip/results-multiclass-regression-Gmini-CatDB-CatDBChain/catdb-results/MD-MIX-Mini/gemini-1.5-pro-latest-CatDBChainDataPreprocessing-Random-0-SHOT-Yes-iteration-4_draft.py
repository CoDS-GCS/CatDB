# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.compose import make_column_selector as selector
from sklearn.model_selection import train_test_split
from joblib import Parallel, delayed
from sklearn.preprocessing import FunctionTransformer
import numpy as np

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

categorical_features = ['variable_font_weight']
numerical_features = train_data.columns.drop(categorical_features + ['CATEGORY']).tolist()

def augment_data(df):
    df_augmented = df.copy()
    # Example: Add random Gaussian noise to numerical features
    for feature in numerical_features:
        if df_augmented[feature].dtype in ['int64', 'float64']:
            df_augmented[feature] = df_augmented[feature] + 0.01 * df_augmented[feature].std() * np.random.randn(len(df_augmented))
    return pd.concat([df, df_augmented])

preprocessor = ColumnTransformer(
    transformers=[
        ('numerical', 'passthrough', numerical_features),
        ('categorical', OneHotEncoder(handle_unknown='ignore'), categorical_features)
    ])

pipeline = Pipeline([
    ('augmentation', FunctionTransformer(augment_data)),
    ('preprocessor', preprocessor)
])
# ```end