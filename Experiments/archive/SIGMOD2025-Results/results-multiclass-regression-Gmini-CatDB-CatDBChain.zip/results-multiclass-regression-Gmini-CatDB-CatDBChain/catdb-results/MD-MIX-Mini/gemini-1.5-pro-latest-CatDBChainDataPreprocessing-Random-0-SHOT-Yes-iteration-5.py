# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.multioutput import MultiOutputClassifier
from sklearn.linear_model import LogisticRegression
from joblib import Parallel, delayed

categorical_features = ['variable_font_weight']
numerical_features = ['brightness', 'contrast', 'rotation', 'color_enhance', 'shear_x', 'shear_y', 'offset_vertical', 'foreground_image_crop_x_plus_width', 'offset_horizontal', 'outline_image_crop_x_plus_width', 'original_image_height_resolution', 'outline_image_crop_y_plus_height', 'foreground_image_crop_x', 'outline_image_resized_width', 'background_image_crop_y', 'outline_size', 'background_image_resized_width', 'background_image_crop_x', 'background_image_crop_x_plus_width', 'foreground_image_crop_y', 'outline_image_crop_x', 'foreground_image_resized_height', 'background_image_original_width', 'foreground_image_original_height', 'original_image_width_resolution', 'outline_image_original_width', 'outline_image_original_height', 'foreground_image_original_width', 'foreground_image_resized_width', 'foreground_image_crop_y_plus_height', 'background_image_original_height', 'outline_image_crop_y', 'background_image_crop_y_plus_height', 'outline_image_resized_height']

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numerical_features),
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
    ])

def process_data(data):
    X = data.drop('CATEGORY', axis=1)
    y = data['CATEGORY']
    X = preprocessor.fit_transform(X)
    return X, y

n_jobs = -1  # Use all available cores
train_results = Parallel(n_jobs=n_jobs)(delayed(process_data)(train_data) for _ in range(1))  # Assuming single data augmentation
X_train, y_train = train_results[0]

test_results = Parallel(n_jobs=n_jobs)(delayed(process_data)(test_data) for _ in range(1))
X_test, y_test = test_results[0]
# ```end