# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.multioutput import MultiOutputRegressor
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import FunctionTransformer
from joblib import Parallel, delayed

categorical_features = ['variable_font_weight']
numerical_features = ['brightness', 'contrast', 'rotation', 'color_enhance', 'shear_x', 'shear_y', 'offset_vertical', 'foreground_image_crop_x_plus_width', 'offset_horizontal', 'outline_image_crop_x_plus_width', 'original_image_height_resolution', 'outline_image_crop_y_plus_height', 'foreground_image_crop_x', 'outline_image_resized_width', 'background_image_crop_y', 'outline_size', 'background_image_resized_width', 'background_image_crop_x', 'background_image_crop_x_plus_width', 'foreground_image_crop_y', 'outline_image_crop_x', 'foreground_image_resized_height', 'background_image_original_width', 'foreground_image_original_height', 'original_image_width_resolution', 'outline_image_original_width', 'outline_image_original_height', 'foreground_image_original_width', 'foreground_image_resized_width', 'foreground_image_crop_y_plus_height', 'background_image_original_height', 'outline_image_crop_y', 'background_image_crop_y_plus_height', 'outline_image_resized_height']

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

def feature_engineering(data):
    # Example feature: ratio of original image width to height
    data['image_ratio'] = data['original_image_width_resolution'] / data['original_image_height_resolution']
    
    # Example feature: difference between foreground and background crop sizes
    data['crop_size_diff'] = (data['foreground_image_crop_x_plus_width'] - data['foreground_image_crop_x']) - (data['background_image_crop_x_plus_width'] - data['background_image_crop_x'])
    
    return data

preprocessor = ColumnTransformer(
    transformers=[
        ('num', Pipeline([
            ('imputer', SimpleImputer(strategy='mean')),
            ('scaler', StandardScaler())
        ]), numerical_features + ['image_ratio', 'crop_size_diff']),
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
    ])

model = MultiOutputRegressor(LinearRegression())

pipeline = Pipeline([
    ('feature_eng', FunctionTransformer(feature_engineering)),
    ('preprocessor', preprocessor),
    ('model', model)
])
