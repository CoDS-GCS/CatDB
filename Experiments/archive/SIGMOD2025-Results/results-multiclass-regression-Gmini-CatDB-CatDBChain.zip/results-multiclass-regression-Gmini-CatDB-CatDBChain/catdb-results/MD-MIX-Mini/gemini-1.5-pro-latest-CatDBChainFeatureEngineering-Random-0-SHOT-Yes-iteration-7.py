# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from multiprocessing import cpu_count
from sklearn.utils.parallel import Parallel, delayed

categorical_cols = ['variable_font_weight', 'image_blending_method', 'style_name', 'foreground', 'background', 'outline_image_name', 'background_image_name', 'outline', 'foreground_image_name', 'SUPER_CATEGORY']

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_cols)
    ],
    remainder='passthrough'
)

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

X_train = train_data.drop('CATEGORY', axis=1)
y_train = train_data['CATEGORY']
X_test = test_data.drop('CATEGORY', axis=1)
y_test = test_data['CATEGORY']

n_jobs = cpu_count()

def process_data(X, y):
    # Fit and transform the data using the preprocessor
    X_transformed = preprocessor.fit_transform(X)
    return X_transformed, y

X_train_transformed, y_train = process_data(X_train, y_train)

X_test_transformed, y_test = process_data(X_test, y_test)
# ```end