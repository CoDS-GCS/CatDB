# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import FunctionTransformer
from sklearn.pipeline import FeatureUnion

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

categorical_features = ['variable_font_weight']
numerical_features = ['brightness', 'contrast', 'rotation', 'color_enhance', 'shear_x', 'shear_y', 'offset_vertical', 
                       'foreground_image_crop_x_plus_width', 'offset_horizontal', 'outline_image_crop_x_plus_width', 
                       'original_image_height_resolution', 'outline_image_crop_y_plus_height', 'foreground_image_crop_x', 
                       'background_image_crop_y', 'outline_size', 'background_image_crop_x', 
                       'background_image_crop_x_plus_width', 'foreground_image_crop_y', 'outline_image_crop_x', 
                       'original_image_width_resolution', 'foreground_image_crop_y_plus_height', 
                       'outline_image_crop_y', 'background_image_crop_y_plus_height']

def combine_features(X):
    X['combined_crop_area'] = X['foreground_image_crop_x_plus_width'] * X['foreground_image_crop_y_plus_height']
    return X

combined_features = Pipeline([
    ('combiner', FunctionTransformer(combine_features)),
    ('num', SimpleImputer(strategy='mean'))
])

categorical_pipeline = Pipeline([
    ('encoder', OneHotEncoder(handle_unknown='ignore'))
])

numerical_pipeline = Pipeline([
    ('imputer', SimpleImputer(strategy='mean')),
    ('scaler', StandardScaler())
])

preprocessor = ColumnTransformer([
    ('categorical', categorical_pipeline, categorical_features),
    ('numerical', numerical_pipeline, numerical_features),
    ('combined', combined_features, numerical_features)
])

pipeline = Pipeline([
    ('preprocessor', preprocessor)
])

X_train = train_data.drop('CATEGORY', axis=1)
y_train = train_data['CATEGORY']

pipeline.fit(X_train, y_train)
# ```end