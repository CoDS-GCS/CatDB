# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from joblib import Parallel, delayed

categorical_features = ['variable_font_weight']
numerical_features = ['brightness', 'contrast', 'rotation', 'color_enhance', 'shear_x', 'shear_y', 'offset_vertical', 'foreground_image_crop_x_plus_width', 'offset_horizontal', 'outline_image_crop_x_plus_width', 'original_image_height_resolution', 'outline_image_crop_y_plus_height', 'foreground_image_crop_x', 'outline_image_resized_width', 'background_image_crop_y', 'outline_size', 'background_image_resized_width', 'background_image_crop_x', 'background_image_crop_x_plus_width', 'foreground_image_crop_y', 'outline_image_crop_x', 'foreground_image_resized_height', 'background_image_original_width', 'foreground_image_original_height', 'original_image_width_resolution', 'outline_image_original_width', 'outline_image_original_height', 'foreground_image_original_width', 'foreground_image_resized_width', 'foreground_image_crop_y_plus_height', 'background_image_original_height', 'outline_image_crop_y', 'background_image_crop_y_plus_height', 'outline_image_resized_height']
drop_features = ['stroke_fill', 'background_color', 'image_blending_method', 'family_name', 'style_name', 'foreground', 'perspective_params', 'background', 'outline_image_name', 'background_image_name', 'postscript_name', 'text', 'FILE_NAME', 'outline', 'font_file', 'foreground_image_name', 'SUPER_CATEGORY']

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

def process_data(data):
    # Drop features
    data = data.drop(columns=drop_features)
    
    # Create the preprocessing pipelines for both numerical and categorical data.
    numerical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])

    categorical_transformer = Pipeline(steps=[
        ('onehot', OneHotEncoder(handle_unknown='ignore'))
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numerical_transformer, numerical_features),
            ('cat', categorical_transformer, categorical_features)
        ])

    # Fit and transform the data
    data_processed = preprocessor.fit_transform(data)
    return data_processed

n_jobs = -1  # Use all available cores
train_data_processed = Parallel(n_jobs=n_jobs)(delayed(process_data)(train_data) for _ in range(1))
test_data_processed = Parallel(n_jobs=n_jobs)(delayed(process_data)(test_data) for _ in range(1))
# ```end