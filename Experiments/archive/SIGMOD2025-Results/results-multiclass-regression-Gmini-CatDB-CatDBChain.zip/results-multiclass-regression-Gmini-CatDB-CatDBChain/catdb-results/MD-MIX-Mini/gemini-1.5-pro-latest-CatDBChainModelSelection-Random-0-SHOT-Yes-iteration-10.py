# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import r2_score, mean_squared_error
from joblib import Parallel, delayed

categorical_features = ['variable_font_weight']
numerical_features = ['brightness', 'contrast', 'rotation', 'color_enhance', 'shear_x', 'shear_y', 'offset_vertical', 'foreground_image_crop_x_plus_width', 'offset_horizontal', 'outline_image_crop_x_plus_width', 'original_image_height_resolution', 'outline_image_crop_y_plus_height', 'foreground_image_crop_x', 'outline_image_resized_width', 'background_image_crop_y', 'outline_size', 'background_image_resized_width', 'background_image_crop_x', 'background_image_crop_x_plus_width', 'foreground_image_crop_y', 'outline_image_crop_x', 'foreground_image_resized_height', 'background_image_original_width', 'foreground_image_original_height', 'original_image_width_resolution', 'outline_image_original_width', 'outline_image_original_height', 'foreground_image_original_width', 'foreground_image_resized_width', 'foreground_image_crop_y_plus_height', 'background_image_original_height', 'outline_image_crop_y', 'background_image_crop_y_plus_height', 'outline_image_resized_height']
drop_features = ['stroke_fill', 'background_color', 'image_blending_method', 'family_name', 'style_name', 'foreground', 'perspective_params', 'background', 'outline_image_name', 'background_image_name', 'postscript_name', 'text', 'FILE_NAME', 'outline', 'font_file', 'foreground_image_name', 'SUPER_CATEGORY']

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

def feature_engineering(data):
    data['image_size_ratio'] = data['original_image_width_resolution'] / data['original_image_height_resolution']
    data['foreground_crop_ratio'] = (data['foreground_image_crop_x_plus_width'] - data['foreground_image_crop_x']) / (data['foreground_image_crop_y_plus_height'] - data['foreground_image_crop_y'])
    data['background_crop_ratio'] = (data['background_image_crop_x_plus_width'] - data['background_image_crop_x']) / (data['background_image_crop_y_plus_height'] - data['background_image_crop_y'])
    return data

def process_data(data):
    data = feature_engineering(data)
    data = data.drop(drop_features, axis=1)
    X = data.drop("CATEGORY", axis=1)
    y = data["CATEGORY"]
    
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numerical_features),
            ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
        ])
    X_processed = preprocessor.fit_transform(X)
    return X_processed, y

results = Parallel(n_jobs=-1)(delayed(process_data)(data) for data in [train_data, test_data])

X_train_processed, y_train = results[0]
X_test_processed, y_test = results[1]

model = RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1)
model.fit(X_train_processed, y_train)

y_train_pred = model.predict(X_train_processed)
y_test_pred = model.predict(X_test_processed)

Train_R_Squared = r2_score(y_train, y_train_pred)
Test_R_Squared = r2_score(y_test, y_test_pred)

Train_RMSE = mean_squared_error(y_train, y_train_pred, squared=False)
Test_RMSE = mean_squared_error(y_test, y_test_pred, squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")   
print(f"Train_RMSE:{Train_RMSE}") 
print(f"Test_R_Squared:{Test_R_Squared}")   
print(f"Test_RMSE:{Test_RMSE}") 
# ```end