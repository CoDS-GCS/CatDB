# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.compose import ColumnTransformer, make_column_selector
from sklearn.pipeline import FeatureUnion
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.impute import SimpleImputer

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

categorical_features = ['variable_font_weight', 'image_blending_method', 'style_name', 'foreground', 'background', 'outline_image_name', 'background_image_name', 'outline', 'foreground_image_name', 'SUPER_CATEGORY']
numerical_features = ['brightness', 'contrast', 'rotation', 'color_enhance', 'shear_x', 'shear_y', 'offset_vertical', 'foreground_image_crop_x_plus_width', 'offset_horizontal', 'outline_image_crop_x_plus_width', 'original_image_height_resolution', 'outline_image_crop_y_plus_height', 'foreground_image_crop_x', 'background_image_crop_y', 'background_image_crop_x', 'background_image_crop_x_plus_width', 'foreground_image_crop_y', 'outline_image_crop_x', 'original_image_width_resolution', 'foreground_image_crop_y_plus_height', 'outline_image_crop_y', 'background_image_crop_y_plus_height']

preprocessor = ColumnTransformer(
    transformers=[
        ('num', Pipeline([
            ('imputer', SimpleImputer(strategy='mean')),
            ('scaler', StandardScaler())
        ]), make_column_selector(dtype_include=['float64', 'int64'])),
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
    ],
    remainder='drop'
)

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1))
])

X_train = train_data.drop("CATEGORY", axis=1)
y_train = train_data["CATEGORY"]
X_test = test_data.drop("CATEGORY", axis=1)
y_test = test_data["CATEGORY"]

pipeline.fit(X_train, y_train)

y_train_pred = pipeline.predict(X_train)
y_test_pred = pipeline.predict(X_test)

Train_R_Squared = r2_score(y_train, y_train_pred)
Train_RMSE = mean_squared_error(y_train, y_train_pred, squared=False)
Test_R_Squared = r2_score(y_test, y_test_pred)
Test_RMSE = mean_squared_error(y_test, y_test_pred, squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")   
print(f"Train_RMSE:{Train_RMSE}") 
print(f"Test_R_Squared:{Test_R_Squared}")   
print(f"Test_RMSE:{Test_RMSE}") 
# ```end