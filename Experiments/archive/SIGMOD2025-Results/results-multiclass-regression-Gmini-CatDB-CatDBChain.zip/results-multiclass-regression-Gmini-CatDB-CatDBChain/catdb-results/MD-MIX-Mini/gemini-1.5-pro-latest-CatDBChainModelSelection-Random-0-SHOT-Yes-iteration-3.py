# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.compose import make_column_transformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, f_classif
from joblib import Parallel, delayed
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import r2_score, mean_squared_error

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

categorical_features = ['image_blending_method', 'style_name', 'foreground', 'background', 'outline_image_name', 'background_image_name', 'outline', 'foreground_image_name', 'SUPER_CATEGORY']
numerical_features = ['brightness', 'contrast', 'rotation', 'color_enhance', 'shear_x', 'shear_y', 'offset_vertical', 'background_image_resized_height', 'foreground_image_crop_x_plus_width', 'offset_horizontal', 'outline_image_crop_x_plus_width', 'original_image_height_resolution', 'outline_image_crop_y_plus_height', 'foreground_image_crop_x', 'outline_image_resized_width', 'background_image_crop_y', 'outline_size', 'background_image_resized_width', 'background_image_crop_x', 'background_image_crop_x_plus_width', 'foreground_image_crop_y', 'outline_image_crop_x', 'foreground_image_resized_height', 'background_image_original_width', 'foreground_image_original_height', 'original_image_width_resolution', 'outline_image_original_width', 'outline_image_original_height', 'foreground_image_original_width', 'foreground_image_resized_width', 'foreground_image_crop_y_plus_height', 'background_image_original_height', 'outline_image_crop_y', 'background_image_crop_y_plus_height', 'outline_image_resized_height']
boolean_features = ['variable_font_weight']

def process_dataset(data):
    # Example: Combine width and height features to create area features
    data['outline_image_area'] = data['outline_image_resized_width'] * data['outline_image_resized_height']
    data['background_image_area'] = data['background_image_resized_width'] * data['background_image_resized_height']
    data['foreground_image_area'] = data['foreground_image_resized_width'] * data['foreground_image_resized_height']

    return data

train_data = process_dataset(train_data)
test_data = process_dataset(test_data)

numerical_features.extend(['outline_image_area', 'background_image_area', 'foreground_image_area'])

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transformer = OneHotEncoder(handle_unknown='ignore')

boolean_transformer = OneHotEncoder(handle_unknown='ignore', drop='if_binary')

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features),
        ('bool', boolean_transformer, boolean_features)
    ])

pipeline = Pipeline(
    steps=[
        ('preprocessor', preprocessor),
        ('feature_selection', SelectKBest(f_classif, k=100)),  # Select top 100 features
        ('classifier', RandomForestClassifier(n_jobs=-1, max_leaf_nodes=500, random_state=42))
    ],
    verbose=True,
)

X_train = train_data.drop('CATEGORY', axis=1)
y_train = train_data['CATEGORY']
X_test = test_data.drop('CATEGORY', axis=1)
y_test = test_data['CATEGORY']

pipeline.fit(X_train, y_train)

y_train_pred = pipeline.predict(X_train)
y_test_pred = pipeline.predict(X_test)

Train_R_Squared = r2_score(y_train, y_train_pred)
Train_RMSE = mean_squared_error(y_train, y_train_pred, squared=False)

Test_R_Squared = r2_score(y_test, y_test_pred)
Test_RMSE = mean_squared_error(y_test, y_test_pred, squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")   
print(f"Train_RMSE:{Train_RMSE}") 
print(f"Test_R_Squared:{Test_R_Squared}")   
print(f"Test_RMSE:{Test_RMSE}") 
# ```end