# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from multiprocessing import cpu_count
from sklearn.utils.parallel import Parallel, delayed
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.impute import SimpleImputer

categorical_cols = ['variable_font_weight', 'image_blending_method', 'style_name', 'foreground', 'background', 'outline_image_name', 'background_image_name', 'outline', 'foreground_image_name', 'SUPER_CATEGORY','stroke_fill','background_color', 'perspective_params', 'family_name', 'postscript_name', 'text', 'font_file']

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', Pipeline([
            ('imputer', SimpleImputer(strategy='most_frequent')),
            ('onehot', OneHotEncoder(handle_unknown='ignore'))
        ]), categorical_cols)
    ],
    remainder='passthrough'
)

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

X_train = train_data.drop('CATEGORY', axis=1)
y_train = train_data['CATEGORY']
X_test = test_data.drop('CATEGORY', axis=1)
y_test = test_data['CATEGORY']

n_jobs = cpu_count()

def process_data(X, y):
    # Fit and transform the data using the preprocessor
    X = X.drop(columns=['FILE_NAME'])
    # Convert all columns to string type before applying OneHotEncoder
    for col in X.columns:
        if col in categorical_cols:
            X[col] = X[col].astype(str)
        else:
            X[col] = pd.to_numeric(X[col], errors='coerce')
    X_transformed = preprocessor.fit_transform(X)
    return X_transformed, y

X_train_transformed, y_train = process_data(X_train.copy(), y_train)

preprocessor.fit(X_train_transformed)

X_test_transformed, y_test = process_data(X_test.copy(), y_test)

model = RandomForestClassifier(max_leaf_nodes=500, n_jobs=n_jobs)
model.fit(X_train_transformed, y_train)

y_train_pred = model.predict(X_train_transformed)
y_test_pred = model.predict(X_test_transformed)

Train_R_Squared = r2_score(y_train, y_train_pred)
Test_R_Squared = r2_score(y_test, y_test_pred)

Train_RMSE = mean_squared_error(y_train, y_train_pred, squared=False)
Test_RMSE = mean_squared_error(y_test, y_test_pred, squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")   
print(f"Train_RMSE:{Train_RMSE}") 
print(f"Test_R_Squared:{Test_R_Squared}")   
print(f"Test_RMSE:{Test_RMSE}") 
# ```end