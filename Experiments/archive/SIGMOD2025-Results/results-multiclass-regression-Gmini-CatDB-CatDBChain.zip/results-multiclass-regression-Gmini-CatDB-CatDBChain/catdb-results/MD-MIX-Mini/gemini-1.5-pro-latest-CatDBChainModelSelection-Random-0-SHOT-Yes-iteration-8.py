# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import FunctionTransformer
from sklearn.pipeline import FeatureUnion
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error

train_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_train.csv")
test_data = pd.read_csv("../../../data/MD-MIX-Mini/MD-MIX-Mini_test.csv")

categorical_features = ['variable_font_weight']
numerical_features = ['brightness', 'contrast', 'rotation', 'color_enhance', 'shear_x', 'shear_y', 'offset_vertical', 
                       'foreground_image_crop_x_plus_width', 'offset_horizontal', 'outline_image_crop_x_plus_width', 
                       'original_image_height_resolution', 'outline_image_crop_y_plus_height', 'foreground_image_crop_x', 
                       'background_image_crop_y', 'outline_size', 'background_image_crop_x', 
                       'background_image_crop_x_plus_width', 'foreground_image_crop_y', 'outline_image_crop_x', 
                       'original_image_width_resolution', 'foreground_image_crop_y_plus_height', 
                       'outline_image_crop_y', 'background_image_crop_y_plus_height']

def combine_features(X):
    X['combined_crop_area'] = X['foreground_image_crop_x_plus_width'] * X['foreground_image_crop_y_plus_height']
    return X

combined_features = Pipeline([
    ('combiner', FunctionTransformer(combine_features)),
    ('num', SimpleImputer(strategy='mean'))
])

categorical_pipeline = Pipeline([
    ('encoder', OneHotEncoder(handle_unknown='ignore'))
])

numerical_pipeline = Pipeline([
    ('imputer', SimpleImputer(strategy='mean')),
    ('scaler', StandardScaler())
])

preprocessor = ColumnTransformer([
    ('categorical', categorical_pipeline, categorical_features),
    ('numerical', numerical_pipeline, numerical_features),
    ('combined', combined_features, numerical_features)
])

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('regressor', RandomForestRegressor(n_jobs=-1, max_leaf_nodes=500))
])

X_train = train_data.drop('CATEGORY', axis=1)
y_train = train_data['CATEGORY']
X_test = test_data.drop('CATEGORY', axis=1)
y_test = test_data['CATEGORY']

pipeline.fit(X_train, y_train)

y_train_pred = pipeline.predict(X_train)
y_test_pred = pipeline.predict(X_test)

Train_R_Squared = r2_score(y_train, y_train_pred)
Train_RMSE = mean_squared_error(y_train, y_train_pred, squared=False)
Test_R_Squared = r2_score(y_test, y_test_pred)
Test_RMSE = mean_squared_error(y_test, y_test_pred, squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")   
print(f"Train_RMSE:{Train_RMSE}") 
print(f"Test_R_Squared:{Test_R_Squared}")   
print(f"Test_RMSE:{Test_RMSE}") 
# ```end