# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import r2_score, mean_squared_error

df = pd.read_csv('FILE_NAME.csv') 
X = df.drop('CATEGORY', axis=1)
y = df['CATEGORY']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1)
model.fit(X_train, y_train)

Train_R_Squared = r2_score(y_train, model.predict(X_train))
Train_RMSE = mean_squared_error(y_train, model.predict(X_train), squared=False)

Test_R_Squared = r2_score(y_test, model.predict(X_test))
Test_RMSE = mean_squared_error(y_test, model.predict(X_test), squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")
# ```end