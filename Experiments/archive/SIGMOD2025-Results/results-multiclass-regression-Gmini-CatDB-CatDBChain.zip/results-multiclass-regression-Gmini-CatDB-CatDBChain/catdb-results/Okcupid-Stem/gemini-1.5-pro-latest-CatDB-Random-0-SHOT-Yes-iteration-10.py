# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score

train_data = pd.read_csv("../../../data/Okcupid-Stem/Okcupid-Stem_train.csv")
test_data = pd.read_csv("../../../data/Okcupid-Stem/Okcupid-Stem_test.csv")

combined_data = pd.concat([train_data, test_data], axis=0)

encoder = OneHotEncoder(handle_unknown='ignore')
for col in ['income', 'body_type', 'ethnicity']:
    # Fit on the combined data to handle unseen values
    encoder.fit(combined_data[[col]])
    
    # Transform training data
    train_encoded = pd.DataFrame(encoder.transform(train_data[[col]]).toarray(), 
                                  columns=[f"{col}_{cat}" for cat in encoder.categories_[0]])
    train_data = train_data.drop(columns=[col]).reset_index(drop=True)
    train_data = pd.concat([train_data, train_encoded], axis=1)
    
    # Transform test data
    test_encoded = pd.DataFrame(encoder.transform(test_data[[col]]).toarray(), 
                                 columns=[f"{col}_{cat}" for cat in encoder.categories_[0]])
    test_data = test_data.drop(columns=[col]).reset_index(drop=True)
    test_data = pd.concat([test_data, test_encoded], axis=1)

def family_affinity(df):
    """
    # family_affinity 
    # Usefulness: People with kids or who want kids and have pets might be less likely to have a STEM job due to family-time constraints.
    """
    df['family_affinity'] = ((df['offspring'].str.contains('has|wants', na=False)) & (df['pets'].str.contains('has', na=False))).astype(int)
    return df

train_data = family_affinity(train_data)
test_data = family_affinity(test_data)

columns_to_drop = ['offspring', 'pets']  # Example
for column in columns_to_drop:
    # Explanation why the column XX is dropped
    # These columns are being dropped as we're creating a new, engineered feature 'family_affinity' that encapsulates the key information from these columns. 
    # This reduces dimensionality and potential multicollinearity.
    train_data.drop(columns=[column], inplace=True)
    test_data.drop(columns=[column], inplace=True)

X_train = train_data.drop(columns=['job'])
y_train = train_data['job']
X_test = test_data.drop(columns=['job'])
y_test = test_data['job']

X_train = pd.get_dummies(X_train)
X_test = pd.get_dummies(X_test)

X_train, X_test = X_train.align(X_test, join='outer', axis=1, fill_value=0)

trn = RandomForestClassifier(max_leaf_nodes=500, random_state=42)
trn.fit(X_train, y_train)

train_predictions = trn.predict(X_train)
test_predictions = trn.predict(X_test)

Train_Accuracy = accuracy_score(y_train, train_predictions)
Test_Accuracy = accuracy_score(y_test, test_predictions)

Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, trn.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovr')
Test_AUC_OVO = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end