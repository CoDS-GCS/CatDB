# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

train_data = pd.read_csv("../../../data/Okcupid-Stem/Okcupid-Stem_train.csv")
test_data = pd.read_csv("../../../data/Okcupid-Stem/Okcupid-Stem_test.csv")



ohe = OneHotEncoder(handle_unknown='ignore')
ohe.fit(pd.concat([train_data[['income']], test_data[['income']]]))
income_encoded = pd.DataFrame(ohe.transform(train_data[['income']]).toarray(), columns=ohe.get_feature_names_out(['income']))
train_data = train_data.drop('income', axis=1).join(income_encoded)
income_encoded = pd.DataFrame(ohe.transform(test_data[['income']]).toarray(), columns=ohe.get_feature_names_out(['income']))
test_data = test_data.drop('income', axis=1).join(income_encoded)

for column in train_data.columns:
    if column not in ['body_type', 'job']:
        try:
            train_data[column] = pd.to_numeric(train_data[column])
        except:
            print(f"Column {column} cannot be converted to numeric")
for column in test_data.columns:
    if column not in ['body_type', 'job']:
        try:
            test_data[column] = pd.to_numeric(test_data[column])
        except:
            print(f"Column {column} cannot be converted to numeric")

X_train = train_data.drop(columns=['job'])
y_train = train_data['job']
X_test = test_data.drop(columns=['job'])
y_test = test_data['job']

combined_data = pd.concat([X_train, X_test])
combined_data = pd.get_dummies(combined_data)

X_train = combined_data.iloc[:len(X_train)]
X_test = combined_data.iloc[len(X_train):]

trn = RandomForestClassifier(max_leaf_nodes=500)
trn.fit(X_train, y_train)

Train_Accuracy = accuracy_score(y_train, trn.predict(X_train))
Test_Accuracy = accuracy_score(y_test, trn.predict(X_test))
Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, trn.predict_proba(X_test))
Train_AUC_OVO = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovo')
Test_AUC_OVO = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovr')
Test_AUC_OVR = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovr')
print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end