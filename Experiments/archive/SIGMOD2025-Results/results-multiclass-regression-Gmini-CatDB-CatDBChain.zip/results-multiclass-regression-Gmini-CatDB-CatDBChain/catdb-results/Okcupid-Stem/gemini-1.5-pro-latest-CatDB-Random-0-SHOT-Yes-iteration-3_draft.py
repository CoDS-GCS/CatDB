# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score

train_data = pd.read_csv("../../../data/Okcupid-Stem/Okcupid-Stem_train.csv")
test_data = pd.read_csv("../../../data/Okcupid-Stem/Okcupid-Stem_test.csv")



encoder = OneHotEncoder(handle_unknown='ignore')
encoder.fit(pd.concat([train_data[['income']], test_data[['income']]]))
train_income_encoded = encoder.transform(train_data[['income']]).toarray()
test_income_encoded = encoder.transform(test_data[['income']]).toarray()
train_income_df = pd.DataFrame(train_income_encoded, columns=[f'income_{i}' for i in range(train_income_encoded.shape[1])])
test_income_df = pd.DataFrame(test_income_encoded, columns=[f'income_{i}' for i in range(test_income_encoded.shape[1])])
train_data = pd.concat([train_data, train_income_df], axis=1)
test_data = pd.concat([test_data, test_income_df], axis=1)

train_data['offspring_and_pets'] = train_data['offspring'].str.cat(train_data['pets'], sep='-').astype('category').cat.codes
test_data['offspring_and_pets'] = test_data['offspring'].str.cat(test_data['pets'], sep='-').astype('category').cat.codes

train_data.drop(columns=['offspring'], inplace=True)
test_data.drop(columns=['offspring'], inplace=True)
train_data.drop(columns=['pets'], inplace=True)
test_data.drop(columns=['pets'], inplace=True)
train_data.drop(columns=['income'], inplace=True)
test_data.drop(columns=['income'], inplace=True)

X_train = train_data.drop(columns=['job'])
y_train = train_data['job']
X_test = test_data.drop(columns=['job'])
y_test = test_data['job']

for column in X_train.columns:
    if X_train[column].dtype == 'object':
        X_train[column] = X_train[column].astype('category').cat.codes
        X_test[column] = X_test[column].astype('category').cat.codes

trn = RandomForestClassifier(max_leaf_nodes=500)
trn.fit(X_train, y_train)

Train_Accuracy = accuracy_score(y_train, trn.predict(X_train))
Test_Accuracy = accuracy_score(y_test, trn.predict(X_test))

Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, trn.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovr')
Test_AUC_OVO = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end