# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score
import numpy as np

train_data = pd.read_csv("../../../data/Okcupid-Stem/Okcupid-Stem_train.csv")
test_data = pd.read_csv("../../../data/Okcupid-Stem/Okcupid-Stem_test.csv")



ohe = OneHotEncoder(handle_unknown='ignore')
feature_cols = ['income']
ohe.fit(pd.concat([train_data[feature_cols], test_data[feature_cols]]))
feature_array_train = ohe.transform(train_data[feature_cols]).toarray()
feature_array_test = ohe.transform(test_data[feature_cols]).toarray()
feature_labels = np.array(ohe.categories_).ravel()
features_train = pd.DataFrame(feature_array_train, columns=feature_labels)
features_test = pd.DataFrame(feature_array_test, columns=feature_labels)
train_data = pd.concat([train_data, features_train], axis=1)
test_data = pd.concat([test_data, features_test], axis=1)


train_data.drop(columns=['income'], inplace=True)
test_data.drop(columns=['income'], inplace=True)

target_variable = 'job'

X_train = train_data.drop(columns=target_variable)
y_train = train_data[target_variable]
X_test = test_data.drop(columns=target_variable)
y_test = test_data[target_variable]

X_train = pd.get_dummies(X_train)
X_test = pd.get_dummies(X_test)
missing_cols = set(X_train.columns) - set(X_test.columns)
for c in missing_cols:
    X_test[c] = 0
X_test = X_test[X_train.columns]
X_train.columns = X_train.columns.astype(str)
X_test.columns = X_test.columns.astype(str)

trn = RandomForestClassifier(max_leaf_nodes=500)
trn.fit(X_train, y_train)

Train_Accuracy = accuracy_score(y_train, trn.predict(X_train))
Test_Accuracy = accuracy_score(y_test, trn.predict(X_test))

Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, trn.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovr')
Test_AUC_OVO = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end