# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score

train_data = pd.read_csv("../../../data/Okcupid-Stem/Okcupid-Stem_train.csv")
test_data = pd.read_csv("../../../data/Okcupid-Stem/Okcupid-Stem_test.csv")



ohe = OneHotEncoder(handle_unknown='ignore')
feature_cols = ['income']
ohe.fit(pd.concat([train_data[feature_cols], test_data[feature_cols]]))
train_ohe = ohe.transform(train_data[feature_cols]).toarray()
test_ohe = ohe.transform(test_data[feature_cols]).toarray()
train_data = train_data.drop(columns=feature_cols, axis=1)
test_data = test_data.drop(columns=feature_cols, axis=1)
train_data = pd.concat([train_data, pd.DataFrame(train_ohe, columns=[f"ohe_{i}" for i in range(train_ohe.shape[1])])], axis=1)
test_data = pd.concat([test_data, pd.DataFrame(test_ohe, columns=[f"ohe_{i}" for i in range(test_ohe.shape[1])])], axis=1)

def engineer_features(df):
    # offspring_pets
    # Usefulness: Combines information about offspring and pet preferences, which might reflect lifestyle choices and indirectly relate to job fields.
    df['offspring_pets'] = df['offspring'].astype(str) + '_' + df['pets'].astype(str)

    # drinks_smokes
    # Usefulness: Combines information about drinking and smoking habits, which might correlate with personality traits and social behaviors relevant to certain jobs.
    df['drinks_smokes'] = df['drinks'].astype(str) + '_' + df['smokes'].astype(str)
    return df

train_data = engineer_features(train_data.copy())
test_data = engineer_features(test_data.copy())

train_data.drop(columns=['offspring', 'pets', 'drinks', 'smokes'], inplace=True)
test_data.drop(columns=['offspring', 'pets', 'drinks', 'smokes'], inplace=True)

X_train = train_data.drop(columns=['job'])
y_train = train_data['job']
X_test = test_data.drop(columns=['job'])
y_test = test_data['job']

for col in X_train.columns:
    if col not in ['body_type', 'offspring_pets', 'drinks_smokes', 'speaks', 'ethnicity', 'education', 'sign', 'status', 'diet', 'religion', 'location', 'orientation', 'sex', 'height', 'age','ohe_0', 'ohe_1', 'ohe_2', 'ohe_3', 'ohe_4', 'ohe_5', 'ohe_6', 'ohe_7', 'ohe_8', 'ohe_9', 'ohe_10', 'ohe_11']:
        try:
            X_train[col] = X_train[col].astype(float)
        except:
            pass
for col in X_test.columns:
    if col not in ['body_type', 'offspring_pets', 'drinks_smokes', 'speaks', 'ethnicity', 'education', 'sign', 'status', 'diet', 'religion', 'location', 'orientation', 'sex', 'height', 'age', 'ohe_0', 'ohe_1', 'ohe_2', 'ohe_3', 'ohe_4', 'ohe_5', 'ohe_6', 'ohe_7', 'ohe_8', 'ohe_9', 'ohe_10', 'ohe_11']:
        try:
            X_test[col] = X_test[col].astype(float)
        except:
            pass

X = pd.concat([X_train, X_test])
X = pd.get_dummies(X)
X_train = X.iloc[:len(X_train)]
X_test = X.iloc[len(X_train):]

trn = RandomForestClassifier(max_leaf_nodes=500)

trn.fit(X_train, y_train)

train_preds = trn.predict(X_train)
test_preds = trn.predict(X_test)
train_proba = trn.predict_proba(X_train)
test_proba = trn.predict_proba(X_test)

Train_Accuracy = accuracy_score(y_train, train_preds)
Test_Accuracy = accuracy_score(y_test, test_preds)

Train_Log_loss = log_loss(y_train, train_proba)
Test_Log_loss = log_loss(y_test, test_proba)

Train_AUC_OVO = roc_auc_score(y_train, train_proba, multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, train_proba, multi_class='ovr')
Test_AUC_OVO = roc_auc_score(y_test, test_proba, multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, test_proba, multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end