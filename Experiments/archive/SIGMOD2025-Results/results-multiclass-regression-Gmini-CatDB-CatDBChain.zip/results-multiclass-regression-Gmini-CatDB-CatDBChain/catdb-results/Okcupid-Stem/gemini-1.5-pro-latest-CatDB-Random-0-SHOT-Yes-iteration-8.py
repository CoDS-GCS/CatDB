# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

train_data = pd.read_csv("../../../data/Okcupid-Stem/Okcupid-Stem_train.csv")
test_data = pd.read_csv("../../../data/Okcupid-Stem/Okcupid-Stem_test.csv")



combined_data = pd.concat([train_data, test_data])
encoder = OneHotEncoder(handle_unknown='ignore')
encoded_income = encoder.fit_transform(combined_data[['income']]).toarray()
encoded_income_df = pd.DataFrame(encoded_income, columns=[f"income_{i}" for i in range(encoded_income.shape[1])])
combined_data = pd.concat([combined_data.reset_index(drop=True), encoded_income_df], axis=1)

train_data = combined_data.iloc[:len(train_data)]
test_data = combined_data.iloc[len(train_data):].reset_index(drop=True)



features = ['income_0', 'income_1', 'income_2', 'income_3', 'income_4', 'income_5', 'income_6', 'income_7', 'income_8', 'income_9', 'income_10', 'income_11']
target = 'job'

