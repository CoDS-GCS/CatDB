# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score

train_data = pd.read_csv("../../../data/Okcupid-Stem/Okcupid-Stem_train.csv")
test_data = pd.read_csv("../../../data/Okcupid-Stem/Okcupid-Stem_test.csv")



ohe = OneHotEncoder(handle_unknown='ignore')
for col in ['income', 'orientation', 'sex']:
    # Fit the encoder on the combined data
    ohe.fit(pd.concat([train_data[[col]], test_data[[col]]]))
    # Transform the training data
    train_ohe = pd.DataFrame(ohe.transform(train_data[[col]]).toarray(), columns=[f'{col}_{c}' for c in ohe.categories_[0]])
    train_data = train_data.drop(columns=[col]).reset_index(drop=True)
    train_data = pd.concat([train_data, train_ohe], axis=1)
    # Transform the test data
    test_ohe = pd.DataFrame(ohe.transform(test_data[[col]]).toarray(), columns=[f'{col}_{c}' for c in ohe.categories_[0]])
    test_data = test_data.drop(columns=[col]).reset_index(drop=True)
    test_data = pd.concat([test_data, test_ohe], axis=1)


train_data.drop(columns=['offspring'], inplace=True)
test_data.drop(columns=['offspring'], inplace=True)
train_data.drop(columns=['pets'], inplace=True)
test_data.drop(columns=['pets'], inplace=True)
train_data.drop(columns=['drugs'], inplace=True)
test_data.drop(columns=['drugs'], inplace=True)
train_data.drop(columns=['speaks'], inplace=True)
test_data.drop(columns=['speaks'], inplace=True)
train_data.drop(columns=['ethnicity'], inplace=True)
test_data.drop(columns=['ethnicity'], inplace=True)
train_data.drop(columns=['smokes'], inplace=True)
test_data.drop(columns=['smokes'], inplace=True)
train_data.drop(columns=['drinks'], inplace=True)
test_data.drop(columns=['drinks'], inplace=True)
train_data.drop(columns=['education'], inplace=True)
test_data.drop(columns=['education'], inplace=True)
train_data.drop(columns=['sign'], inplace=True)
test_data.drop(columns=['sign'], inplace=True)
train_data.drop(columns=['status'], inplace=True)
test_data.drop(columns=['status'], inplace=True)
train_data.drop(columns=['diet'], inplace=True)
test_data.drop(columns=['diet'], inplace=True)
train_data.drop(columns=['religion'], inplace=True)
test_data.drop(columns=['religion'], inplace=True)
train_data.drop(columns=['location'], inplace=True)
test_data.drop(columns=['location'], inplace=True)
train_data.drop(columns=['body_type'], inplace=True)
test_data.drop(columns=['body_type'], inplace=True)

X_train = train_data.drop(columns=['job'])
y_train = train_data['job']
X_test = test_data.drop(columns=['job'])
y_test = test_data['job']

trn = RandomForestClassifier(max_leaf_nodes=500)
trn.fit(X_train, y_train)

y_pred_train = trn.predict(X_train)
y_pred_proba_train = trn.predict_proba(X_train)
y_pred_test = trn.predict(X_test)
y_pred_proba_test = trn.predict_proba(X_test)

Train_Accuracy = accuracy_score(y_train, y_pred_train)
Test_Accuracy = accuracy_score(y_test, y_pred_test)

Train_Log_loss = log_loss(y_train, y_pred_proba_train)
Test_Log_loss = log_loss(y_test, y_pred_proba_test)

Train_AUC_OVO = roc_auc_score(y_train, y_pred_proba_train, multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, y_pred_proba_train, multi_class='ovr')

Test_AUC_OVO = roc_auc_score(y_test, y_pred_proba_test, multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, y_pred_proba_test, multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")

print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end