# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

target_column = "job"

categorical_features = ['offspring', 'pets', 'drugs', 'smokes', 'drinks', 'education', 'sign', 'status', 'diet', 'religion', 'location', 'orientation', 'sex', 'body_type', 'height', 'age']

numerical_features = ['income']

columns_to_drop = ['speaks', 'ethnicity']  

def process_data(data):
    data = data.copy()  # Create a copy to avoid modifying the original DataFrame
    X = data.drop(columns=target_column)
    y = data[target_column]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features),
        # ('num', StandardScaler(), numerical_features),  # Uncomment if you want to scale numerical features
    ],
    remainder='passthrough'  # Keep the remaining columns
)
    data = data.drop(columns=columns_to_drop)
    data = preprocessor.fit_transform(data)
    return data
# ```end