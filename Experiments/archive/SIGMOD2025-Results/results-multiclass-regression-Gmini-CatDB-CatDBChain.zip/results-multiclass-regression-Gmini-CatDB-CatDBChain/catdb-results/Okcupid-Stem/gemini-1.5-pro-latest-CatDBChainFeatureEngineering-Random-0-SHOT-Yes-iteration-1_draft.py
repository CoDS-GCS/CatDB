# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from multiprocessing import Pool
import numpy as np


def process_chunk(data):
    # Apply one-hot encoding to categorical features
    ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
    ct = ColumnTransformer(transformers=[('ohe', ohe, categorical_features)], remainder='passthrough')
    data_encoded = ct.fit_transform(data)
    return data_encoded

def data_preprocessing_pipeline(df):
    df = df[df['job'].isin(['stem', 'non_stem', 'student'])]
    df.dropna(subset=['job'], inplace=True)

    categorical_features = ['offspring', 'pets', 'drugs', 'smokes', 'drinks', 'education', 'sign', 'status', 'diet', 'religion', 'location', 'orientation', 'sex', 'body_type', 'height']
    numerical_features = ['age', 'income']

    target = 'job'

    X_train, X_test, y_train, y_test = train_test_split(df.drop(columns=target), df[target], test_size=0.2, random_state=42)
    
    with Pool() as pool:
        # Split the data into chunks
        chunk_size = len(X_train) // pool._processes
        X_train_chunks = [X_train[i:i + chunk_size] for i in range(0, len(X_train), chunk_size)]

        # Process the chunks in parallel
        results = pool.map(process_chunk, X_train_chunks)

    X_train_encoded = pd.DataFrame(data=np.concatenate(results))

    X_test_encoded = process_chunk(X_test)
    
    return  X_train_encoded,  X_test_encoded, y_train, y_test