# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from multiprocessing import Pool


def process_data(df):
    df = df[df['job'].isin(['stem', 'non_stem', 'student'])]
    df.dropna(subset=['job'], inplace=True)

    categorical_features = ['offspring', 'pets', 'drugs', 'smokes', 'drinks', 'education', 'sign', 'status', 'diet', 'religion', 'location', 'orientation', 'sex', 'body_type', 'height']
    numerical_features = ['age', 'income']

    target = 'job'

    X_train, X_test, y_train, y_test = train_test_split(df.drop(columns=target), df[target], test_size=0.2, random_state=42)

    def process_chunk(chunk):
        # Apply one-hot encoding to categorical features
        ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
        chunk_encoded = ohe.fit_transform(chunk[categorical_features])
        chunk_encoded_df = pd.DataFrame(chunk_encoded, columns=ohe.get_feature_names_out(categorical_features))
        
        # Concatenate encoded features with numerical features
        chunk_processed = pd.concat([chunk[numerical_features].reset_index(drop=True), chunk_encoded_df], axis=1)
        return chunk_processed

    with Pool(processes=4) as pool:  # Adjust the number of processes as needed
        # Split the DataFrame into chunks
        chunk_size = len(X_train) // 4  # Adjust chunk size as needed
        chunks = [X_train[i:i + chunk_size] for i in range(0, len(X_train), chunk_size)]
        
        # Process the chunks in parallel
        results = pool.map(process_chunk, chunks)

    X_train_processed = pd.concat(results)
    return X_train_processed
# ```end