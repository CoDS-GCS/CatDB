# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

categorical_features = ['offspring', 'pets', 'drugs', 'smokes', 'drinks', 'education', 'sign', 'status', 'diet', 'religion', 'location', 'orientation', 'sex', 'body_type', 'height']

categorical_transformer = OneHotEncoder(handle_unknown='ignore')

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', categorical_transformer, categorical_features)
    ],
    remainder='passthrough'  # Pass through other columns
)

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    # Add your classifier here
])
# ```end