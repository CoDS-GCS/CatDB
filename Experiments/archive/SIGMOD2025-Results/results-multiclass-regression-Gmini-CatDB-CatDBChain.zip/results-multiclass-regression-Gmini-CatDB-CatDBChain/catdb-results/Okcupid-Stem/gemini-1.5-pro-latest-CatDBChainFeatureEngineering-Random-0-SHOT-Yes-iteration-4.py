# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

target_column = "job"

categorical_columns = ['offspring', 'pets', 'drugs', 'smokes', 'drinks', 'education', 'sign', 'status', 'diet', 'religion', 'location', 'orientation', 'sex', 'body_type', 'height']

class ColumnSelector:
    def __init__(self, columns_to_drop):
        self.columns_to_drop = columns_to_drop

    def transform(self, X):
        return X.drop(columns=self.columns_to_drop)

    def fit(self, X, y=None):
        return self

def process_data(df):
    # Drop potentially irrelevant columns
    columns_to_drop = ['speaks', 'ethnicity']  # Add more columns if needed
    feature_selector = ColumnSelector(columns_to_drop)
    df = feature_selector.transform(df)

    # Split into features (X) and target (y)
    X = df.drop(columns=target_column)
    y = df[target_column]

    # Split into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Apply one-hot encoding to categorical features
    preprocessor = ColumnTransformer(
        transformers=[
            ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_columns)
        ],
        remainder='passthrough'
    )

    # Create the pipeline
    pipeline = Pipeline([
        ('preprocessor', preprocessor)
    ])

    # Fit and transform the data
    X_train = pipeline.fit_transform(X_train)
    X_test = pipeline.transform(X_test)

    return X_train, X_test, y_train, y_test

if __name__ == '__main__':
    df = pd.read_csv('your_data.csv')  # Load your DataFrame
    X_train, X_test, y_train, y_test = process_data(df)
# ```end