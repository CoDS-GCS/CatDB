# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

target_column = "job"

drop_columns = ['location', 'last_online', 'sign'] 

categorical_features = ['offspring', 'pets', 'drugs', 'smokes', 'drinks', 'education', 'status', 'diet', 'religion', 'orientation', 'sex', 'body_type', 'height']
numerical_features = ['age', 'income']

categorical_transformer = OneHotEncoder(handle_unknown='ignore')

numerical_transformer = StandardScaler()

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', categorical_transformer, categorical_features),
        ('num', numerical_transformer, numerical_features)
    ])

def create_pipeline():
    return Pipeline(steps=[
        ('preprocessor', preprocessor)
    ], verbose=True)
# ```end