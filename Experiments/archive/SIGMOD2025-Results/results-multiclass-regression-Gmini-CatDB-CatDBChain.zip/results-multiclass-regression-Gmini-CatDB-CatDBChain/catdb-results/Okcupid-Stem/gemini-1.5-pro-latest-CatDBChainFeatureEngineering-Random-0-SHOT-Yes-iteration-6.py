# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split

def process_data():
    # Load the dataset
    data = pd.read_csv("okcupid_profiles.csv")

    # Drop potentially redundant columns
    columns_to_drop = ['offspring', 'pets', 'drugs', 'speaks', 'ethnicity', 'smokes', 'drinks', 'education', 'sign', 'status', 'diet', 'religion', 'location', 'orientation', 'body_type', 'height']
    data = data.drop(columns=columns_to_drop)

    # Split into features (X) and target (y)
    X = data.drop('job', axis=1)
    y = data['job']

    # Split into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Define categorical features for one-hot encoding
    categorical_features = ['sex']

    # Create a column transformer for preprocessing
    preprocessor = ColumnTransformer(
        transformers=[
            ('cat', OneHotEncoder(), categorical_features)
        ],
        remainder='passthrough'
    )

    # Create a pipeline
    pipeline = Pipeline([
        ('preprocessor', preprocessor)
    ])

    # Fit and transform the data
    X_train = pipeline.fit_transform(X_train)
    X_test = pipeline.transform(X_test)

    return X_train, X_test, y_train, y_test
# ```end