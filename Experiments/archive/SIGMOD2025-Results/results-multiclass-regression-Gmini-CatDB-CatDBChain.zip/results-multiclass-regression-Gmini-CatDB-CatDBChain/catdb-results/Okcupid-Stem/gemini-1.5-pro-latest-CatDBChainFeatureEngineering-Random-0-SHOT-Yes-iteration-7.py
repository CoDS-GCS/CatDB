# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

target_column = 'job'
categorical_columns = ['income']  # Only 'income' seems relevant for one-hot encoding

df = pd.DataFrame({'income': [1000, 2000, 2000, 1000, 5000, 1000, 2000], 'job': [1, 2, 1, 2, 3, 1, 2]}) # Replace with your actual data loading

X_train, X_test, y_train, y_test = train_test_split(
    df.drop(columns=target_column), df[target_column], test_size=0.2, random_state=42
)

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_columns)
    ],
    remainder='passthrough'
)

X_train_transformed = preprocessor.fit_transform(X_train)
X_test_transformed = preprocessor.transform(X_test)
# ```end