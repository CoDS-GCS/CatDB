# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.multiclass import OneVsRestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.compose import make_column_selector as selector

target_variable = "job"

categorical_features = ['income']

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features),
        ('num', StandardScaler(), selector(dtype_exclude="object"))
    ])

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('clf', OneVsRestClassifier(LogisticRegression(random_state=0)))
])
# ```end