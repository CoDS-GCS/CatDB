# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer

target_column = 'job'

columns_to_drop = ['location', 'sign', 'speaks', 'ethnicity', 'last_online'] 

categorical_features = ['offspring', 'pets', 'drugs', 'smokes', 'drinks', 'education', 'status', 'diet', 'religion', 'orientation', 'sex', 'body_type', 'height']
numerical_features = ['age', 'income']

def feature_engineering(data):
    # Example: Combine 'age' and 'income' into a new feature 'age_income_ratio'
    data['age_income_ratio'] = data['age'] / data['income']
    return data


categorical_transformer = OneHotEncoder(handle_unknown='ignore')

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', categorical_transformer, categorical_features),
    ],
    remainder='passthrough'  # Passthrough numerical features
)

pipeline = Pipeline([
    ('feature_engineering', FunctionTransformer(feature_engineering)),  # Use FunctionTransformer
    ('preprocessor', preprocessor)
])

# ```end