# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

target_column = "job"

categorical_features = ['offspring', 'pets', 'drugs', 'smokes', 'drinks', 'education', 'sign', 'status', 'diet', 'religion', 'location', 'orientation', 'sex', 'body_type', 'height', 'age', 'income']

numerical_features = []

columns_to_drop = ['speaks', 'ethnicity']  

def process_data(data):
    data = data.copy()  # Create a copy to avoid modifying the original DataFrame
    X = data.drop(columns=target_column)
    y = data[target_column]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features),
        # ('num', StandardScaler(), numerical_features),  # Uncomment if you want to scale numerical features
    ],
    remainder='passthrough'  # Keep the remaining columns
)
    data = data.drop(columns=columns_to_drop)
    X_train = preprocessor.fit_transform(X_train)
    X_test = preprocessor.transform(X_test)
    model = RandomForestClassifier(max_leaf_nodes=500, random_state=42)
    model.fit(X_train, y_train)

    # Make predictions
    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)
    y_train_proba = model.predict_proba(X_train)
    y_test_proba = model.predict_proba(X_test)

    # Calculate metrics
    Train_Accuracy = accuracy_score(y_train, y_train_pred)
    Test_Accuracy = accuracy_score(y_test, y_test_pred)
    Train_Log_loss = log_loss(y_train, y_train_proba)
    Test_Log_loss = log_loss(y_test, y_test_proba)
    Train_AUC_OVO = roc_auc_score(y_train, y_train_proba, multi_class='ovo')
    Train_AUC_OVR = roc_auc_score(y_train, y_train_proba, multi_class='ovr')
    Test_AUC_OVO = roc_auc_score(y_test, y_test_proba, multi_class='ovo')
    Test_AUC_OVR = roc_auc_score(y_test, y_test_proba, multi_class='ovr')

    # Print results
    print(f"Train_AUC_OVO:{Train_AUC_OVO}")
    print(f"Train_AUC_OVR:{Train_AUC_OVR}")
    print(f"Train_Accuracy:{Train_Accuracy}")   
    print(f"Train_Log_loss:{Train_Log_loss}") 
    print(f"Test_AUC_OVO:{Test_AUC_OVO}")
    print(f"Test_AUC_OVR:{Test_AUC_OVR}")
    print(f"Test_Accuracy:{Test_Accuracy}")   
    print(f"Test_Log_loss:{Test_Log_loss}")
    return data