# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from multiprocessing import Pool
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

def process_chunk(data):
    # Apply one-hot encoding to categorical features
    ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
    ct = ColumnTransformer(transformers=[('ohe', ohe, categorical_features)], remainder='passthrough')
    data_encoded = ct.fit_transform(data)
    return data_encoded

def data_preprocessing_pipeline(df):
    df = df[df['job'].isin(['stem', 'non_stem', 'student'])]
    df.dropna(subset=['job'], inplace=True)

    categorical_features = ['offspring', 'pets', 'drugs', 'smokes', 'drinks', 'education', 'sign', 'status', 'diet', 'religion', 'location', 'orientation', 'sex', 'body_type', 'height']
    numerical_features = ['age', 'income']

    target = 'job'

    X_train, X_test, y_train, y_test = train_test_split(df.drop(columns=target), df[target], test_size=0.2, random_state=42)
    
    with Pool() as pool:
        # Split the data into chunks
        chunk_size = len(X_train) // pool._processes
        X_train_chunks = [X_train[i:i + chunk_size] for i in range(0, len(X_train), chunk_size)]

        # Process the chunks in parallel
        results = pool.map(process_chunk, X_train_chunks)

    X_train_encoded = pd.DataFrame(data=np.concatenate(results))

    X_test_encoded = process_chunk(X_test)
    
    return  X_train_encoded,  X_test_encoded, y_train, y_test


df = pd.read_csv('dating.csv')  # Replace 'your_data.csv' with the actual file path

X_train, X_test, y_train, y_test = data_preprocessing_pipeline(df)

model = RandomForestClassifier(max_leaf_nodes=500, random_state=42)

model.fit(X_train, y_train)

y_train_pred = model.predict(X_train)
y_test_pred = model.predict(X_test)

Train_Accuracy = accuracy_score(y_train, y_train_pred)
Test_Accuracy = accuracy_score(y_test, y_test_pred)

Train_Log_loss = log_loss(y_train, model.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, model.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, model.predict_proba(X_train), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, model.predict_proba(X_train), multi_class='ovr')

Test_AUC_OVO = roc_auc_score(y_test, model.predict_proba(X_test), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, model.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_Log_loss:{Train_Log_loss}") 

print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_Log_loss:{Test_Log_loss}") 
# ```end