# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from multiprocessing import Pool
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score


def process_data(df):
    df = df[df['job'].isin(['stem', 'non_stem', 'student'])]
    df.dropna(subset=['job'], inplace=True)

    categorical_features = ['offspring', 'pets', 'drugs', 'smokes', 'drinks', 'education', 'sign', 'status', 'diet', 'religion', 'location', 'orientation', 'sex', 'body_type', 'height']
    numerical_features = ['age', 'income']

    target = 'job'

    X_train, X_test, y_train, y_test = train_test_split(df.drop(columns=target), df[target], test_size=0.2, random_state=42)

    def process_chunk(chunk):
        # Apply one-hot encoding to categorical features
        ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
        chunk_encoded = ohe.fit_transform(chunk[categorical_features])
        chunk_encoded_df = pd.DataFrame(chunk_encoded, columns=ohe.get_feature_names_out(categorical_features))
        
        # Concatenate encoded features with numerical features
        chunk_processed = pd.concat([chunk[numerical_features].reset_index(drop=True), chunk_encoded_df], axis=1)
        return chunk_processed

    with Pool(processes=4) as pool:  # Adjust the number of processes as needed
        # Split the DataFrame into chunks
        chunk_size = len(X_train) // 4  # Adjust chunk size as needed
        chunks = [X_train[i:i + chunk_size] for i in range(0, len(X_train), chunk_size)]
        
        # Process the chunks in parallel
        results = pool.map(process_chunk, chunks)

    X_train_processed = pd.concat(results)
    X_test_processed = process_chunk(X_test)

    # Define the model
    model = RandomForestClassifier(max_leaf_nodes=500, random_state=42)

    # Train the model
    model.fit(X_train_processed, y_train)

    # Make predictions
    y_train_pred = model.predict(X_train_processed)
    y_test_pred = model.predict(X_test_processed)
    y_train_proba = model.predict_proba(X_train_processed)
    y_test_proba = model.predict_proba(X_test_processed)

    # Calculate the evaluation metrics
    Train_Accuracy = accuracy_score(y_train, y_train_pred)
    Test_Accuracy = accuracy_score(y_test, y_test_pred)
    Train_Log_loss = log_loss(y_train, y_train_proba)
    Test_Log_loss = log_loss(y_test, y_test_proba)
    Train_AUC_OVO = roc_auc_score(y_train, y_train_proba, multi_class='ovo')
    Train_AUC_OVR = roc_auc_score(y_train, y_train_proba, multi_class='ovr')
    Test_AUC_OVO = roc_auc_score(y_test, y_test_proba, multi_class='ovo')
    Test_AUC_OVR = roc_auc_score(y_test, y_test_proba, multi_class='ovr')

    # Print the evaluation metrics
    print(f"Train_AUC_OVO:{Train_AUC_OVO}")
    print(f"Train_AUC_OVR:{Train_AUC_OVR}")
    print(f"Train_Accuracy:{Train_Accuracy}")   
    print(f"Train_Log_loss:{Train_Log_loss}") 
    print(f"Test_AUC_OVO:{Test_AUC_OVO}")
    print(f"Test_AUC_OVR:{Test_AUC_OVR}")
    print(f"Test_Accuracy:{Test_Accuracy}")   
    print(f"Test_Log_loss:{Test_Log_loss}") 

    return model
# ```end