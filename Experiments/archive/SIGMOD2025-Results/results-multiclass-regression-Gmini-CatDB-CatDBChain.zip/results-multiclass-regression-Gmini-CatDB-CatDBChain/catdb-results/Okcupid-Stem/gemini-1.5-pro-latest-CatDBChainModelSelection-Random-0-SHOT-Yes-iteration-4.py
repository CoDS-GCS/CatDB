# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

target_column = "job"

categorical_columns = ['offspring', 'pets', 'drugs', 'smokes', 'drinks', 'education', 'sign', 'status', 'diet', 'religion', 'location', 'orientation', 'sex', 'body_type', 'height', 'income']

class ColumnSelector:
    def __init__(self, columns_to_drop):
        self.columns_to_drop = columns_to_drop

    def transform(self, X):
        return X.drop(columns=self.columns_to_drop)

    def fit(self, X, y=None):
        return self

def process_data(df):
    # Drop potentially irrelevant columns
    columns_to_drop = ['speaks', 'ethnicity']  # Add more columns if needed
    feature_selector = ColumnSelector(columns_to_drop)
    df = feature_selector.transform(df)

    # Split into features (X) and target (y)
    X = df.drop(columns=target_column)
    y = df[target_column]

    # Split into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Apply one-hot encoding to categorical features
    preprocessor = ColumnTransformer(
        transformers=[
            ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_columns)
        ],
        remainder='passthrough'
    )

    # Create the pipeline
    pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('classifier', RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1, random_state=42))  # Use all available cores
    ])

    # Fit and transform the data
    pipeline.fit(X_train, y_train)

    # Make predictions
    y_train_pred = pipeline.predict_proba(X_train)
    y_test_pred = pipeline.predict_proba(X_test)

    # Calculate evaluation metrics
    Train_Accuracy = accuracy_score(y_train, pipeline.predict(X_train))
    Test_Accuracy = accuracy_score(y_test, pipeline.predict(X_test))
    Train_Log_loss = log_loss(y_train, y_train_pred)
    Test_Log_loss = log_loss(y_test, y_test_pred)
    Train_AUC_OVO = roc_auc_score(y_train, y_train_pred, multi_class='ovo')
    Train_AUC_OVR = roc_auc_score(y_train, y_train_pred, multi_class='ovr')
    Test_AUC_OVO = roc_auc_score(y_test, y_test_pred, multi_class='ovo')
    Test_AUC_OVR = roc_auc_score(y_test, y_test_pred, multi_class='ovr')

    # Print the evaluation results
    print(f"Train_AUC_OVO:{Train_AUC_OVO}")
    print(f"Train_AUC_OVR:{Train_AUC_OVR}")
    print(f"Train_Accuracy:{Train_Accuracy}")
    print(f"Train_Log_loss:{Train_Log_loss}")
    print(f"Test_AUC_OVO:{Test_AUC_OVO}")
    print(f"Test_AUC_OVR:{Test_AUC_OVR}")
    print(f"Test_Accuracy:{Test_Accuracy}")
    print(f"Test_Log_loss:{Test_Log_loss}")

    return pipeline

if __name__ == "__main__":
    try:
        df = pd.read_csv('dating.csv') 
        trained_pipeline = process_data(df)
    except FileNotFoundError:
        print("Error: 'dating.csv' not found. Please make sure the file exists and the path is correct.")
    except Exception as e:
        print(f"An error occurred while reading the file: {e}")
