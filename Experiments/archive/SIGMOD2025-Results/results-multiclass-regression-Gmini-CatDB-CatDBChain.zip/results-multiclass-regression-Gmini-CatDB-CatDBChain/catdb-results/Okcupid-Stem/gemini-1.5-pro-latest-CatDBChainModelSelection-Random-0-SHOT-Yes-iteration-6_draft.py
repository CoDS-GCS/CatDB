# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

def process_data():
    # Load the dataset
    data = pd.read_csv("okcupid_profiles.csv")

    # Drop potentially redundant columns
    columns_to_drop = ['offspring', 'pets', 'drugs', 'speaks', 'ethnicity', 'smokes', 'drinks', 'education', 'sign', 'status', 'diet', 'religion', 'location', 'orientation', 'body_type', 'height']
    data = data.drop(columns=columns_to_drop)

    # Split into features (X) and target (y)
    X = data.drop('job', axis=1)
    y = data['job']

    # Split into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Define categorical features for one-hot encoding
    categorical_features = ['sex']

    # Create a column transformer for preprocessing
    preprocessor = ColumnTransformer(
        transformers=[
            ('cat', OneHotEncoder(), categorical_features)
        ],
        remainder='passthrough'
    )

    # Create a pipeline with RandomForestClassifier
    pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('classifier', RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1, random_state=42))  # n_jobs=-1 for multithreading
    ])

    # Fit and transform the data
    X_train = pipeline.fit_transform(X_train, y_train)
    X_test = pipeline.transform(X_test)

    # Predict probabilities for AUC calculation
    y_train_proba = pipeline.predict_proba(X_train)
    y_test_proba = pipeline.predict_proba(X_test)

    # Calculate evaluation metrics
    Train_Accuracy = accuracy_score(y_train, pipeline.predict(X_train))
    Test_Accuracy = accuracy_score(y_test, pipeline.predict(X_test))
    Train_Log_loss = log_loss(y_train, y_train_proba)
    Test_Log_loss = log_loss(y_test, y_test_proba)
    Train_AUC_OVO = roc_auc_score(y_train, y_train_proba, multi_class='ovo')
    Train_AUC_OVR = roc_auc_score(y_train, y_train_proba, multi_class='ovr')
    Test_AUC_OVO = roc_auc_score(y_test, y_test_proba, multi_class='ovo')
    Test_AUC_OVR = roc_auc_score(y_test, y_test_proba, multi_class='ovr')

    # Print the results
    print(f"Train_AUC_OVO:{Train_AUC_OVO}")
    print(f"Train_AUC_OVR:{Train_AUC_OVR}")
    print(f"Train_Accuracy:{Train_Accuracy}")
    print(f"Train_Log_loss:{Train_Log_loss}")
    print(f"Test_AUC_OVO:{Test_AUC_OVO}")
    print(f"Test_AUC_OVR:{Test_AUC_OVR}")
    print(f"Test_Accuracy:{Test_Accuracy}")
    print(f"Test_Log_loss:{Test_Log_loss}")

    return pipeline

process_data()
# ```end