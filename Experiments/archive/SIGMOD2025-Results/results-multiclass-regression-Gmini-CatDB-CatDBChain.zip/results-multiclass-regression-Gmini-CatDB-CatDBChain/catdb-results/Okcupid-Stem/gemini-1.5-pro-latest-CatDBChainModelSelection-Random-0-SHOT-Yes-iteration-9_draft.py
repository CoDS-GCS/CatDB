# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score

target_column = 'job'

columns_to_drop = ['location', 'sign', 'speaks', 'ethnicity', 'last_online'] 

categorical_features = ['offspring', 'pets', 'drugs', 'smokes', 'drinks', 'education', 'status', 'diet', 'religion', 'orientation', 'sex', 'body_type', 'height']
numerical_features = ['age', 'income']

def feature_engineering(data):
    # Example: Combine 'age' and 'income' into a new feature 'age_income_ratio'
    data['age_income_ratio'] = data['age'] / data['income']
    return data


categorical_transformer = OneHotEncoder(handle_unknown='ignore')

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', categorical_transformer, categorical_features),
    ],
    remainder='passthrough'  # Passthrough numerical features
)

pipeline = Pipeline([
    ('feature_engineering', FunctionTransformer(feature_engineering)),  # Use FunctionTransformer
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1))  # Add classifier to pipeline, n_jobs=-1 to use all cores
])

data = pd.read_csv("okcupid_cleaned.csv") # Fix the error: provide the correct file path to your data file.
data = data.drop(columns=columns_to_drop)

X_train, X_test, y_train, y_test = train_test_split(
    data.drop(target_column, axis=1), data[target_column], test_size=0.2, random_state=42
)

pipeline.fit(X_train, y_train)

y_train_pred = pipeline.predict(X_train)
y_test_pred = pipeline.predict(X_test)

Train_Accuracy = accuracy_score(y_train, y_train_pred)
Test_Accuracy = accuracy_score(y_test, y_test_pred)

Train_Log_loss = log_loss(y_train, pipeline.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, pipeline.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, pipeline.predict_proba(X_train), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, pipeline.predict_proba(X_train), multi_class='ovr')

Test_AUC_OVO = roc_auc_score(y_test, pipeline.predict_proba(X_test), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, pipeline.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end