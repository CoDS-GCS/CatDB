# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error

train_data = pd.read_csv("../../../data/PASS/PASS_train.csv")
test_data = pd.read_csv("../../../data/PASS/PASS_test.csv")



def preprocess_data(df):
    # Convert datetaken to datetime object and extract year, month, and day
    df['datetaken'] = pd.to_datetime(df['datetaken'], errors='coerce')
    df['year'] = df['datetaken'].dt.year
    df['month'] = df['datetaken'].dt.month
    df['day'] = df['datetaken'].dt.day
    df = df.drop(columns=['datetaken'])
    return df

train_data = preprocess_data(train_data.copy())
test_data = preprocess_data(test_data.copy())

combined_data = pd.concat([train_data, test_data])

categorical_features = ['hash', 'url']
combined_data = pd.get_dummies(combined_data, columns=categorical_features, sparse=True)

train_data = combined_data[:len(train_data)]
test_data = combined_data[len(train_data):]

features = train_data.drop(columns=['unickname']).columns
target = 'unickname'

numerical_features = ['latitude', 'longitude', 'year', 'month', 'day']
scaler = StandardScaler()
train_data[numerical_features] = scaler.fit_transform(train_data[numerical_features])
test_data[numerical_features] = scaler.transform(test_data[numerical_features])

trn = LinearRegression()
trn.fit(train_data[features], train_data[target])

Train_R_Squared = r2_score(train_data[target], trn.predict(train_data[features]))
Train_RMSE = mean_squared_error(train_data[target], trn.predict(train_data[features]), squared=False)
Test_R_Squared = r2_score(test_data[target], trn.predict(test_data[features]))
Test_RMSE = mean_squared_error(test_data[target], trn.predict(test_data[features]), squared=False)

print(f"Train_R_Squared:{Train_R_Squared}")
print(f"Train_RMSE:{Train_RMSE}")
print(f"Test_R_Squared:{Test_R_Squared}")
print(f"Test_RMSE:{Test_RMSE}")
# ```end