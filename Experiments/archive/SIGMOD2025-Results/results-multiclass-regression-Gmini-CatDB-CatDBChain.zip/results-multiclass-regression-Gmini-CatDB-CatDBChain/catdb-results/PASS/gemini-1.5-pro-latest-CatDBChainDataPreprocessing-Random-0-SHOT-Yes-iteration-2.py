# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from multiprocessing import cpu_count
from joblib import Parallel, delayed
from scipy.sparse import vstack

train_data = pd.read_csv("../../../data/PASS/PASS_train.csv")
test_data = pd.read_csv("../../../data/PASS/PASS_test.csv")

categorical_features = ['hash', 'url', 'datetaken']
numerical_features = ['latitude', 'longitude']

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ])

def process_data(data):
    X = data.drop('unickname', axis=1)
    y = data['unickname']
    X_preprocessed = preprocessor.fit_transform(X)
    return X_preprocessed, y

n_jobs = cpu_count()
with Parallel(n_jobs=n_jobs) as parallel:
    # Process training data
    train_results = parallel(delayed(process_data)(train_data) for _ in range(n_jobs))
    X_train_processed = vstack([result[0] for result in train_results])
    y_train = pd.concat([result[1] for result in train_results])

    # Process test data
    test_results = parallel(delayed(process_data)(test_data) for _ in range(n_jobs))
    X_test_processed = vstack([result[0] for result in test_results])
    y_test = pd.concat([result[1] for result in test_results])
# ```end