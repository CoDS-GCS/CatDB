# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score

train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")



categorical_cols = ['Hit_Object_in_Carriageway']
encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)

combined_data = pd.concat([train_data, test_data], axis=0)
encoder.fit(combined_data[categorical_cols])

train_encoded = encoder.transform(train_data[categorical_cols])
test_encoded = encoder.transform(test_data[categorical_cols])

train_encoded_df = pd.DataFrame(train_encoded, columns=encoder.get_feature_names_out(categorical_cols))
test_encoded_df = pd.DataFrame(test_encoded, columns=encoder.get_feature_names_out(categorical_cols))

train_data = pd.concat([train_data, train_encoded_df], axis=1)
test_data = pd.concat([test_data, test_encoded_df], axis=1)


train_data.drop(columns=['Accident_Index'], inplace=True)
test_data.drop(columns=['Accident_Index'], inplace=True)
train_data.drop(columns=['LSOA_of_Accident_Location'], inplace=True)
test_data.drop(columns=['LSOA_of_Accident_Location'], inplace=True)

train_data['Date'] = pd.to_datetime(train_data['Date'])
test_data['Date'] = pd.to_datetime(test_data['Date'])

X_train = train_data.drop(columns=['Sex_of_Driver', 'Date', 'Time'])
y_train = train_data['Sex_of_Driver']
X_test = test_data.drop(columns=['Sex_of_Driver', 'Date', 'Time'])
y_test = test_data['Sex_of_Driver']

for col in X_train.columns:
    try:
        X_train[col] = pd.to_numeric(X_train[col])
    except:
        print(f"Column {col} cannot be converted to numeric")

for col in X_test.columns:
    try:
        X_test[col] = pd.to_numeric(X_test[col])
    except:
        print(f"Column {col} cannot be converted to numeric")

X_train = X_train.select_dtypes(include=['number'])
X_test = X_test.select_dtypes(include=['number'])

trn = RandomForestClassifier(max_leaf_nodes=500)
trn.fit(X_train, y_train)

Train_Accuracy = accuracy_score(y_train, trn.predict(X_train))
Test_Accuracy = accuracy_score(y_test, trn.predict(X_test))

Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, trn.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovo')
Test_AUC_OVO = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovo')

Train_AUC_OVR = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovr')
Test_AUC_OVR = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end