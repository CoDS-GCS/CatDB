# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score

train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv", parse_dates=['Date'])
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv", parse_dates=['Date'])

train_data['Date'] = pd.to_numeric(train_data['Date'])
test_data['Date'] = pd.to_numeric(test_data['Date'])

columns_to_encode = ['Hit_Object_in_Carriageway']
encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)

combined_data = pd.concat([train_data, test_data], axis=0)
encoder.fit(combined_data[columns_to_encode])

train_encoded = encoder.transform(train_data[columns_to_encode])
test_encoded = encoder.transform(test_data[columns_to_encode])

encoded_column_names = [f'Hit_Object_in_Carriageway_{i}' for i in range(train_encoded.shape[1])]

train_data = pd.concat([train_data, pd.DataFrame(train_encoded, columns=encoded_column_names)], axis=1)
test_data = pd.concat([test_data, pd.DataFrame(test_encoded, columns=encoded_column_names)], axis=1)

train_data = train_data.drop(columns=['Accident_Index', 'LSOA_of_Accident_Location', 'Time', 'Local_Authority_(Highway)'])
test_data = test_data.drop(columns=['Accident_Index', 'LSOA_of_Accident_Location', 'Time', 'Local_Authority_(Highway)'])

X_train = train_data.drop(columns=['Sex_of_Driver'])
y_train = train_data['Sex_of_Driver']
X_test = test_data.drop(columns=['Sex_of_Driver'])
y_test = test_data['Sex_of_Driver']

for column in X_train.columns:
    try:
        X_train[column] = X_train[column].astype(float)
    except:
        pass
for column in X_test.columns:
    try:
        X_test[column] = X_test[column].astype(float)
    except:
        pass

trn = RandomForestClassifier(max_leaf_nodes=500)

trn.fit(X_train, y_train)

y_pred_train = trn.predict(X_train)
y_pred_proba_train = trn.predict_proba(X_train)
y_pred_test = trn.predict(X_test)
y_pred_proba_test = trn.predict_proba(X_test)

Train_Accuracy = accuracy_score(y_train, y_pred_train)
Test_Accuracy = accuracy_score(y_test, y_pred_test)

Train_Log_loss = log_loss(y_train, y_pred_proba_train)
Test_Log_loss = log_loss(y_test, y_pred_proba_test)

Train_AUC_OVO = roc_auc_score(y_train, y_pred_proba_train, multi_class='ovo')
Test_AUC_OVO = roc_auc_score(y_test, y_pred_proba_test, multi_class='ovo')

Train_AUC_OVR = roc_auc_score(y_train, y_pred_proba_train, multi_class='ovr')
Test_AUC_OVR = roc_auc_score(y_test, y_pred_proba_test, multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end