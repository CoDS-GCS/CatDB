# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score

train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

train_data['IsWeekend'] = (pd.to_datetime(train_data['Date']).dt.dayofweek > 4).astype(int)
test_data['IsWeekend'] = (pd.to_datetime(test_data['Date']).dt.dayofweek > 4).astype(int)

train_data['Hour_of_Day'] = pd.to_datetime(train_data['Time']).dt.hour
test_data['Hour_of_Day'] = pd.to_datetime(test_data['Time']).dt.hour

train_data.drop(columns=['Accident_Index'], inplace=True)
test_data.drop(columns=['Accident_Index'], inplace=True)

train_data.drop(columns=['Date'], inplace=True)
test_data.drop(columns=['Date'], inplace=True)

train_data.drop(columns=['Time'], inplace=True)
test_data.drop(columns=['Time'], inplace=True)

train_data.drop(columns=['LSOA_of_Accident_Location'], inplace=True)
test_data.drop(columns=['LSOA_of_Accident_Location'], inplace=True)

train_data.drop(columns=['Local_Authority_(Highway)'], inplace=True)
test_data.drop(columns=['Local_Authority_(Highway)'], inplace=True)

for column in ['Hit_Object_in_Carriageway']:
    combined_data = pd.concat([train_data, test_data], axis=0)
    ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
    ohe.fit(combined_data[[column]])
    
    encoded_features_train = pd.DataFrame(ohe.transform(train_data[[column]]), columns=[f"{column}_{cat}" for cat in ohe.categories_[0]])
    train_data = pd.concat([train_data, encoded_features_train], axis=1)
    train_data.drop(columns=[column], inplace=True)
    
    encoded_features_test = pd.DataFrame(ohe.transform(test_data[[column]]), columns=[f"{column}_{cat}" for cat in ohe.categories_[0]])
    test_data = pd.concat([test_data, encoded_features_test], axis=1)
    test_data.drop(columns=[column], inplace=True)

trn = RandomForestClassifier(max_leaf_nodes=500, random_state=42)

features = train_data.drop(columns=['Sex_of_Driver']).columns
target = 'Sex_of_Driver'

trn.fit(train_data[features], train_data[target])

Train_Accuracy = accuracy_score(train_data[target], trn.predict(train_data[features]))
Test_Accuracy = accuracy_score(test_data[target], trn.predict(test_data[features]))

Train_Log_loss = log_loss(train_data[target], trn.predict_proba(train_data[features]))
Test_Log_loss = log_loss(test_data[target], trn.predict_proba(test_data[features]))

Train_AUC_OVO = roc_auc_score(train_data[target], trn.predict_proba(train_data[features]), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(train_data[target], trn.predict_proba(train_data[features]), multi_class='ovr')
Test_AUC_OVO = roc_auc_score(test_data[target], trn.predict_proba(test_data[features]), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(test_data[target], trn.predict_proba(test_data[features]), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end