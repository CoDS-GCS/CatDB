# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score
import numpy as np

train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

train_data['Is_Urban_Area'] = train_data['Urban_or_Rural_Area'].apply(lambda x: 1 if x == 1 else 0)
test_data['Is_Urban_Area'] = test_data['Urban_or_Rural_Area'].apply(lambda x: 1 if x == 1 else 0)

train_data['Daytime'] = train_data['Time'].apply(lambda x: 1 if str(x)[:2].isdigit() and int(str(x)[:2]) >= 6 and int(str(x)[:2]) < 18 else 0)
test_data['Daytime'] = test_data['Time'].apply(lambda x: 1 if str(x)[:2].isdigit() and int(str(x)[:2]) >= 6 and int(str(x)[:2]) < 18 else 0)

train_data.drop(columns=['Accident_Index'], inplace=True)
test_data.drop(columns=['Accident_Index'], inplace=True)

train_data.drop(columns=['LSOA_of_Accident_Location'], inplace=True)
test_data.drop(columns=['LSOA_of_Accident_Location'], inplace=True)

train_data.drop(columns=['Date'], inplace=True)
test_data.drop(columns=['Date'], inplace=True)

train_data.drop(columns=['Time'], inplace=True)
test_data.drop(columns=['Time'], inplace=True)

for col in ["Hit_Object_in_Carriageway"]:
    enc = OneHotEncoder(handle_unknown='ignore')
    # fit the encoder on the combined training and test data
    enc.fit(pd.concat([train_data[[col]], test_data[[col]]], axis=0))
    # transform the training and test data separately
    num_train = enc.transform(train_data[[col]]).toarray()
    num_test = enc.transform(test_data[[col]]).toarray()
    # create new column names for the one-hot encoded features
    new_cols = [col + '_' + str(i) for i in range(num_train.shape[1])]
    # create new dataframes with the one-hot encoded features
    df_train = pd.DataFrame(num_train, columns=new_cols, index=train_data.index)
    df_test = pd.DataFrame(num_test, columns=new_cols, index=test_data.index)
    # concatenate the new dataframes with the original dataframes
    train_data = pd.concat([train_data, df_train], axis=1)
    test_data = pd.concat([test_data, df_test], axis=1)
    # drop the original columns
    train_data.drop(columns=[col], inplace=True)
    test_data.drop(columns=[col], inplace=True)

train_data = train_data.apply(pd.to_numeric, errors='coerce')
test_data = test_data.apply(pd.to_numeric, errors='coerce')

train_data.replace([np.inf, -np.inf], np.nan, inplace=True)
test_data.replace([np.inf, -np.inf], np.nan, inplace=True)

train_data.fillna(train_data.mean(), inplace=True)
test_data.fillna(test_data.mean(), inplace=True)

trn = RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1)
trn.fit(train_data.drop(columns=['Sex_of_Driver']), train_data['Sex_of_Driver'])

Train_Accuracy = accuracy_score(train_data['Sex_of_Driver'], trn.predict(train_data.drop(columns=['Sex_of_Driver'])))
Test_Accuracy = accuracy_score(test_data['Sex_of_Driver'], trn.predict(test_data.drop(columns=['Sex_of_Driver'])))
Train_Log_loss = log_loss(train_data['Sex_of_Driver'], trn.predict_proba(train_data.drop(columns=['Sex_of_Driver'])), labels=trn.classes_)
Test_Log_loss = log_loss(test_data['Sex_of_Driver'], trn.predict_proba(test_data.drop(columns=['Sex_of_Driver'])), labels=trn.classes_)
Train_AUC_OVO = roc_auc_score(train_data['Sex_of_Driver'], trn.predict_proba(train_data.drop(columns=['Sex_of_Driver'])), multi_class='ovo', labels=trn.classes_)
Train_AUC_OVR = roc_auc_score(train_data['Sex_of_Driver'], trn.predict_proba(train_data.drop(columns=['Sex_of_Driver'])), multi_class='ovr', labels=trn.classes_)
Test_AUC_OVO = roc_auc_score(test_data['Sex_of_Driver'], trn.predict_proba(test_data.drop(columns=['Sex_of_Driver'])), multi_class='ovo', labels=trn.classes_)
Test_AUC_OVR = roc_auc_score(test_data['Sex_of_Driver'], trn.predict_proba(test_data.drop(columns=['Sex_of_Driver'])), multi_class='ovr', labels=trn.classes_)
print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end