# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score
import numpy as np

train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")



categorical_cols = ['Hit_Object_in_Carriageway']
enc = OneHotEncoder(handle_unknown='ignore')
enc.fit(pd.concat([train_data[categorical_cols], test_data[categorical_cols]]))

def encode_data(df):
    encoded_features = enc.transform(df[categorical_cols]).toarray()
    encoded_df = pd.DataFrame(encoded_features)
    encoded_df = encoded_df.add_prefix('Hit_Object_in_Carriageway_')
    df = df.reset_index(drop=True)
    df = pd.concat([df, encoded_df], axis=1)
    return df

train_data = encode_data(train_data)
test_data = encode_data(test_data)


train_data.drop(columns=['Hit_Object_in_Carriageway'], inplace=True)
test_data.drop(columns=['Hit_Object_in_Carriageway'], inplace=True)

X_train = train_data.drop(columns=['Sex_of_Driver'])
y_train = train_data['Sex_of_Driver']
X_test = test_data.drop(columns=['Sex_of_Driver'])
y_test = test_data['Sex_of_Driver']

for col in X_train.columns:
    X_train[col] = pd.to_numeric(X_train[col], errors='coerce')
    X_test[col] = pd.to_numeric(X_test[col], errors='coerce')

X_train = X_train.fillna(X_train.mean())
X_test = X_test.fillna(X_test.mean())

X_train = np.nan_to_num(X_train)
X_test = np.nan_to_num(X_test)

X_train = np.clip(X_train, -1e9, 1e9)
X_test = np.clip(X_test, -1e9, 1e9)

trn = RandomForestClassifier(max_leaf_nodes=500)
trn.fit(X_train, y_train)

Train_Accuracy = accuracy_score(y_train, trn.predict(X_train))
Test_Accuracy = accuracy_score(y_test, trn.predict(X_test))
Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, trn.predict_proba(X_test))
Train_AUC_OVO = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovo', labels=np.unique(y_train))
Train_AUC_OVR = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovr', labels=np.unique(y_train))
Test_AUC_OVO = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovo', labels=np.unique(y_test))
Test_AUC_OVR = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovr', labels=np.unique(y_test))
print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end