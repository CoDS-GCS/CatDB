# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score

train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

train_data['Is_Weekend'] = (pd.to_datetime(train_data['Date']).dt.dayofweek > 4).astype(int)
test_data['Is_Weekend'] = (pd.to_datetime(test_data['Date']).dt.dayofweek > 4).astype(int)

train_data['Hour_of_Day'] = pd.to_datetime(train_data['Time']).dt.hour
test_data['Hour_of_Day'] = pd.to_datetime(test_data['Time']).dt.hour

bins = [0, 25, 40, 60, 100]
labels = ['Young', 'Adult', 'Middle-aged', 'Senior']
train_data['Age_Group'] = pd.cut(train_data['Age_of_Driver'], bins=bins, labels=labels, right=False).astype(str)
test_data['Age_Group'] = pd.cut(test_data['Age_of_Driver'], bins=bins, labels=labels, right=False).astype(str)

train_data.drop(columns=['Date'], inplace=True)
test_data.drop(columns=['Date'], inplace=True)

train_data.drop(columns=['Time'], inplace=True)
test_data.drop(columns=['Time'], inplace=True)

combined_data = pd.concat([train_data, test_data])

ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
encoded_features = ohe.fit_transform(combined_data[['Hit_Object_in_Carriageway']])
encoded_df = pd.DataFrame(encoded_features, columns=ohe.get_feature_names_out(['Hit_Object_in_Carriageway']))

combined_data = pd.concat([combined_data.reset_index(drop=True), encoded_df], axis=1)

train_data = combined_data[:len(train_data)]
test_data = combined_data[len(train_data):]

trn = RandomForestClassifier(max_leaf_nodes=500)

X_train = train_data.drop(columns=['Sex_of_Driver', 'Accident_Index', 'LSOA_of_Accident_Location']).select_dtypes(include=['number'])
y_train = train_data['Sex_of_Driver']
X_test = test_data.drop(columns=['Sex_of_Driver', 'Accident_Index', 'LSOA_of_Accident_Location']).select_dtypes(include=['number'])
y_test = test_data['Sex_of_Driver']

trn.fit(X_train, y_train)

train_predictions = trn.predict(X_train)
test_predictions = trn.predict(X_test)
train_proba = trn.predict_proba(X_train)
test_proba = trn.predict_proba(X_test)

Train_Accuracy = accuracy_score(y_train, train_predictions)
Test_Accuracy = accuracy_score(y_test, test_predictions)

Train_Log_loss = log_loss(y_train, train_proba)
Test_Log_loss = log_loss(y_test, test_proba)

Train_AUC_OVO = roc_auc_score(y_train, train_proba, multi_class='ovo')
Test_AUC_OVO = roc_auc_score(y_test, test_proba, multi_class='ovo')

Train_AUC_OVR = roc_auc_score(y_train, train_proba, multi_class='ovr')
Test_AUC_OVR = roc_auc_score(y_test, test_proba, multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_Log_loss:{Train_Log_loss}") 
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end