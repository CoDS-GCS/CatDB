# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score
import numpy as np

train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

train_data['IsWeekend'] = (pd.to_datetime(train_data['Date']).dt.dayofweek > 4).astype(int)
test_data['IsWeekend'] = (pd.to_datetime(test_data['Date']).dt.dayofweek > 4).astype(int)

train_data['Hour_of_Day'] = pd.to_datetime(train_data['Time']).dt.hour
test_data['Hour_of_Day'] = pd.to_datetime(test_data['Time']).dt.hour

train_data.drop(columns=['Accident_Index'], inplace=True)
test_data.drop(columns=['Accident_Index'], inplace=True)

train_data.drop(columns=['Date'], inplace=True)
test_data.drop(columns=['Date'], inplace=True)

train_data.drop(columns=['Time'], inplace=True)
test_data.drop(columns=['Time'], inplace=True)

train_data.drop(columns=['LSOA_of_Accident_Location'], inplace=True)
test_data.drop(columns=['LSOA_of_Accident_Location'], inplace=True)

train_data.drop(columns=['Local_Authority_(Highway)'], inplace=True)
test_data.drop(columns=['Local_Authority_(Highway)'], inplace=True)

combined_data = pd.concat([train_data, test_data])

categorical_features = ['Hit_Object_in_Carriageway']

ct = ColumnTransformer([('onehot', OneHotEncoder(handle_unknown='ignore'), categorical_features)], remainder='passthrough')
combined_data_encoded = ct.fit_transform(combined_data)

train_data_encoded = combined_data_encoded[:len(train_data)]
test_data_encoded = combined_data_encoded[len(train_data):]

X_train = train_data_encoded[:, :-1]
y_train = train_data_encoded[:, -1]
X_test = test_data_encoded[:, :-1]
y_test = test_data_encoded[:, -1]

train_not_nan = ~np.isnan(y_train)
X_train = X_train[train_not_nan]
y_train = y_train[train_not_nan]

test_not_nan = ~np.isnan(y_test)
X_test = X_test[test_not_nan]
y_test = y_test[test_not_nan]

trn = RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1)
trn.fit(X_train, y_train)

Train_Accuracy = accuracy_score(y_train, trn.predict(X_train))
Test_Accuracy = accuracy_score(y_test, trn.predict(X_test))

Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, trn.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovo')
Test_AUC_OVO = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovo')

Train_AUC_OVR = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovr')
Test_AUC_OVR = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end