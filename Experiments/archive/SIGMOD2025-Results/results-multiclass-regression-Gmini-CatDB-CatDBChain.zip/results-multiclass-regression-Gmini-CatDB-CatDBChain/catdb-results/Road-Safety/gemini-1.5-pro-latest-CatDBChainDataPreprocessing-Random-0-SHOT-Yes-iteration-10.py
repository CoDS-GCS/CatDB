# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

categorical_features = ['Hit_Object_in_Carriageway']

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features),
        ('num', SimpleImputer(strategy='mean'), ['Longitude', 'Latitude', 'Location_Northing_OSGR', 'Location_Easting_OSGR', 'Engine_Capacity_(CC)'])
    ],
    remainder='drop'  # Drop other columns
)

pipeline = Pipeline(
    steps=[
        ('preprocessor', preprocessor)
    ],
    verbose=True
)

train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

train_data_processed = pipeline.fit_transform(train_data)

test_data_processed = pipeline.transform(test_data)
# ```end