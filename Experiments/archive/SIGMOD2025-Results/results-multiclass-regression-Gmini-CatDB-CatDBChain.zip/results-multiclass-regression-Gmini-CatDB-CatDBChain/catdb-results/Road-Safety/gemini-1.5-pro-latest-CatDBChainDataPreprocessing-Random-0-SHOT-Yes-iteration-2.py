# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.impute import SimpleImputer

categorical_features = ['Hit_Object_in_Carriageway', 'Accident_Index']

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
    ],
    remainder='passthrough'
)

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('imputer', SimpleImputer(strategy='mean')),
    ('classifier', LogisticRegression(n_jobs=-1))
])


train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

X_train = train_data.drop("Sex_of_Driver", axis=1)
y_train = train_data["Sex_of_Driver"]
X_test = test_data.drop("Sex_of_Driver", axis=1)
y_test = test_data["Sex_of_Driver"]

for col in X_train.columns:
    if X_train[col].dtype == 'object':
        try:
            X_train[col] = pd.to_numeric(X_train[col], errors='coerce')
            X_test[col] = pd.to_numeric(X_test[col], errors='coerce')
        except:
            print(f"Column {col} cannot be converted to numeric")

X_train = X_train.fillna(X_train.mean())
X_test = X_test.fillna(X_test.mean())

pipeline.fit(X_train, y_train)
# ```end