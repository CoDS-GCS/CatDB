# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

categorical_features = ['Hit_Object_in_Carriageway']
numerical_features = ['Longitude', 'Latitude', 'Location_Northing_OSGR', 'Location_Easting_OSGR', 'Engine_Capacity_(CC)']

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='mean'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', categorical_transformer, categorical_features),
        ('num', numerical_transformer, numerical_features)
    ],
    remainder='passthrough'  # Keep other columns unchanged
)

pipeline = Pipeline(
    steps=[
        ('preprocessor', preprocessor),
        # Add your desired estimator here (e.g., classifier or regressor)
    ]
)


train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

X_train = train_data.drop("Sex_of_Driver", axis=1)
y_train = train_data["Sex_of_Driver"]
X_test = test_data.drop("Sex_of_Driver", axis=1)
y_test = test_data["Sex_of_Driver"]

pipeline.fit(X_train, y_train)  # Fit on training data
processed_data_train = pipeline.transform(X_train)
processed_data_test = pipeline.transform(X_test)
# ```end