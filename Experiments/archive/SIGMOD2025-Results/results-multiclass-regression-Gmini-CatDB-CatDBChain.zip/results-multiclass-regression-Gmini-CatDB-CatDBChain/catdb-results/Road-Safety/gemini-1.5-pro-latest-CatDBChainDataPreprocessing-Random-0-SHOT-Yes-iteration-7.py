# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from multiprocessing import Pool

categorical_features = ['Hit_Object_in_Carriageway']

def preprocess_data(data):
    # Create a pipeline for categorical feature encoding
    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore'))
    ])

    # Create a column transformer to apply transformers to different columns
    preprocessor = ColumnTransformer(
        transformers=[
            ('cat', categorical_transformer, categorical_features)
        ],
        remainder='passthrough'
    )
    
    # Apply the preprocessor to the data
    data_processed = preprocessor.fit_transform(data)
    return data_processed

if __name__ == '__main__':
    train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
    test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

    n_chunks = 4
    train_data_chunks = [train_data[i::n_chunks] for i in range(n_chunks)]
    test_data_chunks = [test_data[i::n_chunks] for i in range(n_chunks)]

    with Pool(processes=n_chunks) as pool:
        # Process training data in parallel
        train_data_processed_chunks = pool.map(preprocess_data, train_data_chunks)
        # Process test data in parallel
        test_data_processed_chunks = pool.map(preprocess_data, test_data_chunks)

    train_data_processed = pd.concat(train_data_processed_chunks)
    test_data_processed = pd.concat(test_data_processed_chunks)
# ```end