# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

categorical_features = ['Hit_Object_in_Carriageway']

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
    ],
    remainder='passthrough'  # Pass through other columns
)

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('imputer', SimpleImputer(strategy='most_frequent')),  # Impute missing values
    # Add your desired estimator here (e.g., RandomForestClassifier)
])

train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

target_feature = "Sex_of_Driver"

X_train = train_data.drop(columns=[target_feature])
y_train = train_data[target_feature]
X_test = test_data.drop(columns=[target_feature])
y_test = test_data[target_feature]

pipeline.fit(X_train, y_train)

# ```end