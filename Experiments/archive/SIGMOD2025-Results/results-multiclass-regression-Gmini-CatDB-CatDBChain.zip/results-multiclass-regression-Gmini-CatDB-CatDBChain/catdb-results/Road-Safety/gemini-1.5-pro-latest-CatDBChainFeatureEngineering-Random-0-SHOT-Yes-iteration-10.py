# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

categorical_features = ['Hit_Object_in_Carriageway', 'Day_of_Week', 'Weather_Conditions', 'Light_Conditions', 
                       'Road_Surface_Conditions', 'Urban_or_Rural_Area']
numerical_features = ['Longitude', 'Latitude', 'Location_Northing_OSGR', 'Location_Easting_OSGR', 'Engine_Capacity_(CC)', 'Age_of_Driver']

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='mean'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', categorical_transformer, categorical_features),
        ('num', numerical_transformer, numerical_features)
    ]
)

pipeline = Pipeline(
    steps=[
        ('preprocessor', preprocessor)
    ],
    verbose=True
)

train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

X_train = train_data.drop('Sex_of_Driver', axis=1)
y_train = train_data['Sex_of_Driver']
X_test = test_data.drop('Sex_of_Driver', axis=1)
y_test = test_data['Sex_of_Driver']

train_data_processed = pipeline.fit_transform(X_train)
test_data_processed = pipeline.transform(X_test)
# ```end