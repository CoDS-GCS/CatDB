# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.impute import SimpleImputer
from sklearn.compose import make_column_transformer, make_column_selector
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

target_column = 'Sex_of_Driver'

train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

X_train = train_data.drop(columns=[target_column])
y_train = train_data[target_column]
X_test = test_data.drop(columns=[target_column])
y_test = test_data[target_column]

categorical_features = ['Hit_Object_in_Carriageway', 'Accident_Index']
numerical_features = make_column_selector(dtype_include=['number'])

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='mean')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = make_column_transformer(
    (numerical_transformer, numerical_features),
    (categorical_transformer, categorical_features),
    remainder='drop'  # Drop any other columns not specified
)

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('classifier', LogisticRegression(n_jobs=-1))
])

pipeline.fit(X_train, y_train)
# ```end