# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from multiprocessing import Pool

categorical_features = ['Hit_Object_in_Carriageway', 'Age_Band_of_Driver', 'Special_Conditions_at_Site', 'Pedestrian_Movement', 
                       'Pedestrian_Crossing-Human_Control', 'Driver_Home_Area_Type', 'Skidding_and_Overturning', 'Road_Type',
                       'Pedestrian_Road_Maintenance_Worker', 'Junction_Detail', 'Road_Surface_Conditions', 
                       'Journey_Purpose_of_Driver', 'Urban_or_Rural_Area', 'Junction_Control', '1st_Point_of_Impact', 
                       'Car_Passenger', 'Bus_or_Coach_Passenger', 'Casualty_Severity', 'Casualty_IMD_Decile', 
                       'Vehicle_Type', 'Sex_of_Casualty', 'Age_Band_of_Casualty', '1st_Road_Class', 'Speed_limit',
                       'Vehicle_Leaving_Carriageway', 'Accident_Severity', 'Casualty_Class', 'Casualty_Home_Area_Type',
                       'Light_Conditions', 'Junction_Location', 'Pedestrian_Location', 'Hit_Object_off_Carriageway',
                       'Did_Police_Officer_Attend_Scene_of_Accident', 'Was_Vehicle_Left_Hand_Drive?', 'Vehicle_Manoeuvre',
                       'Weather_Conditions', 'Casualty_Type', 'Carriageway_Hazards', 'Day_of_Week', '2nd_Road_Class',
                       'Pedestrian_Crossing-Physical_Facilities', 'Propulsion_Code', 'Vehicle_Location-Restricted_Lane',
                       'Number_of_Vehicles']

columns_to_drop = ['Accident_Index', 'LSOA_of_Accident_Location', 'Time', 'Date', 'Local_Authority_(Highway)',
                   '1st_Road_Number', 'Police_Force', '2nd_Road_Number', 'Vehicle_Reference_df_res', 
                   'Casualty_Reference', 'Location_Easting_OSGR', 'Location_Northing_OSGR', 'Age_of_Casualty',
                   'Age_of_Vehicle', 'Vehicle_Reference_df', 'Engine_Capacity_(CC)', 'Local_Authority_(District)']

def preprocess_data(data):
    # Drop irrelevant columns
    data = data.drop(columns=columns_to_drop, errors='ignore')
    return data

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', categorical_transformer, categorical_features)
    ],
    remainder='passthrough'
)

n_chunks = 4
train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

train_data_chunks = [train_data[i::n_chunks] for i in range(n_chunks)]
test_data_chunks = [test_data[i::n_chunks] for i in range(n_chunks)]

train_data_processed = pd.concat([preprocess_data(chunk) for chunk in train_data_chunks])
test_data_processed = pd.concat([preprocess_data(chunk) for chunk in test_data_chunks])

train_data_processed = preprocessor.fit_transform(train_data_processed)
test_data_processed = preprocessor.transform(test_data_processed)
# ```end