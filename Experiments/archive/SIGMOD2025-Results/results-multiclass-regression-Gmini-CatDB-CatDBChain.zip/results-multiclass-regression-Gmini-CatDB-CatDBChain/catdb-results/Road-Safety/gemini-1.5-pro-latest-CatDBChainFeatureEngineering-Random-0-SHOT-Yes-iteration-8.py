# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split

target_variable = 'Sex_of_Driver'

train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

columns_to_drop = ['Accident_Index', 'LSOA_of_Accident_Location', 'Time', 'Date', 'Local_Authority_(Highway)',
                   '1st_Road_Number', '2nd_Road_Number', 'Police_Force', 'Local_Authority_(District)']
train_data = train_data.drop(columns=columns_to_drop)
test_data = test_data.drop(columns=columns_to_drop)

categorical_features = ['Hit_Object_in_Carriageway', 'Towing_and_Articulation', 'Age_Band_of_Driver',
                       'Special_Conditions_at_Site', 'Pedestrian_Movement',
                       'Pedestrian_Crossing-Human_Control', 'Driver_Home_Area_Type',
                       'Skidding_and_Overturning', 'Road_Type', 'Pedestrian_Road_Maintenance_Worker',
                       'Number_of_Casualties', 'Junction_Detail', 'Vehicle_Reference_df_res',
                       'Road_Surface_Conditions', 'Journey_Purpose_of_Driver', 'Urban_or_Rural_Area',
                       'Junction_Control', '1st_Point_of_Impact', 'Casualty_Reference', 'Car_Passenger',
                       'Bus_or_Coach_Passenger', 'Casualty_Severity', 'Casualty_IMD_Decile',
                       'Vehicle_Type', 'Sex_of_Casualty', 'Age_of_Vehicle', 'Age_Band_of_Casualty',
                       '1st_Road_Class', 'Speed_limit', 'Vehicle_Leaving_Carriageway',
                       'Accident_Severity', 'Casualty_Class', 'Casualty_Home_Area_Type',
                       'Vehicle_Reference_df', 'Light_Conditions', 'Junction_Location',
                       'Pedestrian_Location', 'Hit_Object_off_Carriageway',
                       'Did_Police_Officer_Attend_Scene_of_Accident',
                       'Was_Vehicle_Left_Hand_Drive?', 'Vehicle_Manoeuvre', 'Weather_Conditions',
                       'Casualty_Type', 'Carriageway_Hazards', 'Day_of_Week', '2nd_Road_Class',
                       'Pedestrian_Crossing-Physical_Facilities', 'Propulsion_Code',
                       'Vehicle_Location-Restricted_Lane', 'Number_of_Vehicles']
numerical_features = ['Latitude', 'Longitude', 'Location_Northing_OSGR', 'Location_Easting_OSGR',
                     'Age_of_Driver', 'Age_of_Casualty', 'Engine_Capacity_(CC)']

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features),
        ('num', 'passthrough', numerical_features)
    ]
)

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor)
])

X_train = train_data.drop(target_variable, axis=1)
y_train = train_data[target_variable]
X_test = test_data.drop(target_variable, axis=1)
y_test = test_data[target_variable]

train_data_processed = pipeline.fit_transform(X_train)

test_data_processed = pipeline.transform(X_test)
# ```end