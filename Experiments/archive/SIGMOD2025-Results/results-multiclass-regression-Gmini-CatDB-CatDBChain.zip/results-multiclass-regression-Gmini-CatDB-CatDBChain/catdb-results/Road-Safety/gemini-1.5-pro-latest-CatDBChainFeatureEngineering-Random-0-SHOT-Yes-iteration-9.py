# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split

categorical_features = ['Hit_Object_in_Carriageway']

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
    ],
    remainder='passthrough'  # Pass through other columns
)

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('imputer', SimpleImputer(strategy='most_frequent')),  # Impute missing values
    # Add your desired estimator here (e.g., RandomForestClassifier)
])

train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

target_feature = "Sex_of_Driver"

X_train = train_data.drop(columns=[target_feature])
y_train = train_data[target_feature]
X_test = test_data.drop(columns=[target_feature])
y_test = test_data[target_feature]

def engineer_features(df):
    # Example: Combine 'Age_of_Driver' and 'Speed_limit'
    df['Age_Speed'] = df['Age_of_Driver'] / df['Speed_limit']
    return df

X_train = engineer_features(X_train)
X_test = engineer_features(X_test)

pipeline.fit(X_train, y_train)
# ```end