# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score

categorical_features = ['Hit_Object_in_Carriageway', 'Day_of_Week', 'Weather_Conditions', 'Light_Conditions', 
                       'Road_Surface_Conditions', 'Urban_or_Rural_Area']
numerical_features = ['Longitude', 'Latitude', 'Location_Northing_OSGR', 'Location_Easting_OSGR', 'Engine_Capacity_(CC)', 'Age_of_Driver']

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='mean'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', categorical_transformer, categorical_features),
        ('num', numerical_transformer, numerical_features)
    ]
)

pipeline = Pipeline(
    steps=[
        ('preprocessor', preprocessor),
        ('classifier', RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1))
    ],
    verbose=True
)

train_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_train.csv")
test_data = pd.read_csv("../../../data/Road-Safety/Road-Safety_test.csv")

X_train = train_data.drop('Sex_of_Driver', axis=1)
y_train = train_data['Sex_of_Driver']
X_test = test_data.drop('Sex_of_Driver', axis=1)
y_test = test_data['Sex_of_Driver']

pipeline.fit(X_train, y_train)

y_train_pred = pipeline.predict_proba(X_train)
y_test_pred = pipeline.predict_proba(X_test)

Train_Accuracy = accuracy_score(y_train, pipeline.predict(X_train))
Test_Accuracy = accuracy_score(y_test, pipeline.predict(X_test))

Train_Log_loss = log_loss(y_train, y_train_pred)
Test_Log_loss = log_loss(y_test, y_test_pred)

Train_AUC_OVO = roc_auc_score(y_train, y_train_pred, multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, y_train_pred, multi_class='ovr')

Test_AUC_OVO = roc_auc_score(y_test, y_test_pred, multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, y_test_pred, multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_Log_loss:{Train_Log_loss}") 

print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_Log_loss:{Test_Log_loss}") 
# ```end