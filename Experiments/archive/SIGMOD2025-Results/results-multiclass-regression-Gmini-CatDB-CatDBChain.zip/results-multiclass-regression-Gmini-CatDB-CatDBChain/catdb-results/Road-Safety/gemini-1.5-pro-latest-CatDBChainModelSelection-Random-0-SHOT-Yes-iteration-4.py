# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

target_column = 'Sex_of_Driver'

categorical_features = ['H', 'i', 't', '_', 'O', 'b', 'j', 'e', 'c', 't', '_', 'i', 'n', '_', 'C', 'a', 'r', 'r', 'i', 'a', 'g', 'e', 'w', 'a', 'y',
                       'Towing_and_Articulation', 'Age_Band_of_Driver', 'Special_Conditions_at_Site',
                       'Pedestrian_Movement', 'Pedestrian_Crossing-Human_Control', 'Driver_Home_Area_Type',
                       'Skidding_and_Overturning', 'Road_Type', 'Pedestrian_Road_Maintenance_Worker',
                       'Junction_Detail', 'Police_Force', 'Vehicle_Reference_df_res', 'Road_Surface_Conditions',
                       'Journey_Purpose_of_Driver', 'Urban_or_Rural_Area', 'Junction_Control',
                       '1st_Point_of_Impact', 'Car_Passenger', 'Bus_or_Coach_Passenger', 'Casualty_Severity',
                       'Casualty_IMD_Decile', 'Vehicle_Type', 'Sex_of_Casualty', 'Age_Band_of_Casualty',
                       '1st_Road_Class', 'Speed_limit', 'Vehicle_Leaving_Carriageway', 'Accident_Severity',
                       'Casualty_Class', 'Casualty_Home_Area_Type', 'Vehicle_Reference_df', 'Light_Conditions',
                       'Junction_Location', 'Pedestrian_Location', 'Hit_Object_off_Carriageway',
                       'Did_Police_Officer_Attend_Scene_of_Accident', 'Was_Vehicle_Left_Hand_Drive?',
                       'Vehicle_Manoeuvre', 'Weather_Conditions', 'Casualty_Type', 'Carriageway_Hazards',
                       'Day_of_Week', '2nd_Road_Class', 'Pedestrian_Crossing-Physical_Facilities',
                       'Propulsion_Code', 'Vehicle_Location-Restricted_Lane', 'Number_of_Vehicles',
                       'Hit_Object_in_Carriageway']

numerical_features = ['Latitude', 'Longitude', 'Location_Northing_OSGR', '1st_Road_Number', 'Age_of_Driver',
                     'Number_of_Casualties', '2nd_Road_Number', 'Location_Easting_OSGR', 'Age_of_Casualty',
                     'Age_of_Vehicle', 'Engine_Capacity_(CC)', 'Local_Authority_(District)']

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('cat', categorical_transformer, categorical_features),
        ('num', numerical_transformer, numerical_features)
    ]
)

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(n_jobs=-1, max_leaf_nodes=500))
])
# ```end