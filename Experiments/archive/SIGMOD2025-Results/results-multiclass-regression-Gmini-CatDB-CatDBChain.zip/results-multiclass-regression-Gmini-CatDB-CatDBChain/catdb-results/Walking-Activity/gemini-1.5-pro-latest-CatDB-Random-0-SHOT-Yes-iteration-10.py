# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.preprocessing import OneHotEncoder
from sklearn.multiclass import OneVsOneClassifier
from sklearn.multiclass import OneVsRestClassifier
from sklearn.metrics import roc_auc_score
import numpy as np

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv")
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv")


def add_gaussian_noise(data, noise_factor=0.05):
    """Adds Gaussian noise to the data.

    Args:
        data: The data to add noise to.
        noise_factor: The standard deviation of the Gaussian noise.

    Returns:
        The data with added noise.
    """
    noise = np.random.normal(loc=0.0, scale=noise_factor * np.std(data), size=data.shape)
    return data + noise

train_data_augmented = add_gaussian_noise(train_data.copy())
test_data_augmented = add_gaussian_noise(test_data.copy())

train_data = pd.concat([train_data, train_data_augmented], ignore_index=True)
test_data = pd.concat([test_data, test_data_augmented], ignore_index=True)

y_train = train_data['Class'].astype(int)
y_test = test_data['Class'].astype(int)

X_train = train_data.drop(columns=['Class'])
X_test = test_data.drop(columns=['Class'])

train_data['V1_squared'] = train_data['V1'] ** 2
test_data['V1_squared'] = test_data['V1'] ** 2

train_data['V2_squared'] = train_data['V2'] ** 2
test_data['V2_squared'] = test_data['V2'] ** 2

train_data['V3_squared'] = train_data['V3'] ** 2
test_data['V3_squared'] = test_data['V3'] ** 2

train_data['acc_magnitude'] = np.sqrt(train_data['V1']**2 + train_data['V2']**2 + train_data['V3']**2)
test_data['acc_magnitude'] = np.sqrt(test_data['V1']**2 + test_data['V2']**2 + test_data['V3']**2)


X_train = train_data.drop(columns=['Class'])
X_test = test_data.drop(columns=['Class'])

trn = RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1)
trn.fit(X_train, y_train)

Train_Accuracy = accuracy_score(y_train, trn.predict(X_train))
Test_Accuracy = accuracy_score(y_test, trn.predict(X_test))

Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, trn.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovo')
Test_AUC_OVO = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovo')

Train_AUC_OVR = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovr')
Test_AUC_OVR = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end