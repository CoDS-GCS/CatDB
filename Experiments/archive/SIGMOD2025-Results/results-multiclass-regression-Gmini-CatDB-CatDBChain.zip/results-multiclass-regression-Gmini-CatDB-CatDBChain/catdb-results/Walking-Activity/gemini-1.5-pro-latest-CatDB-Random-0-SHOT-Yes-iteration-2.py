# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.preprocessing import OneHotEncoder
from sklearn.multiclass import OneVsOneClassifier
from sklearn.multiclass import OneVsRestClassifier
from sklearn.metrics import roc_auc_score

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv")
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv")



enc = OneHotEncoder(handle_unknown='ignore')
enc.fit(train_data[['Class']])
train_data_encoded = pd.DataFrame(enc.transform(train_data[['Class']]).toarray())
train_data = train_data.join(train_data_encoded)
test_data_encoded = pd.DataFrame(enc.transform(test_data[['Class']]).toarray())
test_data = test_data.join(test_data_encoded)



combined_data = pd.concat([train_data, test_data])

train_data = combined_data[:len(train_data)]
test_data = combined_data[len(train_data):]

trn = RandomForestClassifier(max_leaf_nodes=500)

X_train = train_data.drop(columns=['Class'])
y_train = train_data['Class']
X_test = test_data.drop(columns=['Class'])
y_test = test_data['Class']

X_train.columns = X_train.columns.astype(str)
X_test.columns = X_test.columns.astype(str)

trn.fit(X_train, y_train)

train_predictions = trn.predict(X_train)
test_predictions = trn.predict(X_test)
train_proba = trn.predict_proba(X_train)
test_proba = trn.predict_proba(X_test)

Train_Accuracy = accuracy_score(y_train, train_predictions)
Test_Accuracy = accuracy_score(y_test, test_predictions)
Train_Log_loss = log_loss(y_train, train_proba)
Test_Log_loss = log_loss(y_test, test_proba)

Train_AUC_OVO = roc_auc_score(y_train, train_proba, multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, train_proba, multi_class='ovr')
Test_AUC_OVO = roc_auc_score(y_test, test_proba, multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, test_proba, multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end