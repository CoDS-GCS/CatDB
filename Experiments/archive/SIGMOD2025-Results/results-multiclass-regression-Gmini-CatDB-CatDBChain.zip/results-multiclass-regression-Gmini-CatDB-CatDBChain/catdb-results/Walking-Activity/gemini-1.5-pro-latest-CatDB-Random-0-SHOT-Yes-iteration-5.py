# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv")
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv")



train_data = pd.get_dummies(train_data, columns=["Class"], prefix="Class")
test_data = pd.get_dummies(test_data, columns=["Class"], prefix="Class")



combined_data = pd.concat([train_data, test_data])

scaler = StandardScaler()
train_data[['V1', 'V2', 'V3', 'V4']] = scaler.fit_transform(train_data[['V1', 'V2', 'V3', 'V4']])
test_data[['V1', 'V2', 'V3', 'V4']] = scaler.transform(test_data[['V1', 'V2', 'V3', 'V4']])

X_train = train_data.drop(columns=[col for col in train_data.columns if col.startswith('Class_')])
y_train = train_data[[col for col in train_data.columns if col.startswith('Class_')]].values.argmax(axis=1)
X_test = test_data.drop(columns=[col for col in test_data.columns if col.startswith('Class_')])
y_test = test_data[[col for col in test_data.columns if col.startswith('Class_')]].values.argmax(axis=1)

clf = RandomForestClassifier(max_leaf_nodes=500)
trn = clf.fit(X_train, y_train)

Train_Accuracy = accuracy_score(y_train, clf.predict(X_train))
Test_Accuracy = accuracy_score(y_test, clf.predict(X_test))

Train_Log_loss = log_loss(y_train, clf.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, clf.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, clf.predict_proba(X_train), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, clf.predict_proba(X_train), multi_class='ovr')
Test_AUC_OVO = roc_auc_score(y_test, clf.predict_proba(X_test), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, clf.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end