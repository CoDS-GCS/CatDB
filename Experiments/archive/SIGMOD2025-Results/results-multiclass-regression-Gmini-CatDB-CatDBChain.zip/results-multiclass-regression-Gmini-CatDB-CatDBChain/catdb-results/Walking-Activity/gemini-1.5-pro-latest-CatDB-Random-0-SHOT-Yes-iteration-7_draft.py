# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv")
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv")



train_data = pd.get_dummies(train_data, columns=['Class'], prefix='Class')
test_data = pd.get_dummies(test_data, columns=['Class'], prefix='Class')

train_data['V4_squared'] = train_data['V4'] ** 2
test_data['V4_squared'] = test_data['V4'] ** 2

train_data['V3_minus_V2'] = train_data['V3'] - train_data['V2']
test_data['V3_minus_V2'] = test_data['V3'] - test_data['V2']

train_data.drop(columns=['V1'], inplace=True)
test_data.drop(columns=['V1'], inplace=True)

X_train = train_data.drop(columns=[col for col in train_data.columns if 'Class_' in col])
y_train = train_data[[col for col in train_data.columns if 'Class_' in col]].values.argmax(axis=1)
X_test = test_data.drop(columns=[col for col in test_data.columns if 'Class_' in col])
y_test = test_data[[col for col in test_data.columns if 'Class_' in col]].values.argmax(axis=1)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

trn = RandomForestClassifier(max_leaf_nodes=500, random_state=42)
trn.fit(X_train, y_train)

train_predictions = trn.predict_proba(X_train)
test_predictions = trn.predict_proba(X_test)

Train_Accuracy = accuracy_score(y_train, train_predictions.argmax(axis=1))
Test_Accuracy = accuracy_score(y_test, test_predictions.argmax(axis=1))
Train_Log_loss = log_loss(y_train, train_predictions)
Test_Log_loss = log_loss(y_test, test_predictions)
Train_AUC_OVO = roc_auc_score(y_train, train_predictions, multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, train_predictions, multi_class='ovr')
Test_AUC_OVO = roc_auc_score(y_test, test_predictions, multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, test_predictions, multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end