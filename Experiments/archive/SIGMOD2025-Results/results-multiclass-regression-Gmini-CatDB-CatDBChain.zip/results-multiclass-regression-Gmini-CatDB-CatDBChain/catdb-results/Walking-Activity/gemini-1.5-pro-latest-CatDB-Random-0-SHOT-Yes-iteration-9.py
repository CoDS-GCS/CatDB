# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.preprocessing import OneHotEncoder
from sklearn.multiclass import OneVsOneClassifier
from sklearn.multiclass import OneVsRestClassifier
from sklearn.metrics import roc_auc_score

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv")
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv")

train_data = train_data.fillna(train_data.mean())
test_data = test_data.fillna(test_data.mean())

combined_data = pd.concat([train_data, test_data])


encoder = OneHotEncoder(handle_unknown='ignore')
encoder.fit(combined_data[['Class']])

train_encoded = encoder.transform(train_data[['Class']]).toarray()
train_encoded_df = pd.DataFrame(train_encoded, columns=[f'Class_{i}' for i in range(train_encoded.shape[1])])
train_data = pd.concat([train_data, train_encoded_df], axis=1)

test_encoded = encoder.transform(test_data[['Class']]).toarray()
test_encoded_df = pd.DataFrame(test_encoded, columns=[f'Class_{i}' for i in range(test_encoded.shape[1])])
test_data = pd.concat([test_data, test_encoded_df], axis=1)


trn = RandomForestClassifier(max_leaf_nodes=500)

trn.fit(train_data.drop(columns=['Class']), train_data['Class'])

train_predictions = trn.predict(train_data.drop(columns=['Class']))
test_predictions = trn.predict(test_data.drop(columns=['Class']))

Train_Accuracy = accuracy_score(train_data['Class'], train_predictions)
Test_Accuracy = accuracy_score(test_data['Class'], test_predictions)

Train_Log_loss = log_loss(train_data['Class'], trn.predict_proba(train_data.drop(columns=['Class'])))
Test_Log_loss = log_loss(test_data['Class'], trn.predict_proba(test_data.drop(columns=['Class'])))

Train_AUC_OVO = roc_auc_score(train_data['Class'], trn.predict_proba(train_data.drop(columns=['Class'])), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(train_data['Class'], trn.predict_proba(train_data.drop(columns=['Class'])), multi_class='ovr')

Test_AUC_OVO = roc_auc_score(test_data['Class'], trn.predict_proba(test_data.drop(columns=['Class'])), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(test_data['Class'], trn.predict_proba(test_data.drop(columns=['Class'])), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")

print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end