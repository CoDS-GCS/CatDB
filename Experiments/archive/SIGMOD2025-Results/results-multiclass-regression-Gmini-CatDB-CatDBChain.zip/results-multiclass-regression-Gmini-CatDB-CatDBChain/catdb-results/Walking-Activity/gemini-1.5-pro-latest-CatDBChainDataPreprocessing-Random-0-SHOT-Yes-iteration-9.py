# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
import numpy as np

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv", header=None, names=['V1', 'V2', 'V3', 'V4', 'Class'])
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv", header=None, names=['V1', 'V2', 'V3', 'V4', 'Class'])

categorical_features = ['Class']
numerical_features = ['V1', 'V2', 'V3', 'V4']

numerical_transformer = Pipeline(steps=[
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        # ('cat', categorical_transformer, categorical_features)
    ])

model = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', model)
])

X_train = train_data.drop('Class', axis=1)
y_train = train_data['Class']

scores = cross_val_score(pipeline, X_train, y_train, cv=5, scoring='accuracy', n_jobs=-1)

print("Cross-validation scores:", scores)
print("Average accuracy:", np.mean(scores))
# ```end