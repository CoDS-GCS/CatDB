# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import numpy as np
from sklearn.compose import make_column_transformer, make_column_selector
from sklearn.pipeline import make_pipeline

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv")
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv")

def kinetic_energy(df):
    """Calculates the kinetic energy from the accelerometer data."""
    df['kinetic_energy'] = 0.5 * (df['V2']**2 + df['V3']**2 + df['V4']**2)
    return df

def magnitude_acceleration(df):
    """Calculates the magnitude of acceleration from the accelerometer data."""
    df['magnitude_acceleration'] = np.sqrt(df['V2']**2 + df['V3']**2 + df['V4']**2)
    return df

def signal_magnitude_area(df):
    """Calculates the signal magnitude area for each axis."""
    for axis in ['V2', 'V3', 'V4']:
        df[f'{axis}_sma'] = df[axis].abs().rolling(window=10, center=True).mean()
    return df

preprocessor = make_column_transformer(
    (make_pipeline(SimpleImputer(strategy='median'), StandardScaler()), make_column_selector(dtype_include=['float64'])),
    (OneHotEncoder(handle_unknown='ignore'), ['Class']),
    remainder='passthrough'
)

pipeline = make_pipeline(
    preprocessor,
    kinetic_energy,
    magnitude_acceleration,
    signal_magnitude_area,
    PCA(n_components=0.95, svd_solver='full') 
)
# ```end