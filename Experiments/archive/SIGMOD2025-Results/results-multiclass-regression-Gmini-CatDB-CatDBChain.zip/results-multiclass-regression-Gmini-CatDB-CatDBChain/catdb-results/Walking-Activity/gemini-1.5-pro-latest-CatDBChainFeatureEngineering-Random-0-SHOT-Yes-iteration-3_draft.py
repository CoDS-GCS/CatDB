# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.preprocessing import FunctionTransformer
import multiprocessing

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv")
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv")

categorical_features = ['Class']
numerical_features = ['V1', 'V2', 'V3', 'V4']

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ])

def calculate_features(df):
    df['V1_squared'] = df['V1'] ** 2
    df['V2_squared'] = df['V2'] ** 2
    df['V3_squared'] = df['V3'] ** 2
    df['V4_squared'] = df['V4'] ** 2
    return df

def apply_pca(df):
    pca = PCA(n_components=2)
    principalComponents = pca.fit_transform(df[numerical_features])
    df['principal_component_1'] = principalComponents[:, 0]
    df['principal_component_2'] = principalComponents[:, 1]
    return df

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('feature_engineering', FunctionTransformer(calculate_features)),
    ('pca', FunctionTransformer(apply_pca))
])
# ```end