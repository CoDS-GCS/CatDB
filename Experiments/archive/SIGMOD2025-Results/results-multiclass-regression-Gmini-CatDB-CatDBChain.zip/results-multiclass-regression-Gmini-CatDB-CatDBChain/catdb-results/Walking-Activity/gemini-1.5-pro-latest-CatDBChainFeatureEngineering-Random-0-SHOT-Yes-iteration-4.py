# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score, KFold
import numpy as np
from sklearn.preprocessing import StandardScaler

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv")
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv")

categorical_features = ['Class']
numerical_features = ['V1', 'V2', 'V3', 'V4']

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ])

model = LogisticRegression(max_iter=1000, multi_class='multinomial', n_jobs=-1)  # Use all cores

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', model)
])

n_jobs = -1  # Use all available cores

kf = KFold(n_splits=5, shuffle=True, random_state=42)

scores = cross_val_score(pipeline, train_data[numerical_features + categorical_features], train_data['Class'], cv=kf, scoring='accuracy', n_jobs=n_jobs, error_score='raise')

print("Cross-validation scores:", scores)
print("Average cross-validation score:", np.mean(scores))
# ```end