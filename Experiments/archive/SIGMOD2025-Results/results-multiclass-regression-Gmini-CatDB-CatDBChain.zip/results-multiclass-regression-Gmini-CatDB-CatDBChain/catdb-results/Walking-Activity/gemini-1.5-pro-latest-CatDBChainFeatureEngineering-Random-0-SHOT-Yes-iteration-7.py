# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv")
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv")

categorical_features = ['Class']
numerical_features = ['V1', 'V2', 'V3', 'V4']

preprocessor = Pipeline([
    ('num', StandardScaler(), numerical_features),  # Apply standard scaling to numerical features
    ('pca', PCA(n_components=0.95, svd_solver='full'), numerical_features),  # Apply PCA to the numerical features
    ('cat', OneHotEncoder(), categorical_features)  # Apply one-hot encoding to categorical features
])
# ```end