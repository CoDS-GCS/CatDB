# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import multiprocessing
from sklearn.preprocessing import FunctionTransformer
import numpy as np
from joblib import Parallel, delayed

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv")
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv")

categorical_features = ['Class']
numerical_features = ['V1', 'V2', 'V3', 'V4']

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())  # Standardize numerical features
])

categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ])

def calculate_statistics(df):
    df['acceleration_magnitude'] = np.sqrt(df['V2']**2 + df['V3']**2 + df['V4']**2)
    return df

def apply_pca(df):
    pca = PCA(n_components=2)  # Reduce to 2 principal components
    pca_result = pca.fit_transform(df[['V2', 'V3', 'V4']])
    df[['pca_1', 'pca_2']] = pca_result
    return df

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('statistics', FunctionTransformer(calculate_statistics)),
    ('pca', FunctionTransformer(apply_pca))
])

n_jobs = multiprocessing.cpu_count()
pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('statistics', FunctionTransformer(calculate_statistics)),
    ('pca', FunctionTransformer(apply_pca)),
    ('parallel_step', Parallel(n_jobs=n_jobs)(delayed(lambda x: x)(X) for X in np.array_split(train_data, n_jobs)))
])