# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.preprocessing import FunctionTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score
import multiprocessing

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv")
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv")

categorical_features = ['Class']
numerical_features = ['V1', 'V2', 'V3', 'V4']

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ])

def calculate_features(df):
    df['V1_squared'] = df['V1'] ** 2
    df['V2_squared'] = df['V2'] ** 2
    df['V3_squared'] = df['V3'] ** 2
    df['V4_squared'] = df['V4'] ** 2
    return df

def apply_pca(df):
    pca = PCA(n_components=2)
    principalComponents = pca.fit_transform(df)
    df['principal_component_1'] = principalComponents[:, 0]
    df['principal_component_2'] = principalComponents[:, 1]
    return df

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('feature_engineering', FunctionTransformer(calculate_features)),
    ('pca', FunctionTransformer(apply_pca, validate=False)),
    ('classifier', RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1))
])

X_train = train_data.drop("Class", axis=1)
y_train = train_data["Class"]
X_test = test_data.drop("Class", axis=1)
y_test = test_data["Class"]

pipeline.fit(X_train, y_train)

y_train_pred = pipeline.predict_proba(X_train)
y_test_pred = pipeline.predict_proba(X_test)
Train_Accuracy = accuracy_score(y_train, pipeline.predict(X_train))
Test_Accuracy = accuracy_score(y_test, pipeline.predict(X_test))
Train_Log_loss = log_loss(y_train, y_train_pred)
Test_Log_loss = log_loss(y_test, y_test_pred)
Train_AUC_OVO = roc_auc_score(y_train, y_train_pred, multi_class='ovo', labels=sorted(y_train.unique()))
Train_AUC_OVR = roc_auc_score(y_train, y_train_pred, multi_class='ovr', labels=sorted(y_train.unique()))
Test_AUC_OVO = roc_auc_score(y_test, y_test_pred, multi_class='ovo', labels=sorted(y_test.unique()))
Test_AUC_OVR = roc_auc_score(y_test, y_test_pred, multi_class='ovr', labels=sorted(y_test.unique()))

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_Log_loss:{Train_Log_loss}") 
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end