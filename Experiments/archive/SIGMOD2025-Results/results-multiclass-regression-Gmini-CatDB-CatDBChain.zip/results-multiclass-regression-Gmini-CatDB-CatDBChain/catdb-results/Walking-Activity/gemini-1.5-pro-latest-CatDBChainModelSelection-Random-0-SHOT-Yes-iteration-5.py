# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv")
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv")

categorical_features = ['Class']
numerical_features = ['V1', 'V2', 'V3', 'V4']

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ])

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('pca', PCA(n_components=4)),  # Apply PCA with 4 components
    ('feature_selection', SelectKBest(f_classif, k=10)),  # Select top 10 features using ANOVA F-value
    ('classifier', RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1))  # Use all available cores
])

pipeline.fit(train_data[numerical_features + categorical_features], train_data['Class'])

train_predictions = pipeline.predict(train_data[numerical_features + categorical_features])
test_predictions = pipeline.predict(test_data[numerical_features + categorical_features])
train_proba = pipeline.predict_proba(train_data[numerical_features + categorical_features])
test_proba = pipeline.predict_proba(test_data[numerical_features + categorical_features])

Train_Accuracy = accuracy_score(train_data['Class'], train_predictions)
Test_Accuracy = accuracy_score(test_data['Class'], test_predictions)
Train_Log_loss = log_loss(train_data['Class'], train_proba)
Test_Log_loss = log_loss(test_data['Class'], test_proba)
Train_AUC_OVO = roc_auc_score(train_data['Class'], train_proba, multi_class='ovo')
Train_AUC_OVR = roc_auc_score(train_data['Class'], train_proba, multi_class='ovr')
Test_AUC_OVO = roc_auc_score(test_data['Class'], test_proba, multi_class='ovo')
Test_AUC_OVR = roc_auc_score(test_data['Class'], test_proba, multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end