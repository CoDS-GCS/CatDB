# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv")
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv")

categorical_features = ['Class']
numerical_features = ['V1', 'V2', 'V3', 'V4']

preprocessor = ColumnTransformer(
    transformers=[
        ('num', Pipeline([
            ('scaler', StandardScaler()),
            ('pca', PCA(n_components=0.95, svd_solver='full'))
        ]), numerical_features),
        ('cat', OneHotEncoder(), categorical_features)
    ]
)

model = RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1)  # n_jobs=-1 to use all available cores

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('classifier', model)
])

X_train = train_data.drop('Class', axis=1)
y_train = train_data['Class']
X_test = test_data.drop('Class', axis=1)
y_test = test_data['Class']

pipeline.fit(X_train, y_train)

y_train_pred = pipeline.predict(X_train)
y_test_pred = pipeline.predict(X_test)

Train_Accuracy = accuracy_score(y_train, y_train_pred)
Test_Accuracy = accuracy_score(y_test, y_test_pred)

Train_Log_loss = log_loss(y_train, pipeline.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, pipeline.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, pipeline.predict_proba(X_train), multi_class='ovo', labels=pipeline.classes_)
Train_AUC_OVR = roc_auc_score(y_train, pipeline.predict_proba(X_train), multi_class='ovr', labels=pipeline.classes_)
Test_AUC_OVO = roc_auc_score(y_test, pipeline.predict_proba(X_test), multi_class='ovo', labels=pipeline.classes_)
Test_AUC_OVR = roc_auc_score(y_test, pipeline.predict_proba(X_test), multi_class='ovr', labels=pipeline.classes_)

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end