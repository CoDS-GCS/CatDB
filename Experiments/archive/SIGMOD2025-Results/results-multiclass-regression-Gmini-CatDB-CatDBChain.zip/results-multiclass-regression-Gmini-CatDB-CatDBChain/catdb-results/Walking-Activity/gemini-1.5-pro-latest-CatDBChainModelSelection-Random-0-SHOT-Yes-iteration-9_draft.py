# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
import numpy as np
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import accuracy_score, log_loss, roc_auc_score

train_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_train.csv", header=None, names=['V1', 'V2', 'V3', 'V4', 'Class'])
test_data = pd.read_csv("../../../data/Walking-Activity/Walking-Activity_test.csv", header=None, names=['V1', 'V2', 'V3', 'V4', 'Class'])

categorical_features = ['Class']
numerical_features = ['V1', 'V2', 'V3', 'V4']

numerical_transformer = Pipeline(steps=[
    ('scaler', StandardScaler()),
    ('poly', PolynomialFeatures(degree=2, interaction_only=True))  # Add interaction terms
])

categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        # ('cat', categorical_transformer, categorical_features)
    ])

model = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1, max_leaf_nodes=500)

pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', model)
])

X_train = train_data.drop('Class', axis=1).astype(float)
y_train = train_data['Class']
X_test = test_data.drop('Class', axis=1).astype(float)
y_test = test_data['Class']

pipeline.fit(X_train, y_train)

y_train_pred = pipeline.predict(X_train)
y_test_pred = pipeline.predict(X_test)

Train_Accuracy = accuracy_score(y_train, y_train_pred)
Test_Accuracy = accuracy_score(y_test, y_test_pred)

Train_Log_loss = log_loss(y_train, pipeline.predict_proba(X_train))
Test_Log_loss = log_loss(y_test, pipeline.predict_proba(X_test))

Train_AUC_OVO = roc_auc_score(y_train, pipeline.predict_proba(X_train), multi_class='ovo')
Train_AUC_OVR = roc_auc_score(y_train, pipeline.predict_proba(X_train), multi_class='ovr')

Test_AUC_OVO = roc_auc_score(y_test, pipeline.predict_proba(X_test), multi_class='ovo')
Test_AUC_OVR = roc_auc_score(y_test, pipeline.predict_proba(X_test), multi_class='ovr')

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end