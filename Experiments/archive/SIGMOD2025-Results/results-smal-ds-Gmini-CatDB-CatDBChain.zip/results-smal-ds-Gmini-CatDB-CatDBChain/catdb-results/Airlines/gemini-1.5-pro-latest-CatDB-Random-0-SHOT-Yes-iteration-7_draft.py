# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
import numpy as np

train_data = pd.read_csv("../../../data/Airlines/Airlines_train.csv")
test_data = pd.read_csv("../../../data/Airlines/Airlines_test.csv")


train_data_augmented = train_data.copy()
train_data_augmented['Time'] = train_data_augmented['Time'].apply(lambda x: x + int(np.random.normal(0, 5))) # Add small random noise to Time
train_data = pd.concat([train_data, train_data_augmented], ignore_index=True)

ohe = OneHotEncoder(handle_unknown='ignore')
feature_cols = ['DayOfWeek', 'Airline']
ohe.fit(pd.concat([train_data[feature_cols], test_data[feature_cols]]))
train_encoded = pd.DataFrame(ohe.transform(train_data[feature_cols]).toarray())
test_encoded = pd.DataFrame(ohe.transform(test_data[feature_cols]).toarray())
train_data = train_data.drop(feature_cols, axis=1).reset_index(drop=True).join(train_encoded)
test_data = test_data.drop(feature_cols, axis=1).reset_index(drop=True).join(test_encoded)

train_data['MorningFlight'] = train_data['Time'].apply(lambda x: 1 if 500 <= x <= 1200 else 0) 
test_data['MorningFlight'] = test_data['Time'].apply(lambda x: 1 if 500 <= x <= 1200 else 0)

train_data.drop(columns=['Flight'], inplace=True)
test_data.drop(columns=['Flight'], inplace=True)

target_col = 'Delay'

train_data.columns = train_data.columns.astype(str)
test_data.columns = test_data.columns.astype(str)

trn = RandomForestClassifier(max_leaf_nodes=500)
trn.fit(train_data.drop(target_col, axis=1), train_data[target_col])

Train_AUC = roc_auc_score(train_data[target_col], trn.predict_proba(train_data.drop(target_col, axis=1))[:,1])
Train_Accuracy = accuracy_score(train_data[target_col], trn.predict(train_data.drop(target_col, axis=1)))
Train_F1_score = f1_score(train_data[target_col], trn.predict(train_data.drop(target_col, axis=1)))
Test_AUC = roc_auc_score(test_data[target_col], trn.predict_proba(test_data.drop(target_col, axis=1))[:,1])
Test_Accuracy = accuracy_score(test_data[target_col], trn.predict(test_data.drop(target_col, axis=1)))
Test_F1_score = f1_score(test_data[target_col], trn.predict(test_data.drop(target_col, axis=1)))
print(f"Train_AUC:{Train_AUC}")
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_F1_score:{Train_F1_score}")
print(f"Test_AUC:{Test_AUC}")
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_F1_score:{Test_F1_score}") 
# ```end