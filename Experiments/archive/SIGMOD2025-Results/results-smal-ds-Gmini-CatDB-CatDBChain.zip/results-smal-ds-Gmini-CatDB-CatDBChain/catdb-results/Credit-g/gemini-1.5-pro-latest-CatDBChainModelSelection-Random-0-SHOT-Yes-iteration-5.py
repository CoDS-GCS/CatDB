# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.base import BaseEstimator, TransformerMixin
from multiprocessing import cpu_count, Pool
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

class FeatureEngineer(BaseEstimator, TransformerMixin):
    def __init__(self, n_jobs=None):
        self.n_jobs = n_jobs if n_jobs else cpu_count()

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        X_copy = X.copy()

        # Example feature engineering: Combining 'credit_amount' and 'duration'
        X_copy['credit_amount_duration_ratio'] = X_copy['credit_amount'] / X_copy['duration']

        return X_copy

categorical_features = ['residence_since', 'savings_status', 'job', 'purpose', 'property_magnitude',
                        'personal_status', 'num_dependents', 'existing_credits', 'employment',
                        'other_payment_plans', 'housing', 'duration', 'checking_status',
                        'installment_commitment', 'credit_history', 'other_parties',
                        'foreign_worker', 'own_telephone']

encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)

preprocessor = ColumnTransformer(
    transformers=[('cat', encoder, categorical_features)],
    remainder='passthrough'
)

train_data = pd.read_csv("../../../data/Credit-g/Credit-g_train.csv")
test_data = pd.read_csv("../../../data/Credit-g/Credit-g_test.csv")

X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('feature_engineer', FeatureEngineer(n_jobs=None)),  # Add feature engineering step
    ('classifier', RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1))
])