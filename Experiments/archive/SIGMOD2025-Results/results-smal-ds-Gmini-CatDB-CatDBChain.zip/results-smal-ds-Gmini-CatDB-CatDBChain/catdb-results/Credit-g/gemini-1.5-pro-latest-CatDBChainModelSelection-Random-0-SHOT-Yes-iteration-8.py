# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.compose import make_column_transformer, make_column_selector
import numpy as np
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

train_data = pd.read_csv("../../../data/Credit-g/Credit-g_train.csv")
test_data = pd.read_csv("../../../data/Credit-g/Credit-g_test.csv")

categorical_features = ['residence_since', 'savings_status', 'job', 'purpose', 'property_magnitude',
                        'personal_status', 'num_dependents', 'existing_credits', 'employment',
                        'other_payment_plans', 'housing', 'duration', 'checking_status',
                        'installment_commitment', 'credit_history', 'other_parties',
                        'foreign_worker', 'own_telephone']

numerical_features = ['credit_amount', 'age']

target = 'class'


numerical_transformer = Pipeline(
    steps=[
        ('scaler', StandardScaler())
    ]
)

categorical_transformer = Pipeline(
    steps=[
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ]
)


preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ]
)

pipeline = Pipeline(
    steps=[
        ('preprocessor', preprocessor),
        ('pca', PCA(n_components=0.95, svd_solver='full')),  # Keep components explaining 95% variance
        ('classifier', RandomForestClassifier(max_leaf_nodes=500, n_jobs=-1))  # Use all available cores
    ]
)

pipeline.fit(train_data.drop(columns=[target]), train_data[target])

train_predictions = pipeline.predict(train_data.drop(columns=[target]))
test_predictions = pipeline.predict(test_data.drop(columns=[target]))

Train_Accuracy = accuracy_score(train_data[target], train_predictions)
Test_Accuracy = accuracy_score(test_data[target], test_predictions)

Train_F1_score = f1_score(train_data[target], train_predictions)
Test_F1_score = f1_score(test_data[target], test_predictions)

Train_AUC = roc_auc_score(train_data[target], train_predictions)
Test_AUC = roc_auc_score(test_data[target], test_predictions)

print(f"Train_AUC:{Train_AUC}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_F1_score:{Train_F1_score}")
print(f"Test_AUC:{Test_AUC}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_F1_score:{Test_F1_score}")
# ```end