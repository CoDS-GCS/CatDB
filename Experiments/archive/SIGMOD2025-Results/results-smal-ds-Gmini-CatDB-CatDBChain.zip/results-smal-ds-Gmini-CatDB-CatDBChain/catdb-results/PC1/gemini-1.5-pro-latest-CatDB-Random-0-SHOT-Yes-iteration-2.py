# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

train_data = pd.read_csv("../../../data/PC1/PC1_train.csv")
test_data = pd.read_csv("../../../data/PC1/PC1_test.csv")



categorical_cols = ['L', 'uniq_Op', 'v(g)', 'ev(g)', 'iv(G)', 'lOComment', 'locCodeAndComment', 'lOBlank']
encoder = OneHotEncoder(handle_unknown='ignore')
encoder.fit(pd.concat([train_data[categorical_cols], test_data[categorical_cols]]))  # Fit on the combined data
train_encoded = pd.DataFrame(encoder.transform(train_data[categorical_cols]).toarray())
test_encoded = pd.DataFrame(encoder.transform(test_data[categorical_cols]).toarray())
train_data = train_data.drop(categorical_cols, axis=1).reset_index(drop=True).join(train_encoded)
test_data = test_data.drop(categorical_cols, axis=1).reset_index(drop=True).join(test_encoded)


train_data['OpToOpndRatio'] = train_data['total_Op'] / train_data['total_Opnd']
test_data['OpToOpndRatio'] = test_data['total_Op'] / test_data['total_Opnd']

train_data.columns = train_data.columns.astype(str)
test_data.columns = test_data.columns.astype(str)

train_data.replace([float('inf'), float('-inf')], float('nan'), inplace=True)
test_data.replace([float('inf'), float('-inf')], float('nan'), inplace=True)

train_data.fillna(train_data.median(), inplace=True)
test_data.fillna(test_data.median(), inplace=True)

target_col = 'defects'
X_train = train_data.drop(columns=[target_col])
y_train = train_data[target_col]
X_test = test_data.drop(columns=[target_col])
y_test = test_data[target_col]

trn = RandomForestClassifier(max_leaf_nodes=500, random_state=42)
trn.fit(X_train, y_train)


y_train_pred = trn.predict(X_train)
y_test_pred = trn.predict(X_test)

Train_Accuracy = accuracy_score(y_train, y_train_pred)
Test_Accuracy = accuracy_score(y_test, y_test_pred)
Train_F1_score = f1_score(y_train, y_train_pred)
Test_F1_score = f1_score(y_test, y_test_pred)
Train_AUC = roc_auc_score(y_train, trn.predict_proba(X_train)[:, 1])
Test_AUC = roc_auc_score(y_test, trn.predict_proba(X_test)[:, 1])

print(f"Train_AUC:{Train_AUC}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_F1_score:{Train_F1_score}")
print(f"Test_AUC:{Test_AUC}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_F1_score:{Test_F1_score}")
# ```end