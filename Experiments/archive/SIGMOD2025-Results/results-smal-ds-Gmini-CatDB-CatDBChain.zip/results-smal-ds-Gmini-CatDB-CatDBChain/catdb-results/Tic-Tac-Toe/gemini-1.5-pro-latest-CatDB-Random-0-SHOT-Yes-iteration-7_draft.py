# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
import numpy as np

train_data = pd.read_csv("../../../data/Tic-Tac-Toe/Tic-Tac-Toe_train.csv")
test_data = pd.read_csv("../../../data/Tic-Tac-Toe/Tic-Tac-Toe_test.csv")


def augment_data(df):
    """
    Augments the Tic-Tac-Toe dataset by generating rotations and reflections of each board configuration.

    Args:
        df (pd.DataFrame): The original DataFrame containing the Tic-Tac-Toe data.

    Returns:
        pd.DataFrame: The augmented DataFrame with additional rows for rotations and reflections.
    """
    new_rows = []
    for _, row in df.iterrows():
        board = row.values[:-1].reshape(3, 3)  # Reshape to 3x3 board
        for _ in range(4):  # Rotate 4 times
            board = np.rot90(board)
            new_rows.append(list(board.flatten()) + [row['Class']])
        board = np.fliplr(board)  # Reflect horizontally
        new_rows.append(list(board.flatten()) + [row['Class']])
    augmented_df = pd.DataFrame(new_rows, columns=df.columns)
    return pd.concat([df, augmented_df])

train_data = augment_data(train_data)

categorical_cols = ['bottom-middle-square', 'top-middle-square', 'bottom-left-square',
                   'middle-left-square', 'bottom-right-square', 'top-right-square',
                   'middle-right-square', 'middle-middle-square', 'top-left-square']
enc = OneHotEncoder(handle_unknown='ignore')
enc.fit(pd.concat([train_data[categorical_cols], test_data[categorical_cols]]))
train_enc = enc.transform(train_data[categorical_cols]).toarray()
test_enc = enc.transform(test_data[categorical_cols]).toarray()

train_data = train_data.drop(columns=categorical_cols)
test_data = test_data.drop(columns=categorical_cols)

train_data = pd.concat([train_data.reset_index(drop=True), pd.DataFrame(train_enc)], axis=1)
test_data = pd.concat([test_data.reset_index(drop=True), pd.DataFrame(test_enc)], axis=1)


target_col = 'Class'

trn = RandomForestClassifier(max_leaf_nodes=500)
trn.fit(train_data.drop(columns=[target_col]), train_data[target_col])

train_pred = trn.predict(train_data.drop(columns=[target_col]))
test_pred = trn.predict(test_data.drop(columns=[target_col]))

Train_Accuracy = accuracy_score(train_data[target_col], train_pred)
Test_Accuracy = accuracy_score(test_data[target_col], test_pred)

Train_F1_score = f1_score(train_data[target_col], train_pred)
Test_F1_score = f1_score(test_data[target_col], test_pred)

Train_AUC = roc_auc_score(train_data[target_col], train_pred)
Test_AUC = roc_auc_score(test_data[target_col], test_pred)

print(f"Train_AUC:{Train_AUC}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_F1_score:{Train_F1_score}")

print(f"Test_AUC:{Test_AUC}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_F1_score:{Test_F1_score}")
# ```end