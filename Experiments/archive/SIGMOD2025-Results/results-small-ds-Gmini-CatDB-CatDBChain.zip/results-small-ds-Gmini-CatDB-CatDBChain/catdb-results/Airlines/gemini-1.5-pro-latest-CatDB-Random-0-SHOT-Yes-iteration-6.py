# ```python
import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

train_data = pd.read_csv("../../../data/Airlines/Airlines_train.csv")
test_data = pd.read_csv("../../../data/Airlines/Airlines_test.csv")

combined_data = pd.concat([train_data, test_data])

train_data['Length'] = train_data['Length'] + np.random.normal(0, 5, len(train_data))
test_data['Length'] = test_data['Length'] + np.random.normal(0, 5, len(test_data))

encoder = OneHotEncoder(handle_unknown='ignore')
encoder.fit(combined_data[['DayOfWeek', 'Airline']])

train_encoded = pd.DataFrame(encoder.transform(train_data[['DayOfWeek', 'Airline']]).toarray())
train_data = train_data.join(train_encoded)

test_encoded = pd.DataFrame(encoder.transform(test_data[['DayOfWeek', 'Airline']]).toarray())
test_data = test_data.join(test_encoded)

airport_flight_time = train_data.groupby('AirportFrom')['Length'].mean().to_dict()
train_data['AvgFlightTimeFromAirport'] = train_data['AirportFrom'].map(airport_flight_time)
test_data['AvgFlightTimeFromAirport'] = test_data['AirportFrom'].map(airport_flight_time)

airport_to_frequency = train_data['AirportTo'].value_counts().to_dict()
train_data['AirportToFrequency'] = train_data['AirportTo'].map(airport_to_frequency)
test_data['AirportToFrequency'] = test_data['AirportTo'].map(airport_to_frequency)

train_data.drop(columns=['AirportFrom'], inplace=True)
test_data.drop(columns=['AirportFrom'], inplace=True)
train_data.drop(columns=['DayOfWeek'], inplace=True)
test_data.drop(columns=['DayOfWeek'], inplace=True)
train_data.drop(columns=['Airline'], inplace=True)
test_data.drop(columns=['Airline'], inplace=True)

X_train = train_data.drop(columns=['Delay'])
y_train = train_data['Delay']
X_test = test_data.drop(columns=['Delay'])
y_test = test_data['Delay']

X_train.columns = X_train.columns.astype(str)
X_test.columns = X_test.columns.astype(str)

trn = RandomForestClassifier(max_leaf_nodes=500) 

trn.fit(X_train, y_train)

predictions_train = trn.predict(X_train)
predictions_test = trn.predict(X_test)

Train_AUC = roc_auc_score(y_train, predictions_train)
Train_Accuracy = accuracy_score(y_train, predictions_train)
Train_F1_score = f1_score(y_train, predictions_train)

Test_AUC = roc_auc_score(y_test, predictions_test)
Test_Accuracy = accuracy_score(y_test, predictions_test)
Test_F1_score = f1_score(y_test, predictions_test)

print(f"Train_AUC:{Train_AUC}")
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_F1_score:{Train_F1_score}")

print(f"Test_AUC:{Test_AUC}")
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_F1_score:{Test_F1_score}") 