# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
import numpy as np

train_data = pd.read_csv("../../../data/Airlines/Airlines_train.csv")
test_data = pd.read_csv("../../../data/Airlines/Airlines_test.csv")


train_data_augmented = train_data.copy()
train_data_augmented['Time'] = train_data_augmented['Time'].apply(lambda x: x + int(np.random.normal(0, 5))) # Add small random noise to Time
train_data = pd.concat([train_data, train_data_augmented], ignore_index=True)

ohe = OneHotEncoder(handle_unknown='ignore')
feature_cols = ['DayOfWeek', 'Airline']
ohe.fit(pd.concat([train_data[feature_cols], test_data[feature_cols]]))
train_encoded = pd.DataFrame(ohe.transform(train_data[feature_cols]).toarray(), columns=[f'col_{i}' for i in range(ohe.transform(train_data[feature_cols]).toarray().shape[1])])
test_encoded = pd.DataFrame(ohe.transform(test_data[feature_cols]).toarray(), columns=[f'col_{i}' for i in range(ohe.transform(test_data[feature_cols]).toarray().shape[1])])
train_data = train_data.drop(columns=feature_cols).reset_index(drop=True).join(train_encoded, lsuffix='_caller', rsuffix='_other')
test_data = test_data.drop(columns=feature_cols).reset_index(drop=True).join(test_encoded, lsuffix='_caller', rsuffix='_other')

train_data['AirportRoute'] = train_data['AirportFrom'].astype(str) + '_' + train_data['AirportTo'].astype(str)
test_data['AirportRoute'] = test_data['AirportFrom'].astype(str) + '_' + test_data['AirportTo'].astype(str)

ohe2 = OneHotEncoder(handle_unknown='ignore')
feature_cols2 = ['AirportRoute']
ohe2.fit(pd.concat([train_data[feature_cols2], test_data[feature_cols2]]))
train_encoded2 = pd.DataFrame(ohe2.transform(train_data[feature_cols2]).toarray(), columns=[f'col_{i}' for i in range(ohe2.transform(train_data[feature_cols2]).toarray().shape[1])])
test_encoded2 = pd.DataFrame(ohe2.transform(test_data[feature_cols2]).toarray(), columns=[f'col_{i}' for i in range(ohe2.transform(test_data[feature_cols2]).toarray().shape[1])])
train_data = train_data.drop(columns=feature_cols2).reset_index(drop=True).join(train_encoded2, lsuffix='_caller', rsuffix='_other')
test_data = test_data.drop(columns=feature_cols2).reset_index(drop=True).join(test_encoded2, lsuffix='_caller', rsuffix='_other')

columns_to_drop = ['AirportFrom', 'AirportTo'] # Example columns, adjust based on analysis
train_data.drop(columns=columns_to_drop, inplace=True)
test_data.drop(columns=columns_to_drop, inplace=True)

X_train = train_data.drop(columns=['Delay'])
y_train = train_data['Delay']
X_test = test_data.drop(columns=['Delay'])
y_test = test_data['Delay']

X_train.columns = X_train.columns.astype(str)
X_test.columns = X_test.columns.astype(str)

trn = RandomForestClassifier(max_leaf_nodes=500, random_state=42)
trn.fit(X_train, y_train)

y_pred_train = trn.predict(X_train)
y_pred_test = trn.predict(X_test)

Train_Accuracy = accuracy_score(y_train, y_pred_train)
Test_Accuracy = accuracy_score(y_test, y_pred_test)

Train_F1_score = f1_score(y_train, y_pred_train)
Test_F1_score = f1_score(y_test, y_pred_test)

Train_AUC = roc_auc_score(y_train, y_pred_train)
Test_AUC = roc_auc_score(y_test, y_pred_test)

print(f"Train_AUC:{Train_AUC}")
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_F1_score:{Train_F1_score}")
print(f"Test_AUC:{Test_AUC}")
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_F1_score:{Test_F1_score}") 
# ```end