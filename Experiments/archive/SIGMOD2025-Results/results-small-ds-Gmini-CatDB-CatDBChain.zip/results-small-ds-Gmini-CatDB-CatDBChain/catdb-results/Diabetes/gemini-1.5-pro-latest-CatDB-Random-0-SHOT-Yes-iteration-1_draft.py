# ```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.preprocessing import OneHotEncoder
import numpy as np

train_data = pd.read_csv("../../../data/Diabetes/Diabetes_train.csv")
test_data = pd.read_csv("../../../data/Diabetes/Diabetes_test.csv")


def augment_data(df, n_times=2):
    """
    Augments the data by adding Gaussian noise to existing features.

    Args:
        df (pd.DataFrame): The input DataFrame.
        n_times (int): The number of times to augment the data.

    Returns:
        pd.DataFrame: The augmented DataFrame.
    """
    augmented_data = []
    for _ in range(n_times):
        df_augmented = df.copy()
        for col in ['mass', 'pedi', 'skin', 'pres', 'insu', 'plas', 'age']:
            # Add Gaussian noise with mean=0 and std=0.1 * column's std
            df_augmented[col] += np.random.normal(0, 0.1 * df[col].std(), size=len(df))
        augmented_data.append(df_augmented)
    return pd.concat([df] + augmented_data, ignore_index=True)

train_data = augment_data(train_data)

ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
feature_array = ohe.fit_transform(train_data[['preg']])
feature_labels = np.array(ohe.categories_).ravel()
features = pd.DataFrame(feature_array, columns=feature_labels)
train_data = pd.concat([train_data, features], axis=1)

feature_array = ohe.transform(test_data[['preg']])
feature_labels = np.array(ohe.categories_).ravel()
features = pd.DataFrame(feature_array, columns=feature_labels)
test_data = pd.concat([test_data, features], axis=1)


train_data.drop(columns=['preg'], inplace=True)
test_data.drop(columns=['preg'], inplace=True)

X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']

X_train.columns = X_train.columns.astype(str)
X_test.columns = X_test.columns.astype(str)

trn = RandomForestClassifier(max_leaf_nodes=500, random_state=42)
trn.fit(X_train, y_train)

y_pred_train = trn.predict(X_train)
y_pred_test = trn.predict(X_test)

Train_Accuracy = accuracy_score(y_train, y_pred_train)
Test_Accuracy = accuracy_score(y_test, y_pred_test)
Train_F1_score = f1_score(y_train, y_pred_train)
Test_F1_score = f1_score(y_test, y_pred_test)
Train_AUC = roc_auc_score(y_train, y_pred_train)
Test_AUC = roc_auc_score(y_test, y_pred_test)

print(f"Train_AUC:{Train_AUC}")
print(f"Train_Accuracy:{Train_Accuracy}")   
print(f"Train_F1_score:{Train_F1_score}")
print(f"Test_AUC:{Test_AUC}")
print(f"Test_Accuracy:{Test_Accuracy}")   
print(f"Test_F1_score:{Test_F1_score}") 