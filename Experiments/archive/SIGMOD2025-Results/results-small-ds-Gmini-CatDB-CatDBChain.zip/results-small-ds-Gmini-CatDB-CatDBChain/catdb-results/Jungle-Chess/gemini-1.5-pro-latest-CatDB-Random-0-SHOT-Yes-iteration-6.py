# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.metrics import roc_auc_score

train_data = pd.read_csv("../../../data/Jungle-Chess/Jungle-Chess_train.csv")
test_data = pd.read_csv("../../../data/Jungle-Chess/Jungle-Chess_test.csv")

enc = OneHotEncoder(handle_unknown='ignore')

enc.fit(train_data.drop('class', axis=1))

train_data_encoded = enc.transform(train_data.drop('class', axis=1))
test_data_encoded = enc.transform(test_data.drop('class', axis=1))

X_train = train_data_encoded
y_train = train_data['class']
X_test = test_data_encoded
y_test = test_data['class']

trn = RandomForestClassifier(max_leaf_nodes=500)

trn.fit(X_train, y_train)

y_pred_train = trn.predict(X_train)
y_pred_test = trn.predict(X_test)

Train_Accuracy = accuracy_score(y_train, y_pred_train)
Test_Accuracy = accuracy_score(y_test, y_pred_test)

Train_Log_loss = log_loss(y_train, trn.predict_proba(X_train), labels=[0, 1, 2])
Test_Log_loss = log_loss(y_test, trn.predict_proba(X_test), labels=[0, 1, 2])

Train_AUC_OVO = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovo', labels=[0, 1, 2])
Train_AUC_OVR = roc_auc_score(y_train, trn.predict_proba(X_train), multi_class='ovr', labels=[0, 1, 2])
Test_AUC_OVO = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovo', labels=[0, 1, 2])
Test_AUC_OVR = roc_auc_score(y_test, trn.predict_proba(X_test), multi_class='ovr', labels=[0, 1, 2])

print(f"Train_AUC_OVO:{Train_AUC_OVO}")
print(f"Train_AUC_OVR:{Train_AUC_OVR}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_Log_loss:{Train_Log_loss}")
print(f"Test_AUC_OVO:{Test_AUC_OVO}")
print(f"Test_AUC_OVR:{Test_AUC_OVR}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_Log_loss:{Test_Log_loss}")
# ```end