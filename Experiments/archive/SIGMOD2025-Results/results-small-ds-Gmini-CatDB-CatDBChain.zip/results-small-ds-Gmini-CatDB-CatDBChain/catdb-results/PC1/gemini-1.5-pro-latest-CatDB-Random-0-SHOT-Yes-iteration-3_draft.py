# ```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

train_data = pd.read_csv("../../../data/PC1/PC1_train.csv")
test_data = pd.read_csv("../../../data/PC1/PC1_test.csv")


categorical_cols = ['L', 'uniq_Op', 'v(g)', 'ev(g)', 'iv(G)', 'lOComment', 'locCodeAndComment', 'lOBlank']
encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)

encoder.fit(pd.concat([train_data[categorical_cols], test_data[categorical_cols]]))

encoded_features_train = encoder.transform(train_data[categorical_cols])
encoded_feature_names = encoder.get_feature_names_out(categorical_cols)
encoded_df_train = pd.DataFrame(encoded_features_train, columns=encoded_feature_names)
train_data = train_data.drop(categorical_cols, axis=1).reset_index(drop=True)
train_data = pd.concat([train_data, encoded_df_train], axis=1)

encoded_features_test = encoder.transform(test_data[categorical_cols])
encoded_feature_names = encoder.get_feature_names_out(categorical_cols)
encoded_df_test = pd.DataFrame(encoded_features_test, columns=encoded_feature_names)
test_data = test_data.drop(categorical_cols, axis=1).reset_index(drop=True)
test_data = pd.concat([test_data, encoded_df_test], axis=1)


train_data.drop(columns=['B'], inplace=True)
test_data.drop(columns=['B'], inplace=True)

X_train = train_data.drop('defects', axis=1)
y_train = train_data['defects']
X_test = test_data.drop('defects', axis=1)
y_test = test_data['defects']

trn = RandomForestClassifier(max_leaf_nodes=500)
trn.fit(X_train, y_train)

Train_Accuracy = accuracy_score(y_train, trn.predict(X_train))
Test_Accuracy = accuracy_score(y_test, trn.predict(X_test))

Train_F1_score = f1_score(y_train, trn.predict(X_train))
Test_F1_score = f1_score(y_test, trn.predict(X_test))

Train_AUC = roc_auc_score(y_train, trn.predict_proba(X_train)[:, 1])
Test_AUC = roc_auc_score(y_test, trn.predict_proba(X_test)[:, 1])

print(f"Train_AUC:{Train_AUC}")
print(f"Train_Accuracy:{Train_Accuracy}")
print(f"Train_F1_score:{Train_F1_score}")
print(f"Test_AUC:{Test_AUC}")
print(f"Test_Accuracy:{Test_Accuracy}")
print(f"Test_F1_score:{Test_F1_score}")
# ```end