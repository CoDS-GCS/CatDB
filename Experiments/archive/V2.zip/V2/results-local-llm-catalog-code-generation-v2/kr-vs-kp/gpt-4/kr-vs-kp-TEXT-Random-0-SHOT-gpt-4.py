# python-import
# Import all required packages
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
# end-import

# python-load-dataset 
# load train and test datasets (csv file formats) here 
train = pd.read_csv('data/kr-vs-kp/kr-vs-kp_train.csv')
test = pd.read_csv('data/kr-vs-kp/kr-vs-kp_test.csv')
# end-load-dataset 

# python-added-column 
# (Feature name: text_length) 
# Usefulness: (The length of the text could be a useful feature as it may contain information about the complexity or detail of the text, which could be related to the class.) 
train['text_length'] = train['bkxbq'].apply(len)
test['text_length'] = test['bkxbq'].apply(len)
# end-added-column

# python-dropping-columns
# Explanation why the column 'bkxbq' is dropped
# The original text column 'bkxbq' is dropped because we have extracted the length feature from it and the raw text may not be useful for the classifier.
train.drop(columns=['bkxbq'], inplace=True)
test.drop(columns=['bkxbq'], inplace=True)
# end-dropping-columns

# python-training-technique 
# Use a binary classification technique
# Explanation why the solution is selected: RandomForestClassifier is chosen because it is a powerful and flexible model that can handle a variety of data types and structures. It also has built-in feature importance estimation, which can be useful for understanding the model.
X_train = train.drop(columns=['class'])
y_train = train['class']
X_test = test.drop(columns=['class'])
y_test = test['class']

pipeline = Pipeline([
    ('tfidf', TfidfVectorizer()),
    ('clf', RandomForestClassifier())
])

pipeline.fit(X_train, y_train)
# end-training-technique

# python-evaluation
# Report evaluation based on only test dataset 
y_pred = pipeline.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print('Accuracy:', accuracy)
# end-evaluation