# python-import
# Import all required packages
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
# end-import

# python-load-dataset
# load train and test datasets (csv file formats) here
train_data = pd.read_csv('train_data.csv')
test_data = pd.read_csv('test_data.csv')
# end-load-dataset

# python-added-column
# Add a new column 'V1203_V1589' which is the product of 'V1203' and 'V1589'
# Usefulness: Multiplying these two columns can capture the interaction between them and provide additional information for classification.
train_data['V1203_V1589'] = train_data['V1203'] * train_data['V1589']
test_data['V1203_V1589'] = test_data['V1203'] * test_data['V1589']
# end-added-column

# python-added-column
# Add a new column 'V2185_V3884' which is the product of 'V2185' and 'V3884'
# Usefulness: Multiplying these two columns can capture the interaction between them and provide additional information for classification.
train_data['V2185_V3884'] = train_data['V2185'] * train_data['V3884']
test_data['V2185_V3884'] = test_data['V2185'] * test_data['V3884']
# end-added-column

# python-dropping-columns
# Drop the column 'V2419' as it is redundant and may hurt the predictive performance
train_data.drop(columns=['V2419'], inplace=True)
test_data.drop(columns=['V2419'], inplace=True)
# end-dropping-columns

# python-training-technique
# Use Random Forest Classifier for binary classification
# Explanation: Random Forest is an ensemble learning method that combines multiple decision trees to make predictions. It is a popular choice for binary classification tasks due to its ability to handle complex relationships between features.
X_train = train_data.drop(columns=['class'])
y_train = train_data['class']
X_test = test_data.drop(columns=['class'])
y_test = test_data['class']

model = RandomForestClassifier()
model.fit(X_train, y_train)
# end-training-technique

# python-evaluation
# Report evaluation based on only test dataset
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)
# end-evaluation