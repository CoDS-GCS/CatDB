# ```python
# Import all required packages
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/BNG_solar_flare/BNG_solar_flare_train.csv')
test_data = pd.read_csv('data/BNG_solar_flare/BNG_solar_flare_test.csv')
# ```end

# ```python
# Encoding categorical features
# Usefulness: Encoding categorical variables is useful as many machine learning algorithms do not support categorical data directly. They require all input variables and output variables to be numeric.

le = LabelEncoder()
train_data['largest_spot_size'] = le.fit_transform(train_data['largest_spot_size'])
train_data['spot_distribution'] = le.fit_transform(train_data['spot_distribution'])
train_data['class'] = le.fit_transform(train_data['class'])

test_data['largest_spot_size'] = le.transform(test_data['largest_spot_size'])
test_data['spot_distribution'] = le.transform(test_data['spot_distribution'])
test_data['class'] = le.transform(test_data['class'])
# ```end

# ```python-dropping-columns
# Dropping 'Previous_24_hour_flare_activity_code' column
# Explanation: The 'Previous_24_hour_flare_activity_code' column is dropped because it is a historical data that might not have a significant impact on the current solar flare activity.
train_data.drop(columns=['Previous_24_hour_flare_activity_code'], inplace=True)
test_data.drop(columns=['Previous_24_hour_flare_activity_code'], inplace=True)
# ```end-dropping-columns

# ```python
# Define the features and the target
X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']
# ```end

# ```python
# Train a RandomForestClassifier
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)
# ```end

# ```python
# Predict the test data
y_pred = clf.predict(X_test)
# ```end

# ```python
# Report evaluation based on only test dataset
Accuracy = accuracy_score(y_test, y_pred)
F1_score = f1_score(y_test, y_pred, average='weighted')

print(f"Accuracy:{Accuracy}")   
print(f"F1_score:{F1_score}") 
# ```end