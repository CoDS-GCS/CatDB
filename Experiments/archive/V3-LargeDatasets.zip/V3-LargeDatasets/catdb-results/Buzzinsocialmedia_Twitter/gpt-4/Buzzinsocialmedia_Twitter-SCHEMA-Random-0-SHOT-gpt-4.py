# ```python
# Import all required packages
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/Buzzinsocialmedia_Twitter/Buzzinsocialmedia_Twitter_train.csv')
test_data = pd.read_csv('data/Buzzinsocialmedia_Twitter/Buzzinsocialmedia_Twitter_test.csv')
# ```end

# ```python
# Feature: Total NCD (Total Number of Created Discussions)
# Usefulness: This feature gives us the total number of created discussions across all days, which could be a good indicator of the overall buzz around the topic.
train_data['Total_NCD'] = train_data[['NCD_0', 'NCD_1', 'NCD_2', 'NCD_3', 'NCD_4', 'NCD_5', 'NCD_6']].sum(axis=1)
test_data['Total_NCD'] = test_data[['NCD_0', 'NCD_1', 'NCD_2', 'NCD_3', 'NCD_4', 'NCD_5', 'NCD_6']].sum(axis=1)
# ```end

# ```python
# Feature: Total NA (Total Number of Authors)
# Usefulness: This feature gives us the total number of authors across all days, which could be a good indicator of the overall reach of the topic.
train_data['Total_NA'] = train_data[['NA_0', 'NA_1', 'NA_2', 'NA_3', 'NA_4', 'NA_5', 'NA_6']].sum(axis=1)
test_data['Total_NA'] = test_data[['NA_0', 'NA_1', 'NA_2', 'NA_3', 'NA_4', 'NA_5', 'NA_6']].sum(axis=1)
# ```end

# ```python-dropping-columns
# Explanation why the column XX is dropped
# We are dropping the individual day columns for NCD and NA as we have created a total feature which captures the overall information.
train_data.drop(columns=['NCD_0', 'NCD_1', 'NCD_2', 'NCD_3', 'NCD_4', 'NCD_5', 'NCD_6'], inplace=True)
test_data.drop(columns=['NCD_0', 'NCD_1', 'NCD_2', 'NCD_3', 'NCD_4', 'NCD_5', 'NCD_6'], inplace=True)

train_data.drop(columns=['NA_0', 'NA_1', 'NA_2', 'NA_3', 'NA_4', 'NA_5', 'NA_6'], inplace=True)
test_data.drop(columns=['NA_0', 'NA_1', 'NA_2', 'NA_3', 'NA_4', 'NA_5', 'NA_6'], inplace=True)
# ```end-dropping-columns

# ```python
# Define the model
model = LinearRegression()

# Train the model
X_train = train_data.drop(columns=['Annotation'])
y_train = train_data['Annotation']
model.fit(X_train, y_train)

# Test the model
X_test = test_data.drop(columns=['Annotation'])
y_test = test_data['Annotation']
y_pred = model.predict(X_test)

# Report evaluation based on only test dataset
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end