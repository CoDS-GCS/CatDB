# ```python
# Import all required packages
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from math import sqrt

# Load the datasets
train_data = pd.read_csv("data/Buzzinsocialmedia_Twitter/Buzzinsocialmedia_Twitter_train.csv")
test_data = pd.read_csv("data/Buzzinsocialmedia_Twitter/Buzzinsocialmedia_Twitter_test.csv")

# Feature: Total NCD
# Usefulness: Total number of created discussions can be a good indicator of the buzz around a topic.
train_data['Total_NCD'] = train_data[['NCD_0', 'NCD_1', 'NCD_2', 'NCD_3', 'NCD_4', 'NCD_5', 'NCD_6']].sum(axis=1)
test_data['Total_NCD'] = test_data[['NCD_0', 'NCD_1', 'NCD_2', 'NCD_3', 'NCD_4', 'NCD_5', 'NCD_6']].sum(axis=1)

# Feature: Total NA
# Usefulness: Total number of authors can be a good indicator of the buzz around a topic.
train_data['Total_NA'] = train_data[['NA_0', 'NA_1', 'NA_2', 'NA_3', 'NA_4', 'NA_5', 'NA_6']].sum(axis=1)
test_data['Total_NA'] = test_data[['NA_0', 'NA_1', 'NA_2', 'NA_3', 'NA_4', 'NA_5', 'NA_6']].sum(axis=1)

# Feature: Total NAC
# Usefulness: Total number of atomic containers can be a good indicator of the buzz around a topic.
train_data['Total_NAC'] = train_data[['NAC_0', 'NAC_1', 'NAC_2', 'NAC_3', 'NAC_4', 'NAC_5', 'NAC_6']].sum(axis=1)
test_data['Total_NAC'] = test_data[['NAC_0', 'NAC_1', 'NAC_2', 'NAC_3', 'NAC_4', 'NAC_5', 'NAC_6']].sum(axis=1)

# Feature: Total AI
# Usefulness: Total number of atomic containers can be a good indicator of the buzz around a topic.
train_data['Total_AI'] = train_data[['AI_0', 'AI_1', 'AI_2', 'AI_3', 'AI_4', 'AI_5', 'AI_6']].sum(axis=1)
test_data['Total_AI'] = test_data[['AI_0', 'AI_1', 'AI_2', 'AI_3', 'AI_4', 'AI_5', 'AI_6']].sum(axis=1)

# Drop the original columns as they are no longer needed
train_data.drop(columns=['NCD_0', 'NCD_1', 'NCD_2', 'NCD_3', 'NCD_4', 'NCD_5', 'NCD_6', 'NA_0', 'NA_1', 'NA_2', 'NA_3', 'NA_4', 'NA_5', 'NA_6', 'NAC_0', 'NAC_1', 'NAC_2', 'NAC_3', 'NAC_4', 'NAC_5', 'NAC_6', 'AI_0', 'AI_1', 'AI_2', 'AI_3', 'AI_4', 'AI_5', 'AI_6'], inplace=True)
test_data.drop(columns=['NCD_0', 'NCD_1', 'NCD_2', 'NCD_3', 'NCD_4', 'NCD_5', 'NCD_6', 'NA_0', 'NA_1', 'NA_2', 'NA_3', 'NA_4', 'NA_5', 'NA_6', 'NAC_0', 'NAC_1', 'NAC_2', 'NAC_3', 'NAC_4', 'NAC_5', 'NAC_6', 'AI_0', 'AI_1', 'AI_2', 'AI_3', 'AI_4', 'AI_5', 'AI_6'], inplace=True)

# Define the model
model = LinearRegression()

# Train the model
X_train = train_data.drop(columns=['Annotation'])
y_train = train_data['Annotation']
model.fit(X_train, y_train)

# Test the model
X_test = test_data.drop(columns=['Annotation'])
y_test = test_data['Annotation']
y_pred = model.predict(X_test)

# Report evaluation based on only test dataset
R_Squared = r2_score(y_test, y_pred)
RMSE = sqrt(mean_squared_error(y_test, y_pred))

print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end