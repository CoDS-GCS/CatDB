# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/CanadaPricePrediction/CanadaPricePrediction_train.csv')
test_data = pd.read_csv('data/CanadaPricePrediction/CanadaPricePrediction_test.csv')
# ```end

# ```python 
# Feature: review_rate
# Usefulness: The rate of reviews can be a good indicator of the popularity of a product, which can influence its price.
train_data['review_rate'] = train_data['reviews'] / train_data['uid']
test_data['review_rate'] = test_data['reviews'] / test_data['uid']
# ```end 

# ```python 
# Feature: is_best_seller
# Usefulness: Best selling products are usually priced higher due to their high demand.
train_data['is_best_seller'] = train_data['isBestSeller'].apply(lambda x: 1 if x == True else 0)
test_data['is_best_seller'] = test_data['isBestSeller'].apply(lambda x: 1 if x == True else 0)
# ```end 

# ```python-dropping-columns
# Explanation: The 'asin' column is dropped because it is a unique identifier for each product and does not provide any useful information for price prediction.
# The 'uid' column is dropped because it is a unique identifier for each user and does not provide any useful information for price prediction.
# The 'title' and 'category' columns are dropped because they are natural language text and require complex processing to be useful for price prediction.
# The 'isBestSeller' column is dropped because we have created a new feature 'is_best_seller' based on it.
train_data.drop(columns=['asin', 'uid', 'title', 'category', 'isBestSeller'], inplace=True)
test_data.drop(columns=['asin', 'uid', 'title', 'category', 'isBestSeller'], inplace=True)
# ```end-dropping-columns

# ```python
# Train the regression model
X_train = train_data.drop('price', axis=1)
y_train = train_data['price']
X_test = test_data.drop('price', axis=1)
y_test = test_data['price']

model = LinearRegression()
model.fit(X_train, y_train)

# Predict the prices
y_pred = model.predict(X_test)

# Report evaluation based on only test dataset
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end