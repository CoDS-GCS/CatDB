# ```python
# Import all required packages
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/CanadaPricePrediction/CanadaPricePrediction_train.csv')
test_data = pd.read_csv('data/CanadaPricePrediction/CanadaPricePrediction_test.csv')
# ```end

# ```python 
# Feature: review_rate (reviews / uid)
# Usefulness: This feature can provide information about the popularity of the product. A higher review rate might indicate a higher price.
train_data['review_rate'] = train_data['reviews'] / train_data['uid']
test_data['review_rate'] = test_data['reviews'] / test_data['uid']
# ```end 

# ```python 
# Feature: is_bestseller (convert boolean to int)
# Usefulness: This feature can provide information about the product's demand. If a product is a bestseller, it might have a higher price.
train_data['is_bestseller'] = train_data['isBestSeller'].astype(int)
test_data['is_bestseller'] = test_data['isBestSeller'].astype(int)
# ```end 

# ```python-dropping-columns
# Explanation why the column 'uid' is dropped: 
# 'uid' is a unique identifier for each row and does not provide any useful information for the prediction of 'price'.
train_data.drop(columns=['uid'], inplace=True)
test_data.drop(columns=['uid'], inplace=True)
# ```end-dropping-columns

# ```python-dropping-columns
# Explanation why the column 'asin' is dropped: 
# 'asin' is a unique identifier for each product and does not provide any useful information for the prediction of 'price'.
train_data.drop(columns=['asin'], inplace=True)
test_data.drop(columns=['asin'], inplace=True)
# ```end-dropping-columns

# ```python-dropping-columns
# Explanation why the column 'isBestSeller' is dropped: 
# 'isBestSeller' is dropped because we have created a new feature 'is_bestseller' which is a numerical representation of the same information.
train_data.drop(columns=['isBestSeller'], inplace=True)
test_data.drop(columns=['isBestSeller'], inplace=True)
# ```end-dropping-columns

# ```python
# Define preprocessing pipeline for numerical and categorical features
num_features = ['reviews', 'boughtInLastMonth', 'stars', 'review_rate', 'is_bestseller']
cat_features = ['category', 'title']

num_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())])

cat_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
    ('vectorizer', CountVectorizer(max_features=1000, stop_words='english'))])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', num_transformer, num_features),
        ('cat', cat_transformer, cat_features)])

# Append classifier to preprocessing pipeline
clf = Pipeline(steps=[('preprocessor', preprocessor),
                      ('classifier', LinearRegression())])

# Fit the model
X_train = train_data.drop('price', axis=1)
y_train = train_data['price']
clf.fit(X_train, y_train)

# Predict on test data
X_test = test_data.drop('price', axis=1)
y_test = test_data['price']
y_pred = clf.predict(X_test)
# ```end

# ```python
# Report evaluation based on only test dataset
R_Squared = r2_score(y_test, y_pred)
RMSE = mean_squared_error(y_test, y_pred, squared=False)

print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end