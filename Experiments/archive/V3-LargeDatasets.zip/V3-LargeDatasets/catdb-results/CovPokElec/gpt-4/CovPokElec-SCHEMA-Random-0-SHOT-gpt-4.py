# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv("data/CovPokElec/CovPokElec_train.csv")
test_data = pd.read_csv("data/CovPokElec/CovPokElec_test.csv")
# ```end

# ```python
# Feature: Total_Distance
# Usefulness: This feature combines the horizontal and vertical distances to hydrology, which could be useful in predicting the class as it provides a more comprehensive measure of the overall distance to water bodies.
train_data['Total_Distance_To_Hydrology'] = np.sqrt(train_data['Horizontal_Distance_To_Hydrology']**2 + train_data['Vertical_Distance_To_Hydrology']**2)
test_data['Total_Distance_To_Hydrology'] = np.sqrt(test_data['Horizontal_Distance_To_Hydrology']**2 + test_data['Vertical_Distance_To_Hydrology']**2)
# ```end

# ```python
# Feature: Average_Hillshade
# Usefulness: This feature averages the hillshade index at 9am, noon, and 3pm, which could be useful in predicting the class as it provides a more comprehensive measure of the overall hillshade index throughout the day.
train_data['Average_Hillshade'] = (train_data['Hillshade_9am'] + train_data['Hillshade_Noon'] + train_data['Hillshade_3pm']) / 3
test_data['Average_Hillshade'] = (test_data['Hillshade_9am'] + test_data['Hillshade_Noon'] + test_data['Hillshade_3pm']) / 3
# ```end

# ```python-dropping-columns
# Explanation why the column XX is dropped
# The individual hillshade columns are dropped because they have been combined into the Average_Hillshade feature.
train_data.drop(columns=['Hillshade_9am', 'Hillshade_Noon', 'Hillshade_3pm'], inplace=True)
test_data.drop(columns=['Hillshade_9am', 'Hillshade_Noon', 'Hillshade_3pm'], inplace=True)

# The individual distance to hydrology columns are dropped because they have been combined into the Total_Distance_To_Hydrology feature.
train_data.drop(columns=['Horizontal_Distance_To_Hydrology', 'Vertical_Distance_To_Hydrology'], inplace=True)
test_data.drop(columns=['Horizontal_Distance_To_Hydrology', 'Vertical_Distance_To_Hydrology'], inplace=True)
# ```end-dropping-columns

# ```python
# Define the classifier
clf = RandomForestClassifier(n_estimators=100, random_state=0)

# Define the pipeline
pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('classifier', clf)
])

# Fit the pipeline on the training data
X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
pipeline.fit(X_train, y_train)

# Predict on the test data
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']
y_pred = pipeline.predict(X_test)

# Report evaluation based on only test dataset
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

# Print the accuracy result
print(f"R_Squared:{R_Squared}")   

# Print the log loss result
print(f"RMSE:{RMSE}") 
# ```end