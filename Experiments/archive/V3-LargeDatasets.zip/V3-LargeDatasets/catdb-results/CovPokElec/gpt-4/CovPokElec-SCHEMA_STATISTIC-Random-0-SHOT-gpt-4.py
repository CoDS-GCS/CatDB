# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.linear_model import LinearRegression

# Load the datasets
train_data = pd.read_csv("data/CovPokElec/CovPokElec_train.csv")
test_data = pd.read_csv("data/CovPokElec/CovPokElec_test.csv")

# Feature: Total_Distance
# Usefulness: This feature combines the horizontal and vertical distances to hydrology, which could be useful in predicting the class as it provides a more comprehensive measure of the overall distance to hydrology.
train_data['Total_Distance_To_Hydrology'] = np.sqrt(train_data['Horizontal_Distance_To_Hydrology']**2 + train_data['Vertical_Distance_To_Hydrology']**2)
test_data['Total_Distance_To_Hydrology'] = np.sqrt(test_data['Horizontal_Distance_To_Hydrology']**2 + test_data['Vertical_Distance_To_Hydrology']**2)

# Feature: Hillshade_Mean
# Usefulness: This feature averages the hillshade index at 9am, noon and 3pm, providing a more general measure of the amount of sunlight the area receives, which could be useful in predicting the class.
train_data['Hillshade_Mean'] = train_data[['Hillshade_9am', 'Hillshade_Noon', 'Hillshade_3pm']].mean(axis=1)
test_data['Hillshade_Mean'] = test_data[['Hillshade_9am', 'Hillshade_Noon', 'Hillshade_3pm']].mean(axis=1)

# Drop columns 'day', 'date', 'period', 'transfer', 'vicprice', 'nswdemand', 'vicdemand', 'nswprice' as they have only one distinct value and thus do not provide any useful information for the classifier.
train_data.drop(columns=['day', 'date', 'period', 'transfer', 'vicprice', 'nswdemand', 'vicdemand', 'nswprice'], inplace=True)
test_data.drop(columns=['day', 'date', 'period', 'transfer', 'vicprice', 'nswdemand', 'vicdemand', 'nswprice'], inplace=True)

# Define the target variable and the feature matrix
y_train = train_data['class']
X_train = train_data.drop(columns='class')
y_test = test_data['class']
X_test = test_data.drop(columns='class')

# Train a linear regression model
model = LinearRegression()
model.fit(X_train, y_train)

# Make predictions on the test set
y_pred = model.predict(X_test)

# Calculate the R-Squared and RMSE
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

# Print the results
print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end