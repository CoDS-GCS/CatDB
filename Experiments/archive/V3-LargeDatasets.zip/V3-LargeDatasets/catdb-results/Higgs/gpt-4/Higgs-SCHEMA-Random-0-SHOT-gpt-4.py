# ```python
# Import all required packages
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/Higgs/Higgs_train.csv')
test_data = pd.read_csv('data/Higgs/Higgs_test.csv')
# ```end

# ```python 
# Total energy
# Usefulness: Total energy might be a useful feature as it combines information from all jets and might be related to the target.
train_data['total_energy'] = train_data['m_jjj'] + train_data['m_bb'] + train_data['m_wbb'] + train_data['m_wwbb']
test_data['total_energy'] = test_data['m_jjj'] + test_data['m_bb'] + test_data['m_wbb'] + test_data['m_wwbb']
# ```end 

# ```python 
# Total b-tag
# Usefulness: Total b-tag might be a useful feature as it combines information from all jets and might be related to the target.
train_data['total_btag'] = train_data['jet 1 b-tag'] + train_data['jet 2 b-tag'] + train_data['jet 3 b-tag'] + train_data['jet 4 b-tag']
test_data['total_btag'] = test_data['jet 1 b-tag'] + test_data['jet 2 b-tag'] + test_data['jet 3 b-tag'] + test_data['jet 4 b-tag']
# ```end 

# ```python-dropping-columns
# Explanation why the column XX is dropped
# We drop the columns 'jet 1 b-tag', 'jet 2 b-tag', 'jet 3 b-tag', 'jet 4 b-tag' because we have created a new feature 'total_btag' that combines all these features.
# We also drop the columns 'm_jjj', 'm_bb', 'm_wbb', 'm_wwbb' because we have created a new feature 'total_energy' that combines all these features.
train_data.drop(columns=['jet 1 b-tag', 'jet 2 b-tag', 'jet 3 b-tag', 'jet 4 b-tag', 'm_jjj', 'm_bb', 'm_wbb', 'm_wwbb'], inplace=True)
test_data.drop(columns=['jet 1 b-tag', 'jet 2 b-tag', 'jet 3 b-tag', 'jet 4 b-tag', 'm_jjj', 'm_bb', 'm_wbb', 'm_wwbb'], inplace=True)
# ```end-dropping-columns

# ```python
# Prepare data for training
X_train = train_data.drop('Target', axis=1)
y_train = train_data['Target']

X_test = test_data.drop('Target', axis=1)
y_test = test_data['Target']

# Train a RandomForestClassifier
clf = RandomForestClassifier(n_estimators=100, random_state=0)
clf.fit(X_train, y_train)

# Make predictions
y_pred = clf.predict(X_test)

# Report evaluation based on only test dataset
Accuracy = accuracy_score(y_test, y_pred)
F1_score = f1_score(y_test, y_pred)

print(f"Accuracy:{Accuracy}")   
print(f"F1_score:{F1_score}") 
# ```end