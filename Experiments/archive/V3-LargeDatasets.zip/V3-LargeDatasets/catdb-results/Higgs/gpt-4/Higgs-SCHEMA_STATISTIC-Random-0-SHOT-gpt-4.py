# ```python
# Import all required packages
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv("data/Higgs/Higgs_train.csv")
test_data = pd.read_csv("data/Higgs/Higgs_test.csv")
# ```end

# ```python 
# Feature: Total Energy
# Usefulness: Total energy might be a useful feature as it combines information from all jets and might be related to the target.
train_data['total_energy'] = train_data['jet 1 pt'] + train_data['jet 2 pt'] + train_data['jet 3 pt'] + train_data['jet 4 pt']
test_data['total_energy'] = test_data['jet 1 pt'] + test_data['jet 2 pt'] + test_data['jet 3 pt'] + test_data['jet 4 pt']
# ```end 

# ```python 
# Feature: Total b-tag
# Usefulness: Total b-tag might be a useful feature as it combines information from all jets and might be related to the target.
train_data['total_btag'] = train_data['jet 1 b-tag'] + train_data['jet 2 b-tag'] + train_data['jet 3 b-tag'] + train_data['jet 4 b-tag']
test_data['total_btag'] = test_data['jet 1 b-tag'] + test_data['jet 2 b-tag'] + test_data['jet 3 b-tag'] + test_data['jet 4 b-tag']
# ```end 

# ```python-dropping-columns
# Explanation why the column XX is dropped
# The individual jet pt and b-tag columns are dropped as we have created new features that aggregate this information.
train_data.drop(columns=['jet 1 pt', 'jet 2 pt', 'jet 3 pt', 'jet 4 pt', 'jet 1 b-tag', 'jet 2 b-tag', 'jet 3 b-tag', 'jet 4 b-tag'], inplace=True)
test_data.drop(columns=['jet 1 pt', 'jet 2 pt', 'jet 3 pt', 'jet 4 pt', 'jet 1 b-tag', 'jet 2 b-tag', 'jet 3 b-tag', 'jet 4 b-tag'], inplace=True)
# ```end-dropping-columns

# ```python
# Prepare data for training
X_train = train_data.drop('Target', axis=1)
y_train = train_data['Target']
X_test = test_data.drop('Target', axis=1)
y_test = test_data['Target']

# Train a Random Forest Classifier
clf = RandomForestClassifier(n_estimators=100, random_state=0)
clf.fit(X_train, y_train)

# Make predictions on the test set
y_pred = clf.predict(X_test)

# Report evaluation based on only test dataset
Accuracy = accuracy_score(y_test, y_pred)
F1_score = f1_score(y_test, y_pred)

print(f"Accuracy:{Accuracy}")   
print(f"F1_score:{F1_score}") 
# ```end