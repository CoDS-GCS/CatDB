# ```python
# Import all required packages
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv("data/IMDB.drama/IMDB.drama_train.csv")
test_data = pd.read_csv("data/IMDB.drama/IMDB.drama_test.csv")
# ```end

# ```python
# Define the pipeline
pipeline = Pipeline([
    ('scaler', StandardScaler()), 
    ('classifier', LogisticRegression())
])
# ```end

# ```python
# Fit the pipeline on the training data
X_train = train_data.drop(columns=['Drama'])
y_train = train_data['Drama']
pipeline.fit(X_train, y_train)
# ```end

# ```python
# Predict on the test data
X_test = test_data.drop(columns=['Drama'])
y_test = test_data['Drama']
y_pred = pipeline.predict(X_test)
# ```end

# ```python
# Report evaluation based on only test dataset
Accuracy = accuracy_score(y_test, y_pred)
F1_score = f1_score(y_test, y_pred)

print(f"Accuracy: {Accuracy}")
print(f"F1_score: {F1_score}")
# ```end