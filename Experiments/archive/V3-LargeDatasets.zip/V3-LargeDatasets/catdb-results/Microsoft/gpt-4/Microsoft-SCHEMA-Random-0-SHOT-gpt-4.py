# ```python
# Import all required packages
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

# Load the datasets
train_data = pd.read_csv('data/Microsoft/Microsoft_train.csv')
test_data = pd.read_csv('data/Microsoft/Microsoft_test.csv')

# Feature: Total_term_frequency
# Usefulness: This feature combines the term frequency from different parts of the document (body, url, anchor, title, whole document). It can be useful to classify 'relevance' as it gives an overall idea of the term frequency in the entire document.
train_data['Total_term_frequency'] = train_data['sum_of_term_frequency-body'] + train_data['sum_of_term_frequency-url'] + train_data['sum_of_term_frequency-anchor'] + train_data['sum_of_term_frequency-title'] + train_data['sum_of_term_frequency-whole_document']
test_data['Total_term_frequency'] = test_data['sum_of_term_frequency-body'] + test_data['sum_of_term_frequency-url'] + test_data['sum_of_term_frequency-anchor'] + test_data['sum_of_term_frequency-title'] + test_data['sum_of_term_frequency-whole_document']

# Feature: Total_stream_length
# Usefulness: This feature combines the stream length from different parts of the document (body, url, anchor, title, whole document). It can be useful to classify 'relevance' as it gives an overall idea of the stream length in the entire document.
train_data['Total_stream_length'] = train_data['stream_length-body'] + train_data['stream_length-url'] + train_data['stream_length-anchor'] + train_data['stream_length-title'] + train_data['stream_length-whole_document']
test_data['Total_stream_length'] = test_data['stream_length-body'] + test_data['stream_length-url'] + test_data['stream_length-anchor'] + test_data['stream_length-title'] + test_data['stream_length-whole_document']

# Dropping columns
# Explanation: The individual term frequency and stream length columns are dropped as they are now represented by the new features 'Total_term_frequency' and 'Total_stream_length'.
train_data.drop(columns=['sum_of_term_frequency-body', 'sum_of_term_frequency-url', 'sum_of_term_frequency-anchor', 'sum_of_term_frequency-title', 'sum_of_term_frequency-whole_document', 'stream_length-body', 'stream_length-url', 'stream_length-anchor', 'stream_length-title', 'stream_length-whole_document'], inplace=True)
test_data.drop(columns=['sum_of_term_frequency-body', 'sum_of_term_frequency-url', 'sum_of_term_frequency-anchor', 'sum_of_term_frequency-title', 'sum_of_term_frequency-whole_document', 'stream_length-body', 'stream_length-url', 'stream_length-anchor', 'stream_length-title', 'stream_length-whole_document'], inplace=True)

# Define the target variable and the feature matrix
y_train = train_data['relevance']
X_train = train_data.drop(columns=['relevance'])
y_test = test_data['relevance']
X_test = test_data.drop(columns=['relevance'])

# Create a pipeline with a standard scaler and a random forest classifier
pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('classifier', RandomForestClassifier())
])

# Fit the pipeline on the training data
pipeline.fit(X_train, y_train)

# Predict the target variable on the test data
y_pred = pipeline.predict(X_test)

# Report evaluation based on only test dataset
# Calculate the model accuracy
Accuracy = accuracy_score(y_test, y_pred)

# Calculate the model log loss
y_pred_proba = pipeline.predict_proba(X_test)
Log_loss = log_loss(y_test, y_pred_proba)

# Print the accuracy result
print(f"Accuracy: {Accuracy}")

# Print the log loss result
print(f"Log_loss: {Log_loss}")
# ```end