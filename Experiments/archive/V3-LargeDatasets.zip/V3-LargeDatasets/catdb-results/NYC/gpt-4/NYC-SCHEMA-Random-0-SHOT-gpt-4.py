# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from datetime import datetime
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/NYC/NYC_train.csv')
test_data = pd.read_csv('data/NYC/NYC_test.csv')
# ```end

# ```python 
# Feature: Duration
# Usefulness: The duration of the trip could be a useful feature as longer trips might cost more.
train_data['tpep_pickup_datetime'] = pd.to_datetime(train_data['tpep_pickup_datetime'])
train_data['tpep_dropoff_datetime'] = pd.to_datetime(train_data['tpep_dropoff_datetime'])
train_data['duration'] = (train_data['tpep_dropoff_datetime'] - train_data['tpep_pickup_datetime']).dt.total_seconds() / 60

test_data['tpep_pickup_datetime'] = pd.to_datetime(test_data['tpep_pickup_datetime'])
test_data['tpep_dropoff_datetime'] = pd.to_datetime(test_data['tpep_dropoff_datetime'])
test_data['duration'] = (test_data['tpep_dropoff_datetime'] - test_data['tpep_pickup_datetime']).dt.total_seconds() / 60
# ```end

# ```python 
# Feature: Distance
# Usefulness: The distance between pickup and dropoff location might be a useful feature as longer distances might cost more.
train_data['distance'] = np.sqrt((train_data['pickup_latitude'] - train_data['dropoff_latitude'])**2 + (train_data['pickup_longitude'] - train_data['dropoff_longitude'])**2)

test_data['distance'] = np.sqrt((test_data['pickup_latitude'] - test_data['dropoff_latitude'])**2 + (test_data['pickup_longitude'] - test_data['dropoff_longitude'])**2)
# ```end

# ```python-dropping-columns
# Explanation why the column XX is dropped
# The columns 'tpep_pickup_datetime', 'tpep_dropoff_datetime', 'pickup_latitude', 'pickup_longitude', 'dropoff_latitude', 'dropoff_longitude' are dropped because we have created new features 'duration' and 'distance' from them.
train_data.drop(columns=['tpep_pickup_datetime', 'tpep_dropoff_datetime', 'pickup_latitude', 'pickup_longitude', 'dropoff_latitude', 'dropoff_longitude'], inplace=True)
test_data.drop(columns=['tpep_pickup_datetime', 'tpep_dropoff_datetime', 'pickup_latitude', 'pickup_longitude', 'dropoff_latitude', 'dropoff_longitude'], inplace=True)
# ```end-dropping-columns

# ```python
# Regression model training
X_train = train_data.drop('total_amount', axis=1)
y_train = train_data['total_amount']

X_test = test_data.drop('total_amount', axis=1)
y_test = test_data['total_amount']

model = LinearRegression()
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Report evaluation based on only test dataset
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end