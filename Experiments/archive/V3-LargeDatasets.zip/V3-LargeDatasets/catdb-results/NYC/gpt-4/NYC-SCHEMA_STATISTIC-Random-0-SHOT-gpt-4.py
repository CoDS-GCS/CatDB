# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from math import sqrt
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/NYC/NYC_train.csv')
test_data = pd.read_csv('data/NYC/NYC_test.csv')
# ```end

# ```python 
# Feature: Duration of the trip in minutes
# Usefulness: The duration of the trip can be a good indicator of the total amount as longer trips usually cost more.
train_data['trip_duration'] = (pd.to_datetime(train_data['tpep_dropoff_datetime']) - pd.to_datetime(train_data['tpep_pickup_datetime'])).dt.total_seconds() / 60
test_data['trip_duration'] = (pd.to_datetime(test_data['tpep_dropoff_datetime']) - pd.to_datetime(test_data['tpep_pickup_datetime'])).dt.total_seconds() / 60
# ```end 

# ```python 
# Feature: Distance between pickup and dropoff location
# Usefulness: The distance between pickup and dropoff location can also be a good indicator of the total amount as longer distances usually cost more.
train_data['distance'] = np.sqrt((train_data['pickup_latitude'] - train_data['dropoff_latitude'])**2 + (train_data['pickup_longitude'] - train_data['dropoff_longitude'])**2)
test_data['distance'] = np.sqrt((test_data['pickup_latitude'] - test_data['dropoff_latitude'])**2 + (test_data['pickup_longitude'] - test_data['dropoff_longitude'])**2)
# ```end 

# ```python-dropping-columns
# Explanation why the column XX is dropped
# The columns 'tpep_pickup_datetime', 'tpep_dropoff_datetime', 'pickup_latitude', 'pickup_longitude', 'dropoff_latitude', 'dropoff_longitude' are dropped because we have created new features 'trip_duration' and 'distance' which capture the necessary information from these columns.
train_data.drop(columns=['tpep_pickup_datetime', 'tpep_dropoff_datetime', 'pickup_latitude', 'pickup_longitude', 'dropoff_latitude', 'dropoff_longitude'], inplace=True)
test_data.drop(columns=['tpep_pickup_datetime', 'tpep_dropoff_datetime', 'pickup_latitude', 'pickup_longitude', 'dropoff_latitude', 'dropoff_longitude'], inplace=True)
# ```end-dropping-columns

# ```python
# Prepare the data for the model
X_train = train_data.drop('total_amount', axis=1)
y_train = train_data['total_amount']
X_test = test_data.drop('total_amount', axis=1)
y_test = test_data['total_amount']

# Train the model
model = LinearRegression()
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)

# Report evaluation based on only test dataset
R_Squared = r2_score(y_test, y_pred)
RMSE = sqrt(mean_squared_error(y_test, y_pred))

print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end