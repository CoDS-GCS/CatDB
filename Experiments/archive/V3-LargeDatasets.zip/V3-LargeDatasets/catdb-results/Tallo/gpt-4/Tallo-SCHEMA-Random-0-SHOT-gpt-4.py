# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/Tallo/Tallo_train.csv')
test_data = pd.read_csv('data/Tallo/Tallo_test.csv')
# ```end

# ```python 
# Feature name and description: Rainfall_Temperature_Interaction
# Usefulness: This feature captures the interaction between mean annual rainfall and mean annual temperature. 
# In real world, the growth of a tree (and hence its height) is influenced by both rainfall and temperature. 
# Therefore, this feature could be useful for predicting 'height_m'.
train_data['Rainfall_Temperature_Interaction'] = train_data['mean_annual_rainfall'] * train_data['mean_annual_temperature']
test_data['Rainfall_Temperature_Interaction'] = test_data['mean_annual_rainfall'] * test_data['mean_annual_temperature']
# ```end 

# ```python 
# Feature name and description: Latitude_Longitude_Interaction
# Usefulness: This feature captures the interaction between latitude and longitude. 
# The geographical location of a tree can influence its growth and height. 
# Therefore, this feature could be useful for predicting 'height_m'.
train_data['Latitude_Longitude_Interaction'] = train_data['latitude'] * train_data['longitude']
test_data['Latitude_Longitude_Interaction'] = test_data['latitude'] * test_data['longitude']
# ```end 

# ```python-dropping-columns
# Explanation why the column 'reference_id' is dropped: 
# 'reference_id' is just an identifier and does not contain any useful information for predicting 'height_m'.
train_data.drop(columns=['reference_id'], inplace=True)
test_data.drop(columns=['reference_id'], inplace=True)
# ```end-dropping-columns

# ```python-dropping-columns
# Explanation why the column 'genus' is dropped: 
# 'genus' is a categorical variable with potentially many unique values. 
# Including it in the model could lead to overfitting, especially if the dataset is small.
train_data.drop(columns=['genus'], inplace=True)
test_data.drop(columns=['genus'], inplace=True)
# ```end-dropping-columns

# ```python
# Prepare the data for regression
X_train = train_data.drop('height_m', axis=1)
y_train = train_data['height_m']
X_test = test_data.drop('height_m', axis=1)
y_test = test_data['height_m']

# Fit the model
model = LinearRegression()
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)

# Report evaluation based on only test dataset
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

# Print the accuracy result
print(f"R_Squared:{R_Squared}")   

# Print the log loss result
print(f"RMSE:{RMSE}") 
# ```end