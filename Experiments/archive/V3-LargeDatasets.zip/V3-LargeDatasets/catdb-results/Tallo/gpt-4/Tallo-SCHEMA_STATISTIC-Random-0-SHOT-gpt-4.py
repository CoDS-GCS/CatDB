# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import LabelEncoder
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv("data/Tallo/Tallo_train.csv")
test_data = pd.read_csv("data/Tallo/Tallo_test.csv")
# ```end

# ```python 
# Feature: Rainfall per Temperature
# Usefulness: This feature could be useful as it combines two environmental factors that could influence the height of a tree. 
train_data['rainfall_per_temperature'] = train_data['mean_annual_rainfall'] / train_data['mean_annual_temperature']
test_data['rainfall_per_temperature'] = test_data['mean_annual_rainfall'] / test_data['mean_annual_temperature']
# ```end 

# ```python 
# Feature: Temperature per Rainfall
# Usefulness: This feature could be useful as it combines two environmental factors that could influence the height of a tree. 
train_data['temperature_per_rainfall'] = train_data['mean_annual_temperature'] / train_data['mean_annual_rainfall']
test_data['temperature_per_rainfall'] = test_data['mean_annual_temperature'] / test_data['mean_annual_rainfall']
# ```end 

# ```python 
# Feature: Stem Diameter per Rainfall
# Usefulness: This feature could be useful as it combines the physical characteristic of a tree (stem diameter) with an environmental factor (rainfall) that could influence the height of a tree. 
train_data['stem_diameter_per_rainfall'] = train_data['stem_diameter_cm'] / train_data['mean_annual_rainfall']
test_data['stem_diameter_per_rainfall'] = test_data['stem_diameter_cm'] / test_data['mean_annual_rainfall']
# ```end 

# ```python-dropping-columns
# Explanation why the column 'crown_radius_outlier' is dropped
# The 'crown_radius_outlier' column is dropped because it has only one distinct value and thus does not provide any useful information for the model.
train_data.drop(columns=['crown_radius_outlier'], inplace=True)
test_data.drop(columns=['crown_radius_outlier'], inplace=True)
# ```end-dropping-columns

# ```python-dropping-columns
# Explanation why the column 'height_outlier' is dropped
# The 'height_outlier' column is dropped because it has only one distinct value and thus does not provide any useful information for the model.
train_data.drop(columns=['height_outlier'], inplace=True)
test_data.drop(columns=['height_outlier'], inplace=True)
# ```end-dropping-columns

# ```python
# Handle categorical variables
le = LabelEncoder()
for column in train_data.columns:
    if train_data[column].dtype == 'object':
        train_data[column] = train_data[column].fillna('NA')
        train_data[column] = le.fit_transform(train_data[column])
        test_data[column] = test_data[column].fillna('NA')
        test_data[column] = le.transform(test_data[column])
# ```end

# ```python
# Train the model
X_train = train_data.drop(columns=['height_m'])
y_train = train_data['height_m']
X_test = test_data.drop(columns=['height_m'])
y_test = test_data['height_m']

model = LinearRegression()
model.fit(X_train, y_train)

# Predict on the test set
y_pred = model.predict(X_test)
# ```end

# ```python
# Report evaluation based on only test dataset
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end