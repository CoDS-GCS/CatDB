# ```python
# Import all required packages
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, mean_squared_error
from math import sqrt
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/Traffic_violations/Traffic_violations_train.csv')
test_data = pd.read_csv('data/Traffic_violations/Traffic_violations_test.csv')
# ```end

# ```python 
# Feature: 'year' 
# Usefulness: The year of the violation could be useful to classify 'violation_type' as the type of violations might change over the years.
# No need to add a new column, 'year' already exists in the dataset.
# ```end 

# ```python 
# Feature: 'commercial_vehicle' 
# Usefulness: Whether the vehicle is commercial or not could be useful to classify 'violation_type' as commercial vehicles might have different types of violations compared to non-commercial vehicles.
# No need to add a new column, 'commercial_vehicle' already exists in the dataset.
# ```end 

# ```python 
# Feature: 'alcohol' 
# Usefulness: Whether alcohol was involved in the violation could be useful to classify 'violation_type' as alcohol-related violations might be different from non-alcohol related violations.
# No need to add a new column, 'alcohol' already exists in the dataset.
# ```end 

# ```python-dropping-columns
# Explanation why the column 'seqid' is dropped
# 'seqid' is just an identifier and does not provide any useful information for the classification of 'violation_type'.
train_data.drop(columns=['seqid'], inplace=True)
test_data.drop(columns=['seqid'], inplace=True)
# ```end-dropping-columns

# ```python-dropping-columns
# Explanation why the column 'description' is dropped
# 'description' is a text field that might contain a lot of unique values and might not be useful for the classification of 'violation_type'.
train_data.drop(columns=['description'], inplace=True)
test_data.drop(columns=['description'], inplace=True)
# ```end-dropping-columns

# ```python
# Convert categorical variables into numerical variables
le = LabelEncoder()
for column in train_data.columns:
    if train_data[column].dtype == 'object':
        train_data[column] = le.fit_transform(train_data[column].astype(str))
for column in test_data.columns:
    if test_data[column].dtype == 'object':
        test_data[column] = le.fit_transform(test_data[column].astype(str))

# Split the data into features and target variable
X_train = train_data.drop('violation_type', axis=1)
y_train = train_data['violation_type']
X_test = test_data.drop('violation_type', axis=1)
y_test = test_data['violation_type']

# Train a Random Forest Classifier
clf = RandomForestClassifier()
clf.fit(X_train, y_train)

# Make predictions on the test set
y_pred = clf.predict(X_test)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy}")

# Calculate R-Squared
R_Squared = clf.score(X_test, y_test)
print(f"R_Squared: {R_Squared}")

# Calculate Root Mean Squared Error
RMSE = sqrt(mean_squared_error(y_test, y_pred))
print(f"RMSE: {RMSE}")
# ```end