# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/USCars/USCars_train.csv')
test_data = pd.read_csv('data/USCars/USCars_test.csv')
# ```end

# ```python 
# Feature: Age of the car
# Usefulness: The age of the car can be a significant factor in determining its price. Older cars tend to be cheaper.
train_data['age'] = 2022 - train_data['year']
test_data['age'] = 2022 - test_data['year']
# ```end 

# ```python 
# Feature: Car was previously in an accident
# Usefulness: Cars that have been in an accident may have a lower price due to potential damage.
train_data['was_in_accident'] = train_data['has_accidents'].apply(lambda x: 1 if x > 0 else 0)
test_data['was_in_accident'] = test_data['has_accidents'].apply(lambda x: 1 if x > 0 else 0)
# ```end 

# ```python-dropping-columns
# Explanation why the column 'main_picture_url' is dropped
# The 'main_picture_url' column is dropped because it is a URL and does not provide any useful information for the regression model.
train_data.drop(columns=['main_picture_url'], inplace=True)
test_data.drop(columns=['main_picture_url'], inplace=True)
# ```end-dropping-columns

# ```python-dropping-columns
# Explanation why the column 'vin' is dropped
# The 'vin' column is dropped because it is a unique identifier for each vehicle and does not provide any useful information for the regression model.
train_data.drop(columns=['vin'], inplace=True)
test_data.drop(columns=['vin'], inplace=True)
# ```end-dropping-columns

# ```python
# Define the model
model = LinearRegression()

# Define the features and target
features = ['horsepower', 'age', 'was_in_accident', 'savings_amount', 'owner_count', 'combine_fuel_economy', 'engine_displacement', 'vehicle_damage_category', 'highway_fuel_economy', 'city_fuel_economy', 'daysonmarket', 'mileage']
target = 'price'

# Train the model
model.fit(train_data[features], train_data[target])

# Make predictions
predictions = model.predict(test_data[features])

# Calculate R-Squared
R_Squared = r2_score(test_data[target], predictions)

# Calculate Root Mean Squared Error
RMSE = np.sqrt(mean_squared_error(test_data[target], predictions))

# Print the results
print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end