# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv("data/USCars/USCars_train.csv")
test_data = pd.read_csv("data/USCars/USCars_test.csv")
# ```end

# ```python 
# Feature: Age of the car
# Usefulness: The age of the car can be a significant factor in determining its price. Older cars tend to be cheaper.
train_data['age'] = 2021 - train_data['year']
test_data['age'] = 2021 - test_data['year']
# ```end 

# ```python 
# Feature: Car has accidents or not
# Usefulness: Cars that have been in accidents may have a lower price due to potential damage.
# Fill missing values with 0 (assuming no accident if not reported)
train_data['has_accidents'].fillna(0, inplace=True)
test_data['has_accidents'].fillna(0, inplace=True)
# ```end 

# ```python 
# Feature: Owner count
# Usefulness: The number of previous owners can affect the price. Cars with more owners may be cheaper.
# Fill missing values with the median
train_data['owner_count'].fillna(train_data['owner_count'].median(), inplace=True)
test_data['owner_count'].fillna(test_data['owner_count'].median(), inplace=True)
# ```end 

# ```python-dropping-columns
# Dropping columns that have too many missing values or do not provide useful information for price prediction
# Columns 'combine_fuel_economy', 'is_oemcpo', 'vehicle_damage_category', 'is_certified', 'wheelbase', 'bed_length', 'cabin', 'bed_height' have too many missing values
# Columns 'trimId', 'main_picture_url', 'vin', 'listing_id', 'sp_id', 'dealer_zip' do not provide useful information for price prediction
train_data.drop(columns=['trimId', 'main_picture_url', 'vin', 'combine_fuel_economy', 'is_oemcpo', 'vehicle_damage_category', 'is_certified', 'wheelbase', 'bed_length', 'cabin', 'bed_height', 'listing_id', 'sp_id', 'dealer_zip'], inplace=True)
test_data.drop(columns=['trimId', 'main_picture_url', 'vin', 'combine_fuel_economy', 'is_oemcpo', 'vehicle_damage_category', 'is_certified', 'wheelbase', 'bed_length', 'cabin', 'bed_height', 'listing_id', 'sp_id', 'dealer_zip'], inplace=True)
# ```end-dropping-columns

# ```python
# Preprocessing: Label encoding for categorical features
le = LabelEncoder()
for col in train_data.columns:
    if train_data[col].dtype == 'object':
        train_data[col] = train_data[col].fillna('NA')
        train_data[col] = le.fit_transform(train_data[col])
        test_data[col] = test_data[col].fillna('NA')
        test_data[col] = le.transform(test_data[col])
# ```end

# ```python
# Regression model training
X_train = train_data.drop(columns=['price'])
y_train = train_data['price']
X_test = test_data.drop(columns=['price'])
y_test = test_data['price']

model = LinearRegression()
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)
# ```end

# ```python
# Report evaluation based on only test dataset
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end