# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/beer_reviews/beer_reviews_train.csv')
test_data = pd.read_csv('data/beer_reviews/beer_reviews_test.csv')
# ```end

# ```python 
# Feature: review_length
# Usefulness: The length of the review might be indicative of the beer style. Some styles might elicit more verbose reviews.
train_data['review_length'] = train_data['review_profilename'].apply(len)
test_data['review_length'] = test_data['review_profilename'].apply(len)
# ```end 

# ```python 
# Feature: brewery_freq
# Usefulness: The frequency of the brewery might be indicative of the beer style. Some breweries might specialize in certain styles.
brewery_freq = train_data['brewery_name'].value_counts().to_dict()
train_data['brewery_freq'] = train_data['brewery_name'].map(brewery_freq)
test_data['brewery_freq'] = test_data['brewery_name'].map(brewery_freq)
# ```end 

# ```python-dropping-columns
# Explanation why the column review_profilename is dropped
# The review_profilename is dropped because it is a unique identifier for each review and does not provide any useful information for the classification task.
train_data.drop(columns=['review_profilename'], inplace=True)
test_data.drop(columns=['review_profilename'], inplace=True)
# ```end-dropping-columns

# ```python-dropping-columns
# Explanation why the column beer_name is dropped
# The beer_name is dropped because it is a unique identifier for each beer and does not provide any useful information for the classification task.
train_data.drop(columns=['beer_name'], inplace=True)
test_data.drop(columns=['beer_name'], inplace=True)
# ```end-dropping-columns

# ```python
# Label encoding for the target variable 'beer_style'
le = LabelEncoder()
train_data['beer_style'] = le.fit_transform(train_data['beer_style'])
test_data['beer_style'] = le.transform(test_data['beer_style'])
# ```end

# ```python
# Train a RandomForestClassifier
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(train_data.drop('beer_style', axis=1), train_data['beer_style'])

# Predict the classes and class probabilities
preds = clf.predict(test_data.drop('beer_style', axis=1))
probs = clf.predict_proba(test_data.drop('beer_style', axis=1))
# ```end

# ```python
# Report evaluation based on only test dataset
Accuracy = accuracy_score(test_data['beer_style'], preds)
Log_loss = log_loss(test_data['beer_style'], probs)

print(f"Accuracy: {Accuracy}")
print(f"Log_loss: {Log_loss}")
# ```end