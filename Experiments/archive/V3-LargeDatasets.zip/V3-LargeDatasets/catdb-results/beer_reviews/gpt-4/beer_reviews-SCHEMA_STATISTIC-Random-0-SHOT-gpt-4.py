# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/beer_reviews/beer_reviews_train.csv')
test_data = pd.read_csv('data/beer_reviews/beer_reviews_test.csv')
# ```end

# ```python
# Feature: review_profilename_encoded
# Usefulness: Encoding the review_profilename can help the model to understand the correlation between the reviewer and the beer_style.
label_encoder = LabelEncoder()
train_data['review_profilename_encoded'] = label_encoder.fit_transform(train_data['review_profilename'].astype(str))
test_data['review_profilename_encoded'] = label_encoder.transform(test_data['review_profilename'].astype(str))
# ```end

# ```python
# Feature: brewery_id_encoded
# Usefulness: Encoding the brewery_id can help the model to understand the correlation between the brewery and the beer_style.
label_encoder = LabelEncoder()
train_data['brewery_id_encoded'] = label_encoder.fit_transform(train_data['brewery_id'])
test_data['brewery_id_encoded'] = label_encoder.transform(test_data['brewery_id'])
# ```end

# ```python
# Feature: beer_beerid_encoded
# Usefulness: Encoding the beer_beerid can help the model to understand the correlation between the beer and the beer_style.
label_encoder = LabelEncoder()
train_data['beer_beerid_encoded'] = label_encoder.fit_transform(train_data['beer_beerid'])
test_data['beer_beerid_encoded'] = label_encoder.transform(test_data['beer_beerid'])
# ```end

# ```python-dropping-columns
# Explanation why the column review_profilename, brewery_id, beer_beerid are dropped
# These columns are dropped because they have been encoded and the original columns are no longer needed.
train_data.drop(columns=['review_profilename', 'brewery_id', 'beer_beerid'], inplace=True)
test_data.drop(columns=['review_profilename', 'brewery_id', 'beer_beerid'], inplace=True)
# ```end-dropping-columns

# ```python
# Prepare the data for the model
X_train = train_data.drop(columns=['beer_style'])
y_train = train_data['beer_style']
X_test = test_data.drop(columns=['beer_style'])
y_test = test_data['beer_style']

# Encode the target variable
label_encoder = LabelEncoder()
y_train = label_encoder.fit_transform(y_train)
y_test = label_encoder.transform(y_test)

# Train the model
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)
y_pred_proba = model.predict_proba(X_test)

# Report evaluation based on only test dataset
Accuracy = accuracy_score(y_test, y_pred)
Log_loss = log_loss(y_test, y_pred_proba)

print(f"Accuracy:{Accuracy}")   
print(f"Log_loss:{Log_loss}") 
# ```end