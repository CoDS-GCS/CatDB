# ```python
# Import all required packages
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/sf-police-incidents/sf-police-incidents_train.csv')
test_data = pd.read_csv('data/sf-police-incidents/sf-police-incidents_test.csv')
# ```end

# ```python 
# Feature: DayTime
# Usefulness: The time of day can be a useful feature as certain crimes may be more likely to occur at certain times of the day. 
train_data['DayTime'] = train_data['Hour'].apply(lambda x: 'morning' if 5<=x<12 else 'afternoon' if 12<=x<17 else 'evening' if 17<=x<21 else 'night')
test_data['DayTime'] = test_data['Hour'].apply(lambda x: 'morning' if 5<=x<12 else 'afternoon' if 12<=x<17 else 'evening' if 17<=x<21 else 'night')
# ```end 

# ```python 
# Feature: Weekend
# Usefulness: The day of the week can be a useful feature as certain crimes may be more likely to occur on weekends. 
train_data['Weekend'] = train_data['DayOfWeek'].apply(lambda x: 1 if x>=5 else 0)
test_data['Weekend'] = test_data['DayOfWeek'].apply(lambda x: 1 if x>=5 else 0)
# ```end 

# ```python-dropping-columns
# Explanation why the column Address is dropped
# The address is a high cardinality feature and may lead to overfitting. Therefore, it is dropped.
train_data.drop(columns=['Address'], inplace=True)
test_data.drop(columns=['Address'], inplace=True)
# ```end-dropping-columns

# ```python
# Label encoding for categorical features
le = LabelEncoder()
train_data['PdDistrict'] = le.fit_transform(train_data['PdDistrict'])
test_data['PdDistrict'] = le.transform(test_data['PdDistrict'])
train_data['DayTime'] = le.fit_transform(train_data['DayTime'])
test_data['DayTime'] = le.transform(test_data['DayTime'])
train_data['ViolentCrime'] = le.fit_transform(train_data['ViolentCrime'])
test_data['ViolentCrime'] = le.transform(test_data['ViolentCrime'])
# ```end

# ```python
# Binary classification
X_train = train_data.drop('ViolentCrime', axis=1)
y_train = train_data['ViolentCrime']
X_test = test_data.drop('ViolentCrime', axis=1)
y_test = test_data['ViolentCrime']

clf = RandomForestClassifier()
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)
# ```end

# ```python
# Report evaluation based on only test dataset
Accuracy = accuracy_score(y_test, y_pred)
F1_score = f1_score(y_test, y_pred)
print(f"Accuracy:{Accuracy}")   
print(f"F1_score:{F1_score}") 
# ```end