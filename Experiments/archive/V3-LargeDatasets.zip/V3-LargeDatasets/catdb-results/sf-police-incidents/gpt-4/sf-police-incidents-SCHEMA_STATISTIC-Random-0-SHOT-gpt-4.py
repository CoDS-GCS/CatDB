# ```python
# Import all required packages
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/sf-police-incidents/sf-police-incidents_train.csv')
test_data = pd.read_csv('data/sf-police-incidents/sf-police-incidents_test.csv')
# ```end

# ```python 
# Feature: 'Night' (binary: 1 if Hour is between 20 and 5, 0 otherwise)
# Usefulness: Crimes might be more likely to be violent during the night.
train_data['Night'] = ((train_data['Hour'] >= 20) | (train_data['Hour'] <= 5)).astype(int)
test_data['Night'] = ((test_data['Hour'] >= 20) | (test_data['Hour'] <= 5)).astype(int)
# ```end 

# ```python 
# Feature: 'Weekend' (binary: 1 if DayOfWeek is Saturday or Sunday, 0 otherwise)
# Usefulness: Crimes might be more likely to be violent during the weekend.
train_data['Weekend'] = (train_data['DayOfWeek'] >= 6).astype(int)
test_data['Weekend'] = (test_data['DayOfWeek'] >= 6).astype(int)
# ```end 

# ```python-dropping-columns
# Explanation why the column 'Address' is dropped: 
# The 'Address' column is a text field with a high cardinality, which might lead to overfitting. 
# Moreover, the 'X' and 'Y' columns already provide location information.
train_data.drop(columns=['Address'], inplace=True)
test_data.drop(columns=['Address'], inplace=True)
# ```end-dropping-columns

# ```python
# Convert 'ViolentCrime' and 'PdDistrict' to numerical values using LabelEncoder
le = LabelEncoder()
train_data['ViolentCrime'] = le.fit_transform(train_data['ViolentCrime'])
test_data['ViolentCrime'] = le.transform(test_data['ViolentCrime'])

train_data['PdDistrict'] = le.fit_transform(train_data['PdDistrict'])
test_data['PdDistrict'] = le.transform(test_data['PdDistrict'])

# Define the features and the target
features = train_data.drop(columns=['ViolentCrime']).columns
target = 'ViolentCrime'

# Train a RandomForestClassifier
clf = RandomForestClassifier(random_state=42)
clf.fit(train_data[features], train_data[target])

# Make predictions on the test set
predictions = clf.predict(test_data[features])

# Report evaluation based on only test dataset
Accuracy = accuracy_score(test_data[target], predictions)
F1_score = f1_score(test_data[target], predictions)

print(f"Accuracy:{Accuracy}")   
print(f"F1_score:{F1_score}") 
# ```end