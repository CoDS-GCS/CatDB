# ```python
# Import all required packages
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/simulated_electricity/simulated_electricity_train.csv')
test_data = pd.read_csv('data/simulated_electricity/simulated_electricity_test.csv')
# ```end

# ```python 
# Feature: Price Difference (vicprice - nswprice)
# Usefulness: The difference in price between the two regions could be a significant factor in determining the class. 
train_data['price_diff'] = train_data['vicprice'] - train_data['nswprice']
test_data['price_diff'] = test_data['vicprice'] - test_data['nswprice']
# ```end 

# ```python 
# Feature: Demand Difference (vicdemand - nswdemand)
# Usefulness: The difference in demand between the two regions could also be a significant factor in determining the class. 
train_data['demand_diff'] = train_data['vicdemand'] - train_data['nswdemand']
test_data['demand_diff'] = test_data['vicdemand'] - test_data['nswdemand']
# ```end 

# ```python-dropping-columns
# Explanation why the column 'date' is dropped: The 'date' column is dropped because it is a continuous variable that does not provide any meaningful information for the classification task.
train_data.drop(columns=['date'], inplace=True)
test_data.drop(columns=['date'], inplace=True)
# ```end-dropping-columns

# ```python
# Convert the class column to numerical values
le = LabelEncoder()
train_data['class'] = le.fit_transform(train_data['class'])
test_data['class'] = le.transform(test_data['class'])

# Separate the features and the target variable
X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']

# Train a Random Forest Classifier
clf = RandomForestClassifier()
clf.fit(X_train, y_train)

# Make predictions on the test set
y_pred = clf.predict(X_test)

# Report evaluation based on only test dataset
Accuracy = accuracy_score(y_test, y_pred)
F1_score = f1_score(y_test, y_pred)

print(f"Accuracy:{Accuracy}")   
print(f"F1_score:{F1_score}") 
# ```end