# ```python
# Import all required packages
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score

# Load the datasets
train_data = pd.read_csv('data/BNG_credit_g/BNG_credit_g_train.csv')
test_data = pd.read_csv('data/BNG_credit_g/BNG_credit_g_test.csv')

# Label encoding for categorical variables
label_encoder = LabelEncoder()
categorical_features = ['other_payment_plans', 'own_telephone', 'foreign_worker', 'property_magnitude', 'personal_status', 'checking_status', 'job', 'purpose', 'other_parties', 'savings_status', 'credit_history', 'employment', 'housing']
for feature in categorical_features:
    train_data[feature] = label_encoder.fit_transform(train_data[feature])
    test_data[feature] = label_encoder.transform(test_data[feature])

# Feature: Total financial commitment
# Usefulness: This feature represents the total financial commitment of a person, which is a combination of the number of dependents, existing credits, and installment commitment. This can be a useful feature as it can indicate the financial stability of a person.
train_data['total_financial_commitment'] = train_data['num_dependents'] + train_data['existing_credits'] + train_data['installment_commitment']
test_data['total_financial_commitment'] = test_data['num_dependents'] + test_data['existing_credits'] + test_data['installment_commitment']

# Feature: Stability index
# Usefulness: This feature represents the stability of a person, which is a combination of the residence since and age. This can be a useful feature as it can indicate the stability of a person.
train_data['stability_index'] = train_data['residence_since'] / train_data['age']
test_data['stability_index'] = test_data['residence_since'] / test_data['age']

# Dropping columns
# Explanation: The columns 'num_dependents', 'residence_since', 'installment_commitment', 'existing_credits' are dropped as they are now represented by the new features 'total_financial_commitment' and 'stability_index'.
train_data.drop(columns=['num_dependents', 'residence_since', 'installment_commitment', 'existing_credits'], inplace=True)
test_data.drop(columns=['num_dependents', 'residence_since', 'installment_commitment', 'existing_credits'], inplace=True)

# Binary classification
# Convert class to binary
train_data['class'] = train_data['class'].map({'good': 1, 'bad': 0})
test_data['class'] = test_data['class'].map({'good': 1, 'bad': 0})

# Define the features and target
X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']

# Train the model
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Predict the test data
y_pred = model.predict(X_test)

# Report evaluation based on only test dataset
Accuracy = accuracy_score(y_test, y_pred)
F1_score = f1_score(y_test, y_pred)

print(f"Accuracy:{Accuracy}")
print(f"F1_score:{F1_score}")
# ```end