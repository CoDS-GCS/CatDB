# ```python
# Import all required packages
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np

# Load the datasets
train_data = pd.read_csv('data/Buzzinsocialmedia_Twitter/Buzzinsocialmedia_Twitter_train.csv')
test_data = pd.read_csv('data/Buzzinsocialmedia_Twitter/Buzzinsocialmedia_Twitter_test.csv')

# Add new features
# Total number of discussions
# Usefulness: This feature gives us the total number of discussions which can be a good indicator of the buzz.
train_data['Total_ND'] = train_data['NCD_0'] + train_data['NCD_1'] + train_data['NCD_2'] + train_data['NCD_3'] + train_data['NCD_4'] + train_data['NCD_5'] + train_data['NCD_6']
test_data['Total_ND'] = test_data['NCD_0'] + test_data['NCD_1'] + test_data['NCD_2'] + test_data['NCD_3'] + test_data['NCD_4'] + test_data['NCD_5'] + test_data['NCD_6']

# Total number of authors
# Usefulness: This feature gives us the total number of authors which can be a good indicator of the buzz.
train_data['Total_NA'] = train_data['NA_0'] + train_data['NA_1'] + train_data['NA_2'] + train_data['NA_3'] + train_data['NA_4'] + train_data['NA_5'] + train_data['NA_6']
test_data['Total_NA'] = test_data['NA_0'] + test_data['NA_1'] + test_data['NA_2'] + test_data['NA_3'] + test_data['NA_4'] + test_data['NA_5'] + test_data['NA_6']

# Drop unused columns
# Explanation: The individual day columns are dropped as we have created a total column which is more useful.
train_data.drop(columns=['NCD_0', 'NCD_1', 'NCD_2', 'NCD_3', 'NCD_4', 'NCD_5', 'NCD_6', 'NA_0', 'NA_1', 'NA_2', 'NA_3', 'NA_4', 'NA_5', 'NA_6'], inplace=True)
test_data.drop(columns=['NCD_0', 'NCD_1', 'NCD_2', 'NCD_3', 'NCD_4', 'NCD_5', 'NCD_6', 'NA_0', 'NA_1', 'NA_2', 'NA_3', 'NA_4', 'NA_5', 'NA_6'], inplace=True)

# Define the pipeline
numeric_features = train_data.columns.drop('Annotation')
numeric_transformer = Pipeline(steps=[
    ('scaler', StandardScaler())])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numeric_features)])

regressor = Pipeline(steps=[('preprocessor', preprocessor),
                      ('classifier', LinearRegression())])

# Fit the model
X_train = train_data.drop('Annotation', axis=1)
y_train = train_data['Annotation']
X_test = test_data.drop('Annotation', axis=1)
y_test = test_data['Annotation']

regressor.fit(X_train, y_train)

# Predict the test data
y_pred = regressor.predict(X_test)

# Report evaluation based on only test dataset
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end