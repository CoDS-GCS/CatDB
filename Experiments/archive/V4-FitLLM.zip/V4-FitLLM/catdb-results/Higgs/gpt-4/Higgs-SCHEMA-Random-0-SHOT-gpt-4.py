# ```python
# Import all required packages
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score

# Load the datasets
train_data = pd.read_csv('data/Higgs/Higgs_train.csv')
test_data = pd.read_csv('data/Higgs/Higgs_test.csv')

# Define the target variable
y_train = train_data['Target']
y_test = test_data['Target']

# Drop the target variable from the training and test datasets
X_train = train_data.drop(columns=['Target'])
X_test = test_data.drop(columns=['Target'])

# Add new features
# Total energy: This feature is the sum of the energies of all jets and the lepton. 
# It can be useful to classify 'Target' as it provides information about the total energy in the event.
X_train['total_energy'] = X_train['jet 1 pt'] + X_train['jet 2 pt'] + X_train['jet 3 pt'] + X_train['jet 4 pt'] + X_train['lepton pT']
X_test['total_energy'] = X_test['jet 1 pt'] + X_test['jet 2 pt'] + X_test['jet 3 pt'] + X_test['jet 4 pt'] + X_test['lepton pT']

# Total b-tag: This feature is the sum of the b-tags of all jets. 
# It can be useful to classify 'Target' as it provides information about the total b-tag in the event.
X_train['total_b-tag'] = X_train['jet 1 b-tag'] + X_train['jet 2 b-tag'] + X_train['jet 3 b-tag'] + X_train['jet 4 b-tag']
X_test['total_b-tag'] = X_test['jet 1 b-tag'] + X_test['jet 2 b-tag'] + X_test['jet 3 b-tag'] + X_test['jet 4 b-tag']

# Drop columns
# We drop the 'jet 4 eta' and 'jet 4 phi' columns as they are not very informative for the classification task.
X_train.drop(columns=['jet 4 eta', 'jet 4 phi'], inplace=True)
X_test.drop(columns=['jet 4 eta', 'jet 4 phi'], inplace=True)

# Train a binary classification model
clf = RandomForestClassifier(n_estimators=100, random_state=0)
clf.fit(X_train, y_train)

# Make predictions on the test set
y_pred = clf.predict(X_test)

# Report evaluation based on only test dataset
Accuracy = accuracy_score(y_test, y_pred)
F1_score = f1_score(y_test, y_pred)

print(f"Accuracy:{Accuracy}")
print(f"F1_score:{F1_score}")
# ```end