# ```python
# Import all required packages
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score

# Load the datasets
train_data = pd.read_csv("data/KDD98/KDD98_train.csv")
test_data = pd.read_csv("data/KDD98/KDD98_test.csv")

# Convert categorical variables into numerical variables
le = LabelEncoder()
for column in train_data.columns:
    if train_data[column].dtype == type(object):
        train_data[column] = le.fit_transform(train_data[column])
for column in test_data.columns:
    if test_data[column].dtype == type(object):
        test_data[column] = le.fit_transform(test_data[column])

# Drop columns that are not useful for the downstream classifier
# Explanation: These columns are dropped because they have too many unique values which may cause overfitting.
train_data.drop(columns=['ZIP', 'OSOURCE', 'MDMAUD'], inplace=True)
test_data.drop(columns=['ZIP', 'OSOURCE', 'MDMAUD'], inplace=True)

# Define the target variable and the feature variables
X_train = train_data.drop('TARGET_B', axis=1)
y_train = train_data['TARGET_B']
X_test = test_data.drop('TARGET_B', axis=1)
y_test = test_data['TARGET_B']

# Train the model
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)

# Report evaluation based on only test dataset
Accuracy = accuracy_score(y_test, y_pred)
F1_score = f1_score(y_test, y_pred)

print(f"Accuracy:{Accuracy}")
print(f"F1_score:{F1_score}")
# ```end