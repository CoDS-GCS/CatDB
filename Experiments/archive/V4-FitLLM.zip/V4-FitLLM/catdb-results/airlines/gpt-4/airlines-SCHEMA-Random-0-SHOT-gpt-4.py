# ```python
# Import all required packages
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/airlines/airlines_train.csv')
test_data = pd.read_csv('data/airlines/airlines_test.csv')
# ```end

# ```python
# Feature: DayOfWeek_is_weekend
# Usefulness: Flights on weekends might have different characteristics than on weekdays. This could be useful for the classifier.
train_data['DayOfWeek_is_weekend'] = train_data['DayOfWeek'].apply(lambda x: 1 if x >= 5 else 0)
test_data['DayOfWeek_is_weekend'] = test_data['DayOfWeek'].apply(lambda x: 1 if x >= 5 else 0)
# ```end

# ```python
# Feature: Flight_Length
# Usefulness: The length of the flight might be related to the class. This could be useful for the classifier.
train_data['Flight_Length'] = train_data['Flight'] * train_data['Length']
test_data['Flight_Length'] = test_data['Flight'] * test_data['Length']
# ```end

# ```python
# Feature: Time_of_day
# Usefulness: The time of the flight might be related to the class. This could be useful for the classifier.
train_data['Time_of_day'] = train_data['Time'].apply(lambda x: 'morning' if x < 12 else ('afternoon' if x < 18 else 'evening'))
test_data['Time_of_day'] = test_data['Time'].apply(lambda x: 'morning' if x < 12 else ('afternoon' if x < 18 else 'evening'))
# ```end

# ```python
# Explanation why the column Flight is dropped
# The Flight column is dropped because it has been used to create the Flight_Length feature and is no longer needed.
train_data.drop(columns=['Flight'], inplace=True)
test_data.drop(columns=['Flight'], inplace=True)
# ```end-dropping-columns

# ```python
# Explanation why the column Length is dropped
# The Length column is dropped because it has been used to create the Flight_Length feature and is no longer needed.
train_data.drop(columns=['Length'], inplace=True)
test_data.drop(columns=['Length'], inplace=True)
# ```end-dropping-columns

# ```python
# Encoding categorical features
le = LabelEncoder()
for col in ['AirportFrom', 'Airline', 'AirportTo', 'Time_of_day']:
    train_data[col] = le.fit_transform(train_data[col])
    test_data[col] = le.transform(test_data[col])
# ```end

# ```python
# Train the classifier
X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']

clf = RandomForestClassifier()
clf.fit(X_train, y_train)
# ```end

# ```python
# Report evaluation based on only test dataset
y_pred = clf.predict(X_test)
Accuracy = accuracy_score(y_test, y_pred)
F1_score = f1_score(y_test, y_pred)

print(f"Accuracy:{Accuracy}")
print(f"F1_score:{F1_score}")
# ```end