# ```python
# Import all required packages
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score

# Load the datasets
train_data = pd.read_csv('data/airlines/airlines_train.csv')
test_data = pd.read_csv('data/airlines/airlines_test.csv')

# Label Encoding for categorical variables
le = LabelEncoder()
train_data['AirportFrom'] = le.fit_transform(train_data['AirportFrom'])
train_data['Airline'] = le.fit_transform(train_data['Airline'])
train_data['AirportTo'] = le.fit_transform(train_data['AirportTo'])

test_data['AirportFrom'] = le.transform(test_data['AirportFrom'])
test_data['Airline'] = le.transform(test_data['Airline'])
test_data['AirportTo'] = le.transform(test_data['AirportTo'])

# Feature: Flight Length Category
# Usefulness: Flight length can be an important factor in determining whether a flight will be delayed or not. 
# Longer flights may have more chances of getting delayed due to various factors like weather conditions, technical issues etc.
bins = [0, 200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000, 2200, 2400, 2600, 2800, 3000, 3200, 3400, 3600, 3800, 4000, 4200, 4400, 4600, 4800, 5000, 5200, 5400, 5600, 5800, 6000, 6200, 6400, 6600]
labels = range(33)
train_data['FlightLengthCategory'] = pd.cut(train_data.Length, bins=bins, labels=labels)
test_data['FlightLengthCategory'] = pd.cut(test_data.Length, bins=bins, labels=labels)

# Drop the 'Length' column as we have categorized it into 'FlightLengthCategory'
train_data.drop(columns=['Length'], inplace=True)
test_data.drop(columns=['Length'], inplace=True)

# Define the features and the target
X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']

# Train a Random Forest Classifier
clf = RandomForestClassifier(n_estimators=100, random_state=0)
clf.fit(X_train, y_train)

# Predict the test set results
y_pred = clf.predict(X_test)

# Report evaluation based on only test dataset
Accuracy = accuracy_score(y_test, y_pred)
F1_score = f1_score(y_test, y_pred)

print(f"Accuracy:{Accuracy}")   
print(f"F1_score:{F1_score}") 
# ```end