# ```python
# Import all required packages
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/cmc/cmc_train.csv')
test_data = pd.read_csv('data/cmc/cmc_test.csv')
# ```end

# ```python 
# Feature: Education_gap
# Usefulness: The difference in education level between the wife and husband might influence the class. 
train_data['Education_gap'] = train_data['Wifes_education'] - train_data['Husbands_education']
test_data['Education_gap'] = test_data['Wifes_education'] - test_data['Husbands_education']
# ```end 

# ```python-dropping-columns
# Explanation: The column 'Wifes_now_working%3F' is dropped because it might not have a significant impact on the class.
train_data.drop(columns=['Wifes_now_working%3F'], inplace=True)
test_data.drop(columns=['Wifes_now_working%3F'], inplace=True)
# ```end-dropping-columns

# ```python
# Define preprocessing pipelines
numeric_features = ['Wifes_age', 'Number_of_children_ever_born', 'Education_gap']
numeric_transformer = Pipeline(steps=[
    ('scaler', StandardScaler())])

categorical_features = ['Wifes_education', 'Husbands_education', 'Husbands_occupation', 'Standard-of-living_index', 'Media_exposure', 'Wifes_religion']
categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numeric_features),
        ('cat', categorical_transformer, categorical_features)])

# Append classifier to preprocessing pipeline
clf = Pipeline(steps=[('preprocessor', preprocessor),
                      ('classifier', RandomForestClassifier())])

# Fit the model
X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
clf.fit(X_train, y_train)
# ```end

# ```python
# Report evaluation based on only test dataset
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']
y_pred = clf.predict(X_test)
y_pred_proba = clf.predict_proba(X_test)

# Calculate the model accuracy
Accuracy = accuracy_score(y_test, y_pred)

# Calculate the model log loss
Log_loss = log_loss(y_test, y_pred_proba)

# Print the accuracy result
print(f"Accuracy:{Accuracy}")   

# Print the log loss result
print(f"Log_loss:{Log_loss}") 
# ```end