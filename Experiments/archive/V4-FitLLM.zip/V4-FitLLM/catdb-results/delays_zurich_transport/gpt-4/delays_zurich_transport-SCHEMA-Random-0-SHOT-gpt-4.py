# ```python
# Import all required packages
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/delays_zurich_transport/delays_zurich_transport_train.csv')
test_data = pd.read_csv('data/delays_zurich_transport/delays_zurich_transport_test.csv')
# ```end

# ```python
# Feature: is_weekend
# Usefulness: The delay might be different on weekends compared to weekdays due to different traffic conditions.
train_data['is_weekend'] = train_data['weekday'].apply(lambda x: 1 if x >= 5 else 0)
test_data['is_weekend'] = test_data['weekday'].apply(lambda x: 1 if x >= 5 else 0)
# ```end

# ```python
# Feature: is_rush_hour
# Usefulness: The delay might be different during rush hours due to increased traffic.
train_data['is_rush_hour'] = train_data['hour'].apply(lambda x: 1 if 7 <= x <= 9 or 16 <= x <= 18 else 0)
test_data['is_rush_hour'] = test_data['hour'].apply(lambda x: 1 if 7 <= x <= 9 or 16 <= x <= 18 else 0)
# ```end

# ```python
# Feature: is_bad_weather
# Usefulness: The delay might be different during bad weather conditions.
train_data['is_bad_weather'] = train_data['precipitation'].apply(lambda x: 1 if x > 0 else 0)
test_data['is_bad_weather'] = test_data['precipitation'].apply(lambda x: 1 if x > 0 else 0)
# ```end

# ```python-dropping-columns
# Explanation why the column 'weekday', 'hour', 'precipitation' are dropped
# These columns are dropped because they have been transformed into more meaningful features ('is_weekend', 'is_rush_hour', 'is_bad_weather').
train_data.drop(columns=['weekday', 'hour', 'precipitation'], inplace=True)
test_data.drop(columns=['weekday', 'hour', 'precipitation'], inplace=True)
# ```end-dropping-columns

# ```python
# Train the regression model
X_train = train_data.drop('delay', axis=1)
y_train = train_data['delay']
X_test = test_data.drop('delay', axis=1)
y_test = test_data['delay']

model = LinearRegression()
model.fit(X_train, y_train)

# Predict on the test set
y_pred = model.predict(X_test)
# ```end

# ```python
# Report evaluation based on only test dataset
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end