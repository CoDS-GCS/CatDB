# ```python
# Import all required packages
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np

# Load the datasets
train_data = pd.read_csv('data/delays_zurich_transport/delays_zurich_transport_train.csv')
test_data = pd.read_csv('data/delays_zurich_transport/delays_zurich_transport_test.csv')

# Feature: IsWeekend
# Usefulness: The delay might be different on weekends compared to weekdays due to different traffic conditions.
train_data['IsWeekend'] = train_data['weekday'].apply(lambda x: 1 if x >= 5 else 0)
test_data['IsWeekend'] = test_data['weekday'].apply(lambda x: 1 if x >= 5 else 0)

# Feature: IsRushHour
# Usefulness: The delay might be different during rush hours due to increased traffic.
train_data['IsRushHour'] = train_data['hour'].apply(lambda x: 1 if 7 <= x <= 9 or 16 <= x <= 18 else 0)
test_data['IsRushHour'] = test_data['hour'].apply(lambda x: 1 if 7 <= x <= 9 or 16 <= x <= 18 else 0)

# Feature: IsBadWeather
# Usefulness: The delay might be different during bad weather conditions.
train_data['IsBadWeather'] = train_data['precipitation'].apply(lambda x: 1 if x > 0 else 0)
test_data['IsBadWeather'] = test_data['precipitation'].apply(lambda x: 1 if x > 0 else 0)

# Drop unnecessary columns
# Explanation: The 'dayminute' column is dropped because it is highly correlated with the 'hour' column and thus redundant.
train_data.drop(columns=['dayminute'], inplace=True)
test_data.drop(columns=['dayminute'], inplace=True)

# Train the model
X_train = train_data.drop(columns=['delay'])
y_train = train_data['delay']
model = LinearRegression()
model.fit(X_train, y_train)

# Predict on the test set
X_test = test_data.drop(columns=['delay'])
y_test = test_data['delay']
y_pred = model.predict(X_test)

# Report evaluation based on only test dataset
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

# Print the accuracy result
print(f"R_Squared:{R_Squared}")   
# Print the log loss result
print(f"RMSE:{RMSE}") 
# ```end