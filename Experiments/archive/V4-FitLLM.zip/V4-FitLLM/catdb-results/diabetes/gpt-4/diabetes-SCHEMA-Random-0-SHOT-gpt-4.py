# ```python
# Import all required packages
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss

# Load the datasets
train_data = pd.read_csv('data/diabetes/diabetes_train.csv')
test_data = pd.read_csv('data/diabetes/diabetes_test.csv')

# Feature: BMI Age
# Usefulness: As age increases, the risk of diabetes also increases. Similarly, a higher BMI can also indicate a higher risk of diabetes. Therefore, creating a feature that combines these two can be useful.
train_data['bmi_age'] = train_data['mass'] * train_data['age']
test_data['bmi_age'] = test_data['mass'] * test_data['age']

# Feature: Insulin Age
# Usefulness: Insulin is a hormone that regulates blood sugar. With age, the body's response to insulin may decrease, leading to diabetes. Therefore, creating a feature that combines these two can be useful.
train_data['insu_age'] = train_data['insu'] * train_data['age']
test_data['insu_age'] = test_data['insu'] * test_data['age']

# Feature: Glucose Age
# Usefulness: High blood glucose levels can indicate diabetes. As age increases, the risk of having high blood glucose levels also increases. Therefore, creating a feature that combines these two can be useful.
train_data['glucose_age'] = train_data['plas'] * train_data['age']
test_data['glucose_age'] = test_data['plas'] * test_data['age']

# Drop the 'skin' column as it is not directly related to diabetes
train_data.drop(columns=['skin'], inplace=True)
test_data.drop(columns=['skin'], inplace=True)

# Define the features and the target
X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']

# Create a pipeline
pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('classifier', RandomForestClassifier())
])

# Fit the pipeline
pipeline.fit(X_train, y_train)

# Predict the classes and the probabilities
y_pred = pipeline.predict(X_test)
y_pred_proba = pipeline.predict_proba(X_test)

# Calculate the accuracy and the log loss
Accuracy = accuracy_score(y_test, y_pred)
Log_loss = log_loss(y_test, y_pred_proba)

# Print the results
print(f"Accuracy: {Accuracy}")
print(f"Log_loss: {Log_loss}")
# ```end