# ```python
# Import all required packages
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/nyc-taxi-green-dec-2016/nyc-taxi-green-dec-2016_train.csv')
test_data = pd.read_csv('data/nyc-taxi-green-dec-2016/nyc-taxi-green-dec-2016_test.csv')
# ```end

# ```python
# Feature: 'total_charges'
# Usefulness: This feature combines the total amount, tolls amount, and improvement surcharge. It provides a comprehensive view of the total charges for the trip, which could be related to the tip amount.
train_data['total_charges'] = train_data['total_amount'] + train_data['tolls_amount'] + train_data['improvement_surcharge']
test_data['total_charges'] = test_data['total_amount'] + test_data['tolls_amount'] + test_data['improvement_surcharge']
# ```end

# ```python
# Feature: 'trip_duration'
# Usefulness: This feature calculates the duration of the trip in minutes. The duration of the trip could influence the tip amount.
train_data['trip_duration'] = (train_data['lpep_dropoff_datetime_hour'] - train_data['lpep_pickup_datetime_hour']) * 60 + (train_data['lpep_dropoff_datetime_minute'] - train_data['lpep_pickup_datetime_minute'])
test_data['trip_duration'] = (test_data['lpep_dropoff_datetime_hour'] - test_data['lpep_pickup_datetime_hour']) * 60 + (test_data['lpep_dropoff_datetime_minute'] - test_data['lpep_pickup_datetime_minute'])
# ```end

# ```python-dropping-columns
# Explanation why the column 'lpep_dropoff_datetime_hour', 'lpep_pickup_datetime_hour', 'lpep_dropoff_datetime_minute', 'lpep_pickup_datetime_minute' are dropped
# These columns are dropped because they are used to calculate the 'trip_duration' feature and are no longer needed.
train_data.drop(columns=['lpep_dropoff_datetime_hour', 'lpep_pickup_datetime_hour', 'lpep_dropoff_datetime_minute', 'lpep_pickup_datetime_minute'], inplace=True)
test_data.drop(columns=['lpep_dropoff_datetime_hour', 'lpep_pickup_datetime_hour', 'lpep_dropoff_datetime_minute', 'lpep_pickup_datetime_minute'], inplace=True)
# ```end-dropping-columns

# ```python
# Define the model
model = LinearRegression()

# Define the features and target
features = ['total_charges', 'trip_duration', 'passenger_count', 'RatecodeID', 'extra', 'mta_tax', 'store_and_fwd_flag', 'VendorID', 'trip_type']
target = 'tip_amount'

# Train the model
model.fit(train_data[features], train_data[target])

# Make predictions
predictions = model.predict(test_data[features])

# Calculate R-Squared
R_Squared = r2_score(test_data[target], predictions)

# Calculate RMSE
RMSE = np.sqrt(mean_squared_error(test_data[target], predictions))

# Print the results
print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end