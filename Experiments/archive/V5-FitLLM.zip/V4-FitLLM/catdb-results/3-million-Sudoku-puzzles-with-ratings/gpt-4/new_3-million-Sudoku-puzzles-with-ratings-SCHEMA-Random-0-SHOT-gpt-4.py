# ```python
# Import all required packages
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/3-million-Sudoku-puzzles-with-ratings/3-million-Sudoku-puzzles-with-ratings_train.csv')
test_data = pd.read_csv('data/3-million-Sudoku-puzzles-with-ratings/3-million-Sudoku-puzzles-with-ratings_test.csv')
# ```end

# ```python
# Feature: Length of solution
# Usefulness: The length of the solution might correlate with the difficulty of the puzzle.
train_data['solution_length'] = train_data['solution'].apply(len)
test_data['solution_length'] = test_data['solution'].apply(len)
# ```end

# ```python
# Feature: Number of unique characters in solution
# Usefulness: The number of unique characters in the solution might correlate with the difficulty of the puzzle.
train_data['unique_chars'] = train_data['solution'].apply(lambda x: len(set(x)))
test_data['unique_chars'] = test_data['solution'].apply(lambda x: len(set(x)))
# ```end

# ```python-dropping-columns
# Explanation why the column 'solution' and 'puzzle' are dropped
# The 'solution' and 'puzzle' columns are dropped because they are strings and cannot be used directly for training the model.
# Also, we have already extracted relevant features from these columns.
train_data.drop(columns=['solution', 'puzzle'], inplace=True)
test_data.drop(columns=['solution', 'puzzle'], inplace=True)
# ```end-dropping-columns

# ```python
# Prepare data for training
X_train = train_data.drop('difficulty', axis=1)
y_train = train_data['difficulty']
X_test = test_data.drop('difficulty', axis=1)
y_test = test_data['difficulty']

# Encode the target variable

# Combine unique labels from both training and test sets
all_labels = pd.concat([train_data['difficulty'], test_data['difficulty']]).unique()

# Fit the LabelEncoder on all_labels
le = LabelEncoder()
le.fit(all_labels)

y_train = le.fit_transform(y_train)
y_test = le.transform(y_test)

# Train the model
clf = RandomForestClassifier()
clf.fit(X_train, y_train)

# Make predictions
y_pred = clf.predict(X_test)
y_pred_proba = clf.predict_proba(X_test)
# ```end

# ```python
# Report evaluation based on only test dataset
# Calculate the model accuracy
Accuracy = accuracy_score(y_test, y_pred)
# Calculate the model log loss
Log_loss = log_loss(y_test, y_pred_proba)

# Print the accuracy result
print(f"Accuracy:{Accuracy}")   
# Print the log loss result
print(f"Log_loss:{Log_loss}") 
# ```end