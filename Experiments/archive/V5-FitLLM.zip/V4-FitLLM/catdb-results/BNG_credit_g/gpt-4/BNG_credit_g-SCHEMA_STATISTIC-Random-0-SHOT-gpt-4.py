# ```python
# Import all required packages
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score

# Load the datasets
train_data = pd.read_csv('data/BNG_credit_g/BNG_credit_g_train.csv')
test_data = pd.read_csv('data/BNG_credit_g/BNG_credit_g_test.csv')

# Feature: Total financial commitment
# Usefulness: This feature combines the number of existing credits and the installment commitment, 
# providing a more comprehensive view of the customer's financial obligations.
train_data['total_financial_commitment'] = train_data['existing_credits'] * train_data['installment_commitment']
test_data['total_financial_commitment'] = test_data['existing_credits'] * test_data['installment_commitment']

# Feature: Age per Dependents
# Usefulness: This feature provides a ratio of the customer's age to the number of dependents they have. 
# This could be useful in understanding the financial burden on the customer.
train_data['age_per_dependents'] = train_data['age'] / train_data['num_dependents']
test_data['age_per_dependents'] = test_data['age'] / test_data['num_dependents']

# Dropping columns
# Explanation: The columns 'other_payment_plans', 'own_telephone', 'foreign_worker', 'property_magnitude', 
# 'personal_status', 'checking_status', 'job', 'purpose', 'other_parties', 'savings_status', 'credit_history', 
# 'employment', 'housing' are dropped as they are categorical and would require extensive preprocessing to be useful. 
# Additionally, they may not have a significant impact on the target variable 'class'.
train_data.drop(columns=['other_payment_plans', 'own_telephone', 'foreign_worker', 'property_magnitude', 
                         'personal_status', 'checking_status', 'job', 'purpose', 'other_parties', 
                         'savings_status', 'credit_history', 'employment', 'housing'], inplace=True)
test_data.drop(columns=['other_payment_plans', 'own_telephone', 'foreign_worker', 'property_magnitude', 
                        'personal_status', 'checking_status', 'job', 'purpose', 'other_parties', 
                        'savings_status', 'credit_history', 'employment', 'housing'], inplace=True)

# Encoding the target variable 'class'
le = LabelEncoder()
train_data['class'] = le.fit_transform(train_data['class'])
test_data['class'] = le.transform(test_data['class'])

# Binary classification
clf = RandomForestClassifier(random_state=42)
clf.fit(train_data.drop('class', axis=1), train_data['class'])

# Predictions
predictions = clf.predict(test_data.drop('class', axis=1))

# Report evaluation based on only test dataset
Accuracy = accuracy_score(test_data['class'], predictions)
F1_score = f1_score(test_data['class'], predictions)

print(f"Accuracy:{Accuracy}")   
print(f"F1_score:{F1_score}") 
# ```end