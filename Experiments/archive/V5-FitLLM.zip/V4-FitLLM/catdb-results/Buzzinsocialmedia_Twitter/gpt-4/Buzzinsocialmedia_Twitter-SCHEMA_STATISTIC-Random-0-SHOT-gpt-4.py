# ```python
# Import all required packages
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np

# Load the datasets
train_data = pd.read_csv("data/Buzzinsocialmedia_Twitter/Buzzinsocialmedia_Twitter_train.csv")
test_data = pd.read_csv("data/Buzzinsocialmedia_Twitter/Buzzinsocialmedia_Twitter_test.csv")

# Feature Engineering
# Adding new features that are the mean of the NCD, NAD, NA, NAC, AI, CS, AT, ASNA, ASNAC, ADL, BL features for each row
train_data['mean_NCD'] = train_data[['NCD_0', 'NCD_1', 'NCD_2', 'NCD_3', 'NCD_4', 'NCD_5', 'NCD_6']].mean(axis=1)
train_data['mean_NAD'] = train_data[['NAD_0', 'NAD_1', 'NAD_2', 'NAD_3', 'NAD_4', 'NAD_5', 'NAD_6']].mean(axis=1)
train_data['mean_NA'] = train_data[['NA_0', 'NA_1', 'NA_2', 'NA_3', 'NA_4', 'NA_5', 'NA_6']].mean(axis=1)
train_data['mean_NAC'] = train_data[['NAC_0', 'NAC_1', 'NAC_2', 'NAC_3', 'NAC_4', 'NAC_5', 'NAC_6']].mean(axis=1)
train_data['mean_AI'] = train_data[['AI_0', 'AI_1', 'AI_2', 'AI_3', 'AI_4', 'AI_5', 'AI_6']].mean(axis=1)
train_data['mean_CS'] = train_data[['CS_0', 'CS_1', 'CS_2', 'CS_3', 'CS_4', 'CS_5', 'CS_6']].mean(axis=1)
train_data['mean_AT'] = train_data[['AT_0', 'AT_1', 'AT_2', 'AT_3', 'AT_4', 'AT_5', 'AT_6']].mean(axis=1)
train_data['mean_ASNA'] = train_data[['ASNA_0', 'ASNA_1', 'ASNA_2', 'ASNA_3', 'ASNA_4', 'ASNA_5', 'ASNA_6']].mean(axis=1)
train_data['mean_ASNAC'] = train_data[['ASNAC_0', 'ASNAC_1', 'ASNAC_2', 'ASNAC_3', 'ASNAC_4', 'ASNAC_5', 'ASNAC_6']].mean(axis=1)
train_data['mean_ADL'] = train_data[['ADL_0', 'ADL_1', 'ADL_2', 'ADL_3', 'ADL_4', 'ADL_5', 'ADL_6']].mean(axis=1)
train_data['mean_BL'] = train_data[['BL_0', 'BL_1', 'BL_2', 'BL_3', 'BL_4', 'BL_5', 'BL_6']].mean(axis=1)

# Dropping the original columns as they are no longer needed
train_data.drop(columns=['NCD_0', 'NCD_1', 'NCD_2', 'NCD_3', 'NCD_4', 'NCD_5', 'NCD_6', 'NAD_0', 'NAD_1', 'NAD_2', 'NAD_3', 'NAD_4', 'NAD_5', 'NAD_6', 'NA_0', 'NA_1', 'NA_2', 'NA_3', 'NA_4', 'NA_5', 'NA_6', 'NAC_0', 'NAC_1', 'NAC_2', 'NAC_3', 'NAC_4', 'NAC_5', 'NAC_6', 'AI_0', 'AI_1', 'AI_2', 'AI_3', 'AI_4', 'AI_5', 'AI_6', 'CS_0', 'CS_1', 'CS_2', 'CS_3', 'CS_4', 'CS_5', 'CS_6', 'AT_0', 'AT_1', 'AT_2', 'AT_3', 'AT_4', 'AT_5', 'AT_6', 'ASNA_0', 'ASNA_1', 'ASNA_2', 'ASNA_3', 'ASNA_4', 'ASNA_5', 'ASNA_6', 'ASNAC_0', 'ASNAC_1', 'ASNAC_2', 'ASNAC_3', 'ASNAC_4', 'ASNAC_5', 'ASNAC_6', 'ADL_0', 'ADL_1', 'ADL_2', 'ADL_3', 'ADL_4', 'ADL_5', 'ADL_6', 'BL_0', 'BL_1', 'BL_2', 'BL_3', 'BL_4', 'BL_5', 'BL_6'], inplace=True)

# Splitting the data into features and target variable
X_train = train_data.drop(columns=['Annotation'])
y_train = train_data['Annotation']

# Applying the same transformations to the test data
test_data['mean_NCD'] = test_data[['NCD_0', 'NCD_1', 'NCD_2', 'NCD_3', 'NCD_4', 'NCD_5', 'NCD_6']].mean(axis=1)
test_data['mean_NAD'] = test_data[['NAD_0', 'NAD_1', 'NAD_2', 'NAD_3', 'NAD_4', 'NAD_5', 'NAD_6']].mean(axis=1)
test_data['mean_NA'] = test_data[['NA_0', 'NA_1', 'NA_2', 'NA_3', 'NA_4', 'NA_5', 'NA_6']].mean(axis=1)
test_data['mean_NAC'] = test_data[['NAC_0', 'NAC_1', 'NAC_2', 'NAC_3', 'NAC_4', 'NAC_5', 'NAC_6']].mean(axis=1)
test_data['mean_AI'] = test_data[['AI_0', 'AI_1', 'AI_2', 'AI_3', 'AI_4', 'AI_5', 'AI_6']].mean(axis=1)
test_data['mean_CS'] = test_data[['CS_0', 'CS_1', 'CS_2', 'CS_3', 'CS_4', 'CS_5', 'CS_6']].mean(axis=1)
test_data['mean_AT'] = test_data[['AT_0', 'AT_1', 'AT_2', 'AT_3', 'AT_4', 'AT_5', 'AT_6']].mean(axis=1)
test_data['mean_ASNA'] = test_data[['ASNA_0', 'ASNA_1', 'ASNA_2', 'ASNA_3', 'ASNA_4', 'ASNA_5', 'ASNA_6']].mean(axis=1)
test_data['mean_ASNAC'] = test_data[['ASNAC_0', 'ASNAC_1', 'ASNAC_2', 'ASNAC_3', 'ASNAC_4', 'ASNAC_5', 'ASNAC_6']].mean(axis=1)
test_data['mean_ADL'] = test_data[['ADL_0', 'ADL_1', 'ADL_2', 'ADL_3', 'ADL_4', 'ADL_5', 'ADL_6']].mean(axis=1)
test_data['mean_BL'] = test_data[['BL_0', 'BL_1', 'BL_2', 'BL_3', 'BL_4', 'BL_5', 'BL_6']].mean(axis=1)
test_data.drop(columns=['NCD_0', 'NCD_1', 'NCD_2', 'NCD_3', 'NCD_4', 'NCD_5', 'NCD_6', 'NAD_0', 'NAD_1', 'NAD_2', 'NAD_3', 'NAD_4', 'NAD_5', 'NAD_6', 'NA_0', 'NA_1', 'NA_2', 'NA_3', 'NA_4', 'NA_5', 'NA_6', 'NAC_0', 'NAC_1', 'NAC_2', 'NAC_3', 'NAC_4', 'NAC_5', 'NAC_6', 'AI_0', 'AI_1', 'AI_2', 'AI_3', 'AI_4', 'AI_5', 'AI_6', 'CS_0', 'CS_1', 'CS_2', 'CS_3', 'CS_4', 'CS_5', 'CS_6', 'AT_0', 'AT_1', 'AT_2', 'AT_3', 'AT_4', 'AT_5', 'AT_6', 'ASNA_0', 'ASNA_1', 'ASNA_2', 'ASNA_3', 'ASNA_4', 'ASNA_5', 'ASNA_6', 'ASNAC_0', 'ASNAC_1', 'ASNAC_2', 'ASNAC_3', 'ASNAC_4', 'ASNAC_5', 'ASNAC_6', 'ADL_0', 'ADL_1', 'ADL_2', 'ADL_3', 'ADL_4', 'ADL_5', 'ADL_6', 'BL_0', 'BL_1', 'BL_2', 'BL_3', 'BL_4', 'BL_5', 'BL_6'], inplace=True)
X_test = test_data.drop(columns=['Annotation'])
y_test = test_data['Annotation']

# Creating the pipeline
pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('regressor', LinearRegression())
])

# Training the model
pipeline.fit(X_train, y_train)

# Making predictions
y_pred = pipeline.predict(X_test)

# Evaluation
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

# Print the results
print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end