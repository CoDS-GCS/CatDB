# ```python
# Import all required packages
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss

# Load the datasets
train_data = pd.read_csv("data/Microsoft/Microsoft_train.csv")
test_data = pd.read_csv("data/Microsoft/Microsoft_test.csv")

# Define the features and the target
features = train_data.drop('relevance', axis=1)
target = train_data['relevance']

# Define the pipeline
numeric_features = features.select_dtypes(include=['int64', 'float64']).columns
numeric_transformer = Pipeline(steps=[
    ('scaler', StandardScaler())])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numeric_features)])

pipeline = Pipeline(steps=[('preprocessor', preprocessor),
                           ('classifier', RandomForestClassifier())])

# Fit the model
pipeline.fit(features, target)

# Predict the test set results
y_pred = pipeline.predict(test_data.drop('relevance', axis=1))

# Calculate the accuracy and log loss
Accuracy = accuracy_score(test_data['relevance'], y_pred)
Log_loss = log_loss(test_data['relevance'], y_pred)

# Print the results
print(f"Accuracy: {Accuracy}")
print(f"Log loss: {Log_loss}")
# ```end