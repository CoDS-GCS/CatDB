# ```python
# Import all required packages
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import LabelEncoder
# ```end

# ```python
# Load the datasets using pandas' CSV readers
train_data = pd.read_csv('data/airlines/airlines_train.csv')
test_data = pd.read_csv('data/airlines/airlines_test.csv')
# ```end

# ```python
# (Feature name: IsWeekend)
# Usefulness: Flights on weekends may have different patterns of delays compared to weekdays.
train_data['IsWeekend'] = train_data['DayOfWeek'].apply(lambda x: 1 if x >= 6 else 0)
test_data['IsWeekend'] = test_data['DayOfWeek'].apply(lambda x: 1 if x >= 6 else 0)
# ```end

# ```python
# (Feature name: DepartureHour)
# Usefulness: Delays might be more frequent during certain hours of the day (e.g., rush hours).
train_data['DepartureHour'] = train_data['Time'] // 100
test_data['DepartureHour'] = test_data['Time'] // 100
# ```end

# ```python
# (Feature name: AirlineLabel)
# Usefulness: Encoding the airline as a numerical feature to capture any airline-specific delay patterns.
label_encoder = LabelEncoder()
train_data['AirlineLabel'] = label_encoder.fit_transform(train_data['Airline'])
test_data['AirlineLabel'] = label_encoder.transform(test_data['Airline'])
# ```end

# ```python
# (Feature name: AirportFromLabel)
# Usefulness: Encoding the departure airport as a numerical feature to capture any location-specific delay patterns.
label_encoder = LabelEncoder()
train_data['AirportFromLabel'] = label_encoder.fit_transform(train_data['AirportFrom'])
test_data['AirportFromLabel'] = label_encoder.transform(test_data['AirportFrom'])
# ```end

# ```python
# (Feature name: AirportToLabel)
# Usefulness: Encoding the arrival airport as a numerical feature to capture any location-specific delay patterns.
label_encoder = LabelEncoder()
train_data['AirportToLabel'] = label_encoder.fit_transform(train_data['AirportTo'])
test_data['AirportToLabel'] = label_encoder.transform(test_data['AirportTo'])
# ```end

# ```python-dropping-columns
# Explanation why the column DayOfWeek is dropped
# It is less informative once we have extracted the IsWeekend feature.
train_data.drop(columns=['DayOfWeek'], inplace=True)
test_data.drop(columns=['DayOfWeek'], inplace=True)
# ```end-dropping-columns

# ```python-dropping-columns
# Explanation why the column Time is dropped
# It is less informative once we have extracted the DepartureHour feature.
train_data.drop(columns=['Time'], inplace=True)
test_data.drop(columns=['Time'], inplace=True)
# ```end-dropping-columns

# ```python-dropping-columns
# Explanation why the columns AirportFrom, Airline, and AirportTo are dropped
# They have been replaced by numerical label encoded features.
train_data.drop(columns=['AirportFrom', 'Airline', 'AirportTo'], inplace=True)
test_data.drop(columns=['AirportFrom', 'Airline', 'AirportTo'], inplace=True)
# ```end-dropping-columns

# ```python
# Report evaluation based on only test dataset
# Prepare the data
X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']

# Initialize the model
model = RandomForestClassifier(n_estimators=100, random_state=42)

# Train the model
model.fit(X_train, y_train)

# Make predictions
predictions = model.predict(X_test)

# Calculate the model accuracy and f1 score
Accuracy = accuracy_score(y_test, predictions)
F1_score = f1_score(y_test, predictions)

# Print the accuracy result
print(f"Accuracy:{Accuracy}")

# Print the f1 score result
print(f"F1_score:{F1_score}")
# ```end