# ```python
# Import all required packages
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/black_friday/black_friday_train.csv')
test_data = pd.read_csv('data/black_friday/black_friday_test.csv')
# ```end

# ```python
# Feature: Total_Products
# Usefulness: This feature represents the total number of products bought by a user. It can be useful to predict 'Purchase' as users who buy more products might have a higher total purchase amount.
train_data['Total_Products'] = train_data['Product_Category_1'] + train_data['Product_Category_2'] + train_data['Product_Category_3']
test_data['Total_Products'] = test_data['Product_Category_1'] + test_data['Product_Category_2'] + test_data['Product_Category_3']
# ```end

# ```python
# Feature: Age_Stay
# Usefulness: This feature represents the product of Age and Stay_In_Current_City_Years. It can be useful to predict 'Purchase' as older people who have stayed longer in the city might have a higher total purchase amount.
train_data['Age_Stay'] = train_data['Age'] * train_data['Stay_In_Current_City_Years']
test_data['Age_Stay'] = test_data['Age'] * test_data['Stay_In_Current_City_Years']
# ```end

# ```python-dropping-columns
# Explanation why the column 'Product_Category_1', 'Product_Category_2', 'Product_Category_3' are dropped
# These columns are dropped because they are already used to create the 'Total_Products' feature and hence, they are redundant.
train_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3'], inplace=True)
test_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3'], inplace=True)
# ```end-dropping-columns

# ```python
# Prepare the data for the regression model
X_train = train_data.drop('Purchase', axis=1)
y_train = train_data['Purchase']
X_test = test_data.drop('Purchase', axis=1)
y_test = test_data['Purchase']

# Standardize the features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Train the regression model
model = LinearRegression()
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)
# ```end

# ```python
# Report evaluation based on only test dataset
# Calculate the model R-Squared
R_Squared = r2_score(y_test, y_pred)

# Calculate the model Root Mean Squared Error
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

# Print the accuracy result
print(f"R_Squared:{R_Squared}")   

# Print the log loss result
print(f"RMSE:{RMSE}") 
# ```end