# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Load the datasets
train_data = pd.read_csv('data/black_friday/black_friday_train.csv')
test_data = pd.read_csv('data/black_friday/black_friday_test.csv')

# Feature: Total_Categories
# Usefulness: This feature represents the total number of product categories a customer has interacted with. 
# This could be useful in predicting the 'Purchase' as customers interacting with more categories might tend to purchase more.
train_data['Total_Categories'] = train_data['Product_Category_1'] + train_data['Product_Category_2'] + train_data['Product_Category_3']
test_data['Total_Categories'] = test_data['Product_Category_1'] + test_data['Product_Category_2'] + test_data['Product_Category_3']

# Feature: Age_Stay
# Usefulness: This feature represents the interaction between 'Age' and 'Stay_In_Current_City_Years'. 
# This could be useful in predicting the 'Purchase' as the age of the customer and the duration of their stay in the city might influence their purchasing behavior.
train_data['Age_Stay'] = train_data['Age'] * train_data['Stay_In_Current_City_Years']
test_data['Age_Stay'] = test_data['Age'] * test_data['Stay_In_Current_City_Years']

# Dropping columns
# Explanation: The columns 'Product_Category_1', 'Product_Category_2', 'Product_Category_3' are dropped as they are now represented by the new feature 'Total_Categories'.
# The columns 'Age' and 'Stay_In_Current_City_Years' are dropped as they are now represented by the new feature 'Age_Stay'.
train_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3', 'Age', 'Stay_In_Current_City_Years'], inplace=True)
test_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3', 'Age', 'Stay_In_Current_City_Years'], inplace=True)

# Regression model
X_train = train_data.drop('Purchase', axis=1)
y_train = train_data['Purchase']
X_test = test_data.drop('Purchase', axis=1)
y_test = test_data['Purchase']

model = LinearRegression()
model.fit(X_train, y_train)
predictions = model.predict(X_test)

# Evaluation
R_Squared = r2_score(y_test, predictions)
RMSE = np.sqrt(mean_squared_error(y_test, predictions))

print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end