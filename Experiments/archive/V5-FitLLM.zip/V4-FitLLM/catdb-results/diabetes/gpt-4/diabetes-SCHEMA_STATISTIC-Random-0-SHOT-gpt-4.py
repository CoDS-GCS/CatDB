# ```python
# Import all required packages
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss

# Load the datasets
train_data = pd.read_csv('data/diabetes/diabetes_train.csv')
test_data = pd.read_csv('data/diabetes/diabetes_test.csv')

# Feature: Body Mass Index (BMI) Category
# Usefulness: BMI is a key risk factor for diabetes. Categorizing BMI can help the model understand the risk levels associated with different BMI ranges.
def bmi_category(bmi):
    if bmi < 18.5:
        return 'Underweight'
    elif 18.5 <= bmi < 25:
        return 'Normal weight'
    elif 25 <= bmi < 30:
        return 'Overweight'
    else:
        return 'Obese'
train_data['bmi_category'] = train_data['mass'].apply(bmi_category)
test_data['bmi_category'] = test_data['mass'].apply(bmi_category)

# Feature: Age Category
# Usefulness: Age is a risk factor for diabetes. Categorizing age can help the model understand the risk levels associated with different age groups.
def age_category(age):
    if age < 30:
        return 'Young'
    elif 30 <= age < 50:
        return 'Middle'
    else:
        return 'Old'
train_data['age_category'] = train_data['age'].apply(age_category)
test_data['age_category'] = test_data['age'].apply(age_category)

# Drop the 'skin' column as it is not a significant predictor for diabetes
# Explanation: The 'skin' column represents the skin thickness, which is not a significant predictor for diabetes.
train_data.drop(columns=['skin'], inplace=True)
test_data.drop(columns=['skin'], inplace=True)

# Define the features and the target
features = train_data.drop('class', axis=1)
target = train_data['class']

# Define the pipeline
pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('classifier', RandomForestClassifier())
])

# Fit the pipeline
pipeline.fit(features, target)

# Predict the classes and the class probabilities
test_features = test_data.drop('class', axis=1)
test_target = test_data['class']
predictions = pipeline.predict(test_features)
probabilities = pipeline.predict_proba(test_features)

# Report evaluation based on only test dataset
Accuracy = accuracy_score(test_target, predictions)
Log_loss = log_loss(test_target, probabilities)

print(f"Accuracy:{Accuracy}")   
print(f"Log_loss:{Log_loss}") 
# ```end