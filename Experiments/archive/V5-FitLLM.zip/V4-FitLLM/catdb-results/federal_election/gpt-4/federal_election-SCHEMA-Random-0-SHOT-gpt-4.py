# ```python
# Import all required packages
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/federal_election/federal_election_train.csv', low_memory=False)
test_data = pd.read_csv('data/federal_election/federal_election_test.csv',low_memory=False)
# ```end

# ```python
# Convert transaction_dt to datetime format
# Usefulness: This will allow us to extract more information from the date such as the month, year, and day of the week.
train_data['transaction_dt'] = pd.to_datetime(train_data['transaction_dt'], format='%Y%m%d')
test_data['transaction_dt'] = pd.to_datetime(test_data['transaction_dt'], format='%Y%m%d')
# ```end

# ```python
# Extract year, month and day of week from transaction_dt
# Usefulness: These features can capture any seasonal trends in the transaction_amt.
train_data['transaction_year'] = train_data['transaction_dt'].dt.year
train_data['transaction_month'] = train_data['transaction_dt'].dt.month
train_data['transaction_dayofweek'] = train_data['transaction_dt'].dt.dayofweek

test_data['transaction_year'] = test_data['transaction_dt'].dt.year
test_data['transaction_month'] = test_data['transaction_dt'].dt.month
test_data['transaction_dayofweek'] = test_data['transaction_dt'].dt.dayofweek
# ```end

# ```python-dropping-columns
# Drop columns that are not useful for the regression model
# Explanation: Columns like 'cmte_id', 'other_id', 'tran_id', 'sub_id', 'image_num', 'file_num', 'amndt_ind', 'employer', 'city', 'rpt_tp', 'name', 'memo_text', 'memo_cd', 'transaction_pgi', 'occupation', 'entity_tp', 'transaction_tp', 'state' are dropped because they are categorical and have high cardinality which can lead to overfitting.
train_data.drop(columns=['cmte_id', 'other_id', 'tran_id', 'sub_id', 'image_num', 'file_num', 'amndt_ind', 'employer', 'city', 'rpt_tp', 'name', 'memo_text', 'memo_cd', 'transaction_pgi', 'occupation', 'entity_tp', 'transaction_tp', 'state'], inplace=True)
test_data.drop(columns=['cmte_id', 'other_id', 'tran_id', 'sub_id', 'image_num', 'file_num', 'amndt_ind', 'employer', 'city', 'rpt_tp', 'name', 'memo_text', 'memo_cd', 'transaction_pgi', 'occupation', 'entity_tp', 'transaction_tp', 'state'], inplace=True)
# ```end-dropping-columns

# ```python
# Define the regression model
model = LinearRegression()

# Fit the model to the training data
model.fit(train_data.drop(columns=['transaction_amt']), train_data['transaction_amt'])

# Predict the transaction_amt on the test data
predictions = model.predict(test_data.drop(columns=['transaction_amt']))
# ```end

# ```python
# Report evaluation based on only test dataset
# Calculate the model R-Squared
R_Squared = r2_score(test_data['transaction_amt'], predictions)

# Calculate the model Root Mean Squared Error
RMSE = np.sqrt(mean_squared_error(test_data['transaction_amt'], predictions))

# Print the accuracy result
print(f"R_Squared:{R_Squared}")   

# Print the log loss result
print(f"RMSE:{RMSE}") 
# ```end