# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/federal_election/federal_election_train.csv')
test_data = pd.read_csv('data/federal_election/federal_election_test.csv')
# ```end

# ```python
# Add a new feature 'employer_length' which is the length of the employer name
# Usefulness: The length of the employer name might have some correlation with the transaction amount. 
# For example, larger companies might have longer names and might contribute more to the election.
train_data['employer_length'] = train_data['employer'].str.len()
test_data['employer_length'] = test_data['employer'].str.len()
# ```end

# ```python
# Add a new feature 'city_length' which is the length of the city name
# Usefulness: The length of the city name might have some correlation with the transaction amount. 
# For example, larger cities might have longer names and might contribute more to the election.
train_data['city_length'] = train_data['city'].str.len()
test_data['city_length'] = test_data['city'].str.len()
# ```end

# ```python
# Add a new feature 'occupation_length' which is the length of the occupation name
# Usefulness: The length of the occupation name might have some correlation with the transaction amount. 
# For example, higher paying occupations might have longer names and might contribute more to the election.
train_data['occupation_length'] = train_data['occupation'].str.len()
test_data['occupation_length'] = test_data['occupation'].str.len()
# ```end

# ```python-dropping-columns
# Drop the columns 'cmte_id', 'other_id', 'tran_id', 'sub_id', 'image_num', 'file_num', 'amndt_ind', 'rpt_tp', 'name', 'memo_text', 'memo_cd', 'transaction_pgi', 'entity_tp', 'transaction_tp', 'state'
# These columns are dropped because they are either identifiers or they have too many missing values or distinct values which might not be useful for the regression model.
train_data.drop(columns=['cmte_id', 'other_id', 'tran_id', 'sub_id', 'image_num', 'file_num', 'amndt_ind', 'rpt_tp', 'name', 'memo_text', 'memo_cd', 'transaction_pgi', 'entity_tp', 'transaction_tp', 'state'], inplace=True)
test_data.drop(columns=['cmte_id', 'other_id', 'tran_id', 'sub_id', 'image_num', 'file_num', 'amndt_ind', 'rpt_tp', 'name', 'memo_text', 'memo_cd', 'transaction_pgi', 'entity_tp', 'transaction_tp', 'state'], inplace=True)
# ```end-dropping-columns

# ```python
# Train the regression model
X_train = train_data.drop(columns=['transaction_amt'])
y_train = train_data['transaction_amt']
X_test = test_data.drop(columns=['transaction_amt'])
y_test = test_data['transaction_amt']

model = LinearRegression()
model.fit(X_train, y_train)

# Predict the transaction amount
y_pred = model.predict(X_test)

# Report evaluation based on only test dataset
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end