# ```python
# Import all required packages
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np

# Load the datasets
train_data = pd.read_csv('data/nyc-taxi-green-dec-2016/nyc-taxi-green-dec-2016_train.csv')
test_data = pd.read_csv('data/nyc-taxi-green-dec-2016/nyc-taxi-green-dec-2016_test.csv')

# Feature: 'trip_duration' - The duration of the trip in minutes
# Usefulness: The duration of the trip could influence the tip amount. Longer trips could result in higher tips.
train_data['trip_duration'] = (train_data['lpep_dropoff_datetime_hour'] - train_data['lpep_pickup_datetime_hour']) * 60 + (train_data['lpep_dropoff_datetime_minute'] - train_data['lpep_pickup_datetime_minute'])
test_data['trip_duration'] = (test_data['lpep_dropoff_datetime_hour'] - test_data['lpep_pickup_datetime_hour']) * 60 + (test_data['lpep_dropoff_datetime_minute'] - test_data['lpep_pickup_datetime_minute'])

# Feature: 'rush_hour' - Whether the trip occurred during rush hour (defined as 7-9am and 4-6pm)
# Usefulness: Trips during rush hour could be longer due to traffic, potentially leading to higher tips.
train_data['rush_hour'] = ((train_data['lpep_pickup_datetime_hour'].between(7, 9)) | (train_data['lpep_pickup_datetime_hour'].between(16, 18))).astype(int)
test_data['rush_hour'] = ((test_data['lpep_pickup_datetime_hour'].between(7, 9)) | (test_data['lpep_pickup_datetime_hour'].between(16, 18))).astype(int)

# Drop columns that are not useful for the prediction
# 'lpep_dropoff_datetime_day', 'lpep_pickup_datetime_day' are dropped because they do not provide useful information for predicting the tip amount.
# 'lpep_dropoff_datetime_hour', 'lpep_pickup_datetime_hour', 'lpep_dropoff_datetime_minute', 'lpep_pickup_datetime_minute' are dropped because they have been used to create the 'trip_duration' and 'rush_hour' features.
train_data.drop(columns=['lpep_dropoff_datetime_day', 'lpep_pickup_datetime_day', 'lpep_dropoff_datetime_hour', 'lpep_pickup_datetime_hour', 'lpep_dropoff_datetime_minute', 'lpep_pickup_datetime_minute'], inplace=True)
test_data.drop(columns=['lpep_dropoff_datetime_day', 'lpep_pickup_datetime_day', 'lpep_dropoff_datetime_hour', 'lpep_pickup_datetime_hour', 'lpep_dropoff_datetime_minute', 'lpep_pickup_datetime_minute'], inplace=True)

# Define the target variable and the feature matrix
y_train = train_data['tip_amount']
X_train = train_data.drop(columns=['tip_amount'])
y_test = test_data['tip_amount']
X_test = test_data.drop(columns=['tip_amount'])

# Train a linear regression model
model = LinearRegression()
model.fit(X_train, y_train)

# Make predictions on the test set
y_pred = model.predict(X_test)

# Calculate the R-Squared and Root Mean Squared Error
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

# Print the results
print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end