# ```python
# Import all required packages
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.preprocessing import StandardScaler
# ```end

# ```python
# Load the datasets
train_data = pd.read_csv('data/pokerhand/pokerhand_train.csv')
test_data = pd.read_csv('data/pokerhand/pokerhand_test.csv')
# ```end

# ```python
# Feature: Total Rank
# Usefulness: The total rank of the hand could be a useful feature to classify the 'class'. 
# A higher total rank could indicate a stronger hand.
train_data['total_rank'] = train_data[['r1', 'r2', 'r3', 'r4', 'r5']].sum(axis=1)
test_data['total_rank'] = test_data[['r1', 'r2', 'r3', 'r4', 'r5']].sum(axis=1)
# ```end

# ```python
# Feature: Total Suit
# Usefulness: The total suit of the hand could be a useful feature to classify the 'class'. 
# A higher total suit could indicate a stronger hand.
train_data['total_suit'] = train_data[['s1', 's2', 's3', 's4', 's5']].sum(axis=1)
test_data['total_suit'] = test_data[['s1', 's2', 's3', 's4', 's5']].sum(axis=1)
# ```end

# ```python-dropping-columns
# Explanation why the column XX is dropped
# The original rank and suit columns are dropped as we have created new features that aggregate their information.
train_data.drop(columns=['r1', 'r2', 'r3', 'r4', 'r5', 's1', 's2', 's3', 's4', 's5'], inplace=True)
test_data.drop(columns=['r1', 'r2', 'r3', 'r4', 'r5', 's1', 's2', 's3', 's4', 's5'], inplace=True)
# ```end-dropping-columns

# ```python
# Prepare the data for the model
X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']

# Scale the features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Train the model
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)
y_pred_proba = model.predict_proba(X_test)
# ```end

# ```python
# Report evaluation based on only test dataset
# Calculate the model accuracy, represented by a value between 0 and 1, where 0 indicates low accuracy and 1 signifies higher accuracy. Store the accuracy value in a variable labeled as "Accuracy=...".
# Calculate the model log loss, a lower log-loss value means better predictions. Store the  log loss value in a variable labeled as "Log_loss=...".
# Print the accuracy result: print(f"Accuracy:{Accuracy}")   
# Print the log loss result: print(f"Log_loss:{Log_loss}") 
unique_classes = y_train.unique()
Accuracy = accuracy_score(y_test, y_pred)
Log_loss = log_loss(y_test, y_pred_proba, labels=unique_classes)

print(f"Accuracy:{Accuracy}")   
print(f"Log_loss:{Log_loss}") 
# ```end