# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
# ```end

# ```python
# Load the training and test datasets
train_data = pd.read_csv("data/dataset_14/dataset_14_train.csv")
test_data = pd.read_csv("data/dataset_14/dataset_14_test.csv")
# ```end

# ```python
# (Feature name and description) 
# Usefulness: (Description why this adds useful real world knowledge to classify 'Purchase' according to dataset description and attributes.) 
# Adding a new column 'Total_Product_Categories' which is the sum of 'Product_Category_1', 'Product_Category_2', and 'Product_Category_3'. This might be useful as the total number of product categories a customer is interested in might affect their purchase.
train_data['Total_Product_Categories'] = train_data['Product_Category_1'] + train_data['Product_Category_2'] + train_data['Product_Category_3']
test_data['Total_Product_Categories'] = test_data['Product_Category_1'] + test_data['Product_Category_2'] + test_data['Product_Category_3']
# ```end

# ```python-dropping-columns
# Explanation why the column 'Product_Category_1', 'Product_Category_2', and 'Product_Category_3' are dropped
# These columns are dropped because they have been aggregated into a new feature 'Total_Product_Categories'
train_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3'], inplace=True)
test_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3'], inplace=True)
# ```end-dropping-columns

# ```python
# Use a 10-folds regression technique
# Explanation why the solution is selected: K-Fold Cross Validation is a common type of cross validation that is widely used in machine learning. K-fold cross validation is performed as per the following steps:
# Partition the original training data set into k equal subsets. Each subset is called a fold. Let the folds be named as f1, f2, …, fk.
# For i = 1 to i = k
# Keep the fold fi as Validation set and keep all the remaining k-1 folds in the Cross validation training set.
# Train your machine learning model using the cross validation training set and calculate the accuracy of your model by validating the predicted results against the validation set.
# Estimate the accuracy of your machine learning model by averaging the accuracies derived in all the k cases of cross validation.
# In the context of this problem, K-Fold Cross Validation will provide a robust way to understand the performance of the model on unseen data.

kf = KFold(n_splits=10)
model = LinearRegression()

X_train = train_data.drop(columns=['Purchase'])
y_train = train_data['Purchase']
X_test = test_data.drop(columns=['Purchase'])
y_test = test_data['Purchase']

for train_index, val_index in kf.split(X_train):
    X_train_fold, X_val_fold = X_train.iloc[train_index], X_train.iloc[val_index]
    y_train_fold, y_val_fold = y_train.iloc[train_index], y_train.iloc[val_index]
    
    model.fit(X_train_fold, y_train_fold)
# ```end

# ```python
# Report evaluation based on only test dataset
# Calculate the model R-Squared, represented by a value between 0 and 1, where 0 indicates low and 1 ndicates more variability is explained by the model. Store the R-Squared value in a variable labeled as "R_Squared=...".
# Calculate the model Root Mean Squared Error, where the lower the value of the Root Mean Squared Error, the better the model is.. Store the model Root Mean Squared Error value in a variable labeled as "RMSE=...".
# Print the accuracy result: print(f"R_Squared:{R_Squared}")   
# Print the log loss result: print(f"RMSE:{RMSE}") 

y_pred = model.predict(X_test)
R_Squared = r2_score(y_test, y_pred)
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

print(f"R_Squared:{R_Squared}")   
print(f"RMSE:{RMSE}") 
# ```end