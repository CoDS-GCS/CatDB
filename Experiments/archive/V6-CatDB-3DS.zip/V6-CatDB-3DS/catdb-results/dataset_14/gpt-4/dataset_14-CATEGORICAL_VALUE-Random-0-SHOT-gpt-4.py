# Import all required packages
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.impute import SimpleImputer

# Load the training and test datasets
train_data = pd.read_csv("data/dataset_14/dataset_14_train.csv")
test_data = pd.read_csv("data/dataset_14/dataset_14_test.csv")

# Remove low ration, static, and unique columns by getting statistic values
train_data = train_data.loc[:, train_data.apply(pd.Series.nunique) != 1]

# Add new columns that are useful for a downstream regression algorithm predicting "Purchase"
train_data['Total_Products_Purchased'] = train_data['Product_Category_1'] + train_data['Product_Category_2'] + train_data['Product_Category_3']

# Replace '0' in 'Stay_In_Current_City_Years' to avoid division by zero
train_data['Stay_In_Current_City_Years'].replace(0, 1, inplace=True)

train_data['Average_Age'] = train_data['Age'] / train_data['Stay_In_Current_City_Years']
train_data['Occupation_Level'] = train_data['Occupation'] / train_data['Stay_In_Current_City_Years']

# Drop the 'Product_Category_1', 'Product_Category_2', 'Product_Category_3' columns as they may be redundant and hurt the predictive performance of the downstream regressor
train_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3'], inplace=True)

# Use a 10-folds regression technique for constructing the model
kf = KFold(n_splits=10)
model = LinearRegression()

X = train_data.drop(columns=['Purchase'])
y = train_data['Purchase']

# Create an imputer object with a median filling strategy
imputer = SimpleImputer(strategy='median')

# Train on the training features
imputer.fit(X)

# Transform both training data and testing data
X = imputer.transform(X)

for train_index, test_index in kf.split(X):
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]
    model.fit(X_train, y_train)

# Report evaluation based on only test dataset
y_pred = model.predict(X_test)

# Calculate the model R-Squared
R_Squared = r2_score(y_test, y_pred)

# Calculate the model Root Mean Squared Error
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

# Print the accuracy result
print(f"R_Squared:{R_Squared}")   

# Print the log loss result
print(f"RMSE:{RMSE}")