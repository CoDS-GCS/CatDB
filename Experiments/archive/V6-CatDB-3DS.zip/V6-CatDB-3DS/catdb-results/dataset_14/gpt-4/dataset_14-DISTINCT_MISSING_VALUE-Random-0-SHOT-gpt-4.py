# Import all required packages
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Load the training and test datasets
train_data = pd.read_csv("data/dataset_14/dataset_14_train.csv")
test_data = pd.read_csv("data/dataset_14/dataset_14_test.csv")

# Add new columns that are useful for a downstream regression algorithm predicting "Purchase"
# Total_Products: Total number of products purchased by a customer
train_data['Total_Products'] = train_data['Product_Category_1'] + train_data['Product_Category_2'] + train_data['Product_Category_3']
test_data['Total_Products'] = test_data['Product_Category_1'] + test_data['Product_Category_2'] + test_data['Product_Category_3']

# Total_Spend: Total amount spent by a customer
train_data['Total_Spend'] = train_data['Purchase'] * train_data['Total_Products']
test_data['Total_Spend'] = test_data['Purchase'] * test_data['Total_Products']

# The columns 'Product_Category_1', 'Product_Category_2', and 'Product_Category_3' are dropped because they are now represented by the new column 'Total_Products'.
train_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3'], inplace=True)
test_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3'], inplace=True)

# Use a 10-folds regression technique for constructing the model
kf = KFold(n_splits=10)
model = LinearRegression()

for train_index, test_index in kf.split(train_data):
    X_train, X_test = train_data.drop('Purchase', axis=1).iloc[train_index], train_data.drop('Purchase', axis=1).iloc[test_index]
    y_train, y_test = train_data['Purchase'].iloc[train_index], train_data['Purchase'].iloc[test_index]

    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

# Report evaluation based on only test dataset
test_predictions = model.predict(test_data.drop('Purchase', axis=1))
R_Squared = r2_score(test_data['Purchase'], test_predictions)
RMSE = np.sqrt(mean_squared_error(test_data['Purchase'], test_predictions))

print(f"R_Squared:{R_Squared}")
print(f"RMSE:{RMSE}")