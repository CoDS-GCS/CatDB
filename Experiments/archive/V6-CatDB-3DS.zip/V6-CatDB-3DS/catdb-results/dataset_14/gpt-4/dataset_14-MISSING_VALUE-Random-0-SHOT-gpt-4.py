# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
# ```end

# ```python
# Load the training and test datasets
train_data = pd.read_csv('data/dataset_14/dataset_14_train.csv')
test_data = pd.read_csv('data/dataset_14/dataset_14_test.csv')
# ```end

# ```python
# Feature: Total_Products
# Usefulness: This feature represents the total number of products purchased by a customer. It can be useful in predicting the 'Purchase' as customers who buy more products might have a higher total purchase amount.
train_data['Total_Products'] = train_data['Product_Category_1'] + train_data['Product_Category_2'] + train_data['Product_Category_3']
test_data['Total_Products'] = test_data['Product_Category_1'] + test_data['Product_Category_2'] + test_data['Product_Category_3']
# ```end

# ```python-dropping-columns
# Explanation why the column 'Product_Category_1', 'Product_Category_2', 'Product_Category_3' are dropped
# These columns are dropped because they are now represented by the new feature 'Total_Products' and keeping them would lead to multicollinearity.
train_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3'], inplace=True)
test_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3'], inplace=True)
# ```end-dropping-columns

# ```python
# Use a 10-folds cross-validation technique
# Explanation why the solution is selected: This technique is selected because it provides a robust estimate of the model performance by training and testing the model on different subsets of the data.
kf = KFold(n_splits=10, shuffle=True, random_state=1)

# Separate features and target variable
X = train_data.drop(columns=['Purchase'])
y = train_data['Purchase']

# Initialize the model
model = LinearRegression()

# Train and evaluate the model using cross-validation
r2_scores = []
rmse_scores = []
for train_index, test_index in kf.split(X):
    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]
    
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    r2_scores.append(r2_score(y_test, y_pred))
    rmse_scores.append(np.sqrt(mean_squared_error(y_test, y_pred)))

# Calculate the average R-Squared and RMSE
R_Squared = np.mean(r2_scores)
RMSE = np.mean(rmse_scores)

# Print the accuracy result
print(f"R_Squared:{R_Squared}")   

# Print the log loss result
print(f"RMSE:{RMSE}") 
# ```end