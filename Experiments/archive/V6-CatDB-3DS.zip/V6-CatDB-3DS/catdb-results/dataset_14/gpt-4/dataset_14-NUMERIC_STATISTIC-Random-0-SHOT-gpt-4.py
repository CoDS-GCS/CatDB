# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
# ```end

# ```python
# Load the training and test datasets
train_data = pd.read_csv("data/dataset_14/dataset_14_train.csv")
test_data = pd.read_csv("data/dataset_14/dataset_14_test.csv")
# ```end

# ```python
# Remove low ration, static, and unique columns by getting statistic values
# Here we assume that columns with standard deviation less than 0.1 are considered static
std_dev = train_data.std()
low_std_dev_columns = std_dev[std_dev < 0.1].index
train_data.drop(columns=low_std_dev_columns, inplace=True)
test_data.drop(columns=low_std_dev_columns, inplace=True)
# ```end

# ```python
# Add new column 'Total_Product_Categories' which is the sum of 'Product_Category_1', 'Product_Category_2' and 'Product_Category_3'
# Usefulness: This adds useful real world knowledge to classify 'Purchase' as it gives an idea about the total categories of products a customer is interested in.
train_data['Total_Product_Categories'] = train_data['Product_Category_1'] + train_data['Product_Category_2'] + train_data['Product_Category_3']
test_data['Total_Product_Categories'] = test_data['Product_Category_1'] + test_data['Product_Category_2'] + test_data['Product_Category_3']
# ```end

# ```python-dropping-columns
# Drop 'Product_Category_1', 'Product_Category_2' and 'Product_Category_3' as they are now represented by 'Total_Product_Categories'
train_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3'], inplace=True)
test_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3'], inplace=True)
# ```end-dropping-columns

# ```python
# Use a 10-folds regression technique for constructing the model
# Explanation: K-Fold Cross validation is used to assess the predictive performance of the models and and to judge how they perform outside the sample to a new data set also known as test data
kf = KFold(n_splits=10, shuffle=True, random_state=1)

X = train_data.drop(columns=['Purchase'])
y = train_data['Purchase']

model = LinearRegression()

for train_index, test_index in kf.split(X):
    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]
    
    model.fit(X_train, y_train)
# ```end

# ```python
# Report evaluation based on only test dataset
X_test = test_data.drop(columns=['Purchase'])
y_test = test_data['Purchase']

y_pred = model.predict(X_test)

# Calculate the model R-Squared
R_Squared = r2_score(y_test, y_pred)

# Calculate the model Root Mean Squared Error
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

# Print the accuracy result
print(f"R_Squared:{R_Squared}")   

# Print the log loss result
print(f"RMSE:{RMSE}") 
# ```end