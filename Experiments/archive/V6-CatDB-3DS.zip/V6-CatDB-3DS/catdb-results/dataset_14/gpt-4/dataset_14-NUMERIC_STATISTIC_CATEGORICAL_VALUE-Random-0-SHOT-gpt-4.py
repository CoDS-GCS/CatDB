# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
# ```end

# ```python
# Load the training and test datasets
train_data = pd.read_csv("data/dataset_14/dataset_14_train.csv")
test_data = pd.read_csv("data/dataset_14/dataset_14_test.csv")
# ```end

# ```python
# Remove low ration, static, and unique columns by getting statistic values
# Here we assume that columns with a distinct count less than 2 are considered static/unique
for col in train_data.columns:
    if train_data[col].nunique() < 2:
        train_data.drop(columns=[col], inplace=True)
        test_data.drop(columns=[col], inplace=True)
# ```end

# ```python
# Add new columns that are useful for a downstream regression algorithm predicting "Purchase"
# Here we add a column that is the sum of the product categories
# Usefulness: This adds useful real world knowledge as it gives a total count of the product categories which might be related to the purchase
train_data['Total_Product_Categories'] = train_data['Product_Category_1'] + train_data['Product_Category_2'] + train_data['Product_Category_3']
test_data['Total_Product_Categories'] = test_data['Product_Category_1'] + test_data['Product_Category_2'] + test_data['Product_Category_3']
# ```end

# ```python-dropping-columns
# Explanation why the column 'Product_Category_1', 'Product_Category_2', 'Product_Category_3' are dropped
# These columns are dropped because we have created a new column 'Total_Product_Categories' that aggregates the information contained in these columns
train_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3'], inplace=True)
test_data.drop(columns=['Product_Category_1', 'Product_Category_2', 'Product_Category_3'], inplace=True)
# ```end-dropping-columns

# ```python
# Use a 10-folds regression technique for constructing the model
# Explanation why the solution is selected: K-Fold Cross validation is one of the most common techniques for evaluating the performance of a machine learning algorithm. It provides a robust estimate of the performance of the model on unseen data.

kf = KFold(n_splits=10)
model = LinearRegression()

X_train = train_data.drop(columns=['Purchase'])
y_train = train_data['Purchase']

for train_index, test_index in kf.split(X_train):
    X_train_fold, X_test_fold = X_train.iloc[train_index], X_train.iloc[test_index]
    y_train_fold, y_test_fold = y_train.iloc[train_index], y_train.iloc[test_index]
    
    model.fit(X_train_fold, y_train_fold)
# ```end

# ```python
# Report evaluation based on only test dataset
X_test = test_data.drop(columns=['Purchase'])
y_test = test_data['Purchase']

y_pred = model.predict(X_test)

# Calculate the model R-Squared
R_Squared = r2_score(y_test, y_pred)

# Calculate the model Root Mean Squared Error
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))

# Print the accuracy result
print(f"R_Squared:{R_Squared}")   

# Print the log loss result
print(f"RMSE:{RMSE}") 
# ```end