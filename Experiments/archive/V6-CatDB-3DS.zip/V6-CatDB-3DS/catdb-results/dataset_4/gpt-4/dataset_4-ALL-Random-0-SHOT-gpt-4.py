# Import all required packages
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import LabelEncoder

# Load the training and test datasets
train_data = pd.read_csv("data/dataset_4/dataset_4_train.csv")
test_data = pd.read_csv("data/dataset_4/dataset_4_test.csv")

# Label encoding for categorical columns
le1 = LabelEncoder()
le2 = LabelEncoder()
le3 = LabelEncoder()

train_data['AirportFrom'] = le1.fit_transform(train_data['AirportFrom'])
train_data['AirportTo'] = le2.fit_transform(train_data['AirportTo'])
train_data['Airline'] = le3.fit_transform(train_data['Airline'])

test_data['AirportFrom'] = le1.transform(test_data['AirportFrom'])
test_data['AirportTo'] = le2.transform(test_data['AirportTo'])
test_data['Airline'] = le3.transform(test_data['Airline'])

# The Flight column is dropped because it has a high cardinality and may lead to overfitting.
train_data.drop(columns=['Flight'], inplace=True)
test_data.drop(columns=['Flight'], inplace=True)

# Use a RandomForestClassifier technique
X_train = train_data.drop(columns=['class'])
y_train = train_data['class']

X_test = test_data.drop(columns=['class'])
y_test = test_data['class']

clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)

# Report evaluation based on only test dataset
y_pred = clf.predict(X_test)

# Calculate the model accuracy
Accuracy = accuracy_score(y_test, y_pred)

# Calculate the model f1 score
F1_score = f1_score(y_test, y_pred)

# Print the accuracy result
print(f"Accuracy:{Accuracy}")

# Print the f1 score result
print(f"F1_score:{F1_score}")