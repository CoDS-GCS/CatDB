# ```python
# Import all required packages
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import LabelEncoder

# Load the training and test datasets
train_data = pd.read_csv('data/dataset_4/dataset_4_train.csv')
test_data = pd.read_csv('data/dataset_4/dataset_4_test.csv')

# Label Encoding for categorical variables
le = LabelEncoder()

for column in ['AirportFrom', 'AirportTo', 'Airline']:
    le.fit(pd.concat([train_data[column], test_data[column]]))
    train_data[column] = le.transform(train_data[column])
    test_data[column] = le.transform(test_data[column])

# 'Time' column is dropped because it is a continuous variable and may not contribute to the binary classification problem.
train_data.drop(columns=['Time'], inplace=True)
test_data.drop(columns=['Time'], inplace=True)

# Use a RandomForestClassifier technique
clf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)

# 10-folds binary classification
skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
X = train_data.drop(columns=['class'])
y = train_data['class']

for train_index, test_index in skf.split(X, y):
    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]
    clf.fit(X_train, y_train)

# Report evaluation based on only test dataset
X_test = test_data.drop(columns=['class'])
y_test = test_data['class']
y_pred = clf.predict(X_test)

# Calculate the model accuracy
Accuracy = accuracy_score(y_test, y_pred)

# Calculate the model f1 score
F1_score = f1_score(y_test, y_pred)

# Print the accuracy result
print(f"Accuracy:{Accuracy}")   

# Print the f1 score result
print(f"F1_score:{F1_score}") 
# ```