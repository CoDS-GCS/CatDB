# ```python
# Import all required packages
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import LabelEncoder
# ```end

# ```python
# Load the training and test datasets
train_data = pd.read_csv('data/dataset_4/dataset_4_train.csv')
test_data = pd.read_csv('data/dataset_4/dataset_4_test.csv')
# ```end

# ```python
# Label encoding for categorical columns
le = LabelEncoder()
categorical_columns = ['AirportFrom', 'AirportTo', 'Airline']
for column in categorical_columns:
    train_data[column] = le.fit_transform(train_data[column])
    test_data[column] = le.transform(test_data[column])
# ```end

# ```python
# Drop columns that may be redundant and hurt the predictive performance
# Explanation: 'Flight' column is dropped because it does not add any useful real world knowledge to classify 'class'
train_data.drop(columns=['Flight'], inplace=True)
test_data.drop(columns=['Flight'], inplace=True)
# ```end-dropping-columns

# ```python
# Use a 10-folds binary classification technique for constructing the model
# Explanation: StratifiedKFold is used to ensure that each fold of the dataset has the same proportion of observations with a given label.
skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=1)
X = train_data.drop('class', axis=1)
y = train_data['class']
for train_index, test_index in skf.split(X, y):
    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]
    model = RandomForestClassifier(n_jobs=-1)
    model.fit(X_train, y_train)
# ```end

# ```python
# Report evaluation based on only test dataset
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']
y_pred = model.predict(X_test)
Accuracy = accuracy_score(y_test, y_pred)
F1_score = f1_score(y_test, y_pred)
print(f"Accuracy:{Accuracy}")
print(f"F1_score:{F1_score}")
# ```end