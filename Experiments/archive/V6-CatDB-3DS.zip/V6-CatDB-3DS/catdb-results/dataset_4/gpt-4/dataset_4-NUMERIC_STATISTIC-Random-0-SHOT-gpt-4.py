# ```python
# Import all required packages
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
# ```end

# ```python
# Load the training and test datasets
train_data = pd.read_csv('data/dataset_4/dataset_4_train.csv')
test_data = pd.read_csv('data/dataset_4/dataset_4_test.csv')
# ```end

# ```python
# Remove low ration, static, and unique columns by getting statistic values
# Here we assume that 'Flight' is a unique identifier for each flight and does not provide any useful information for the classification task
train_data.drop(columns=['Flight'], inplace=True)
test_data.drop(columns=['Flight'], inplace=True)
# ```end-dropping-columns

# ```python
# Add a new feature 'IsWeekend' which indicates whether the day of the week is a weekend or not
# Usefulness: This adds useful real world knowledge to classify 'class' as flight patterns may differ between weekdays and weekends
train_data['IsWeekend'] = train_data['DayOfWeek'].apply(lambda x: 1 if x >= 6 else 0)
test_data['IsWeekend'] = test_data['DayOfWeek'].apply(lambda x: 1 if x >= 6 else 0)
# ```end

# ```python
# Convert categorical variables into dummy/indicator variables
train_data = pd.get_dummies(train_data, columns=['AirportFrom', 'AirportTo', 'Airline'])
test_data = pd.get_dummies(test_data, columns=['AirportFrom', 'AirportTo', 'Airline'])
# ```end

# ```python
# Use a RandomForestClassifier technique
# Explanation: RandomForestClassifier is a robust and versatile classifier that works well on a wide range of datasets. It can handle both categorical and numerical features, and it also provides a good indicator of the importance it assigns to the features.
X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']

# Initialize the model
clf = RandomForestClassifier(n_jobs=-1)

# Train the model
clf.fit(X_train, y_train)
# ```end

# ```python
# Report evaluation based on only test dataset
# Calculate the model accuracy
y_pred = clf.predict(X_test)
Accuracy = accuracy_score(y_test, y_pred)

# Calculate the model f1 score
F1_score = f1_score(y_test, y_pred)

# Print the accuracy result
print(f"Accuracy:{Accuracy}")

# Print the f1 score result
print(f"F1_score:{F1_score}")
# ```end