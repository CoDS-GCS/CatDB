# ```python
# Import all required packages
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import LabelEncoder
# ```end

# ```python
# Load the training and test datasets
train_data = pd.read_csv('data/dataset_4/dataset_4_train.csv')
test_data = pd.read_csv('data/dataset_4/dataset_4_test.csv')
# ```end

# ```python
# Drop columns with high cardinality and low variance
# Explanation: Columns with high cardinality may lead to overfitting and columns with low variance may not contribute much to the model
train_data.drop(columns=['Flight', 'AirportFrom', 'AirportTo'], inplace=True)
test_data.drop(columns=['Flight', 'AirportFrom', 'AirportTo'], inplace=True)
# ```end-dropping-columns

# ```python
# Encode categorical columns
# Explanation: Machine learning algorithms work better with numerical data
le = LabelEncoder()
train_data['Airline'] = le.fit_transform(train_data['Airline'])
test_data['Airline'] = le.transform(test_data['Airline'])
# ```end

# ```python
# Use a 10-folds cross-validation technique
# Explanation: This technique helps to avoid overfitting and gives a better estimate of the model performance
skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=1)

X_train = train_data.drop(columns=['class'])
y_train = train_data['class']
X_test = test_data.drop(columns=['class'])
y_test = test_data['class']

clf = RandomForestClassifier(n_estimators=100, random_state=1)

for train_index, val_index in skf.split(X_train, y_train):
    X_train_fold, X_val_fold = X_train.iloc[train_index], X_train.iloc[val_index]
    y_train_fold, y_val_fold = y_train.iloc[train_index], y_train.iloc[val_index]
    
    clf.fit(X_train_fold, y_train_fold)
# ```end

# ```python
# Report evaluation based on only test dataset
y_pred = clf.predict(X_test)

# Calculate the model accuracy
Accuracy = accuracy_score(y_test, y_pred)

# Calculate the model f1 score
F1_score = f1_score(y_test, y_pred)

# Print the accuracy result
print(f"Accuracy:{Accuracy}")

# Print the f1 score result
print(f"F1_score:{F1_score}")
# ```end