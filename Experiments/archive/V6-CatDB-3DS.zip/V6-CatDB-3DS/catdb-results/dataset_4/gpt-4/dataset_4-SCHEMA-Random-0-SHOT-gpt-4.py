# Import all required packages
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import LabelEncoder

# Load the training and test datasets
train_data = pd.read_csv('data/dataset_4/dataset_4_train.csv')
test_data = pd.read_csv('data/dataset_4/dataset_4_test.csv')

# Label encoding for categorical columns
le1 = LabelEncoder()
le2 = LabelEncoder()
le3 = LabelEncoder()

train_data['AirportFrom'] = le1.fit_transform(train_data['AirportFrom'])
train_data['AirportTo'] = le2.fit_transform(train_data['AirportTo'])
train_data['Airline'] = le3.fit_transform(train_data['Airline'])

test_data['AirportFrom'] = le1.transform(test_data['AirportFrom'])
test_data['AirportTo'] = le2.transform(test_data['AirportTo'])
test_data['Airline'] = le3.transform(test_data['Airline'])

# Drop columns that may be redundant and hurt the predictive performance
train_data.drop(columns=['Time', 'Flight'], inplace=True)
test_data.drop(columns=['Time', 'Flight'], inplace=True)

# Use a 10-folds binary classification technique for constructing the model
X = train_data.drop('class', axis=1)
y = train_data['class']

skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=1)
clf = RandomForestClassifier(n_jobs=-1)

for train_index, test_index in skf.split(X, y):
    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]
    clf.fit(X_train, y_train)

# Report evaluation based on only test dataset
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']

y_pred = clf.predict(X_test)

# Calculate the model accuracy
Accuracy = accuracy_score(y_test, y_pred)

# Calculate the model f1 score
F1_score = f1_score(y_test, y_pred)

# Print the accuracy result
print(f"Accuracy:{Accuracy}")

# Print the f1 score result
print(f"F1_score:{F1_score}")