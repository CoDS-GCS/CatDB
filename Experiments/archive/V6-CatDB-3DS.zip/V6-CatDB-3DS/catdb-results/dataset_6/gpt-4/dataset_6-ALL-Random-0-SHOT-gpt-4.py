# ```python
# Import all required packages
import pandas as pd
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.preprocessing import LabelBinarizer

# Load the training and test datasets
train_data = pd.read_csv("data/dataset_6/dataset_6_train.csv")
test_data = pd.read_csv("data/dataset_6/dataset_6_test.csv")

# Drop columns with unique values
train_data = train_data.loc[:, train_data.nunique() != 1]
test_data = test_data.loc[:, test_data.nunique() != 1]

# Drop columns with high ratio of missing values
missing_ratio = train_data.isnull().sum() / len(train_data)
train_data = train_data.loc[:, missing_ratio < 0.5]
test_data = test_data.loc[:, missing_ratio < 0.5]

# Drop columns with high ratio of unique values
unique_ratio = train_data.nunique() / len(train_data)
train_data = train_data.loc[:, unique_ratio < 0.5]
test_data = test_data.loc[:, unique_ratio < 0.5]

# Define target and features
target = 'relevance'
features = [col for col in train_data.columns if col != target]

# Define the classifier
clf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)

# Use a 10-folds cross-validation technique
cv = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)

# Train the model
scores = cross_val_score(clf, train_data[features], train_data[target], cv=cv, scoring='accuracy')
print(f"Cross-validation accuracy: {scores.mean()}")

# Fit the model on the whole training set
clf.fit(train_data[features], train_data[target])

# Predict the test set results
y_pred = clf.predict(test_data[features])

# Calculate the accuracy
Accuracy = accuracy_score(test_data[target], y_pred)
print(f"Accuracy: {Accuracy}")

# Calculate the log loss
lb = LabelBinarizer()
y_test_bin = lb.fit_transform(test_data[target])
y_pred_bin = lb.transform(y_pred)
Log_loss = log_loss(y_test_bin, y_pred_bin)
print(f"Log loss: {Log_loss}")
# ```