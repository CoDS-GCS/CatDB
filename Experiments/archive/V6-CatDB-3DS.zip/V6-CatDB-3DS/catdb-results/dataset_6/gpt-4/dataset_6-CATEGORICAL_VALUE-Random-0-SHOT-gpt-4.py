# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
# ```end

# ```python
# Load the training and test datasets
train_data = pd.read_csv("data/dataset_6/dataset_6_train.csv")
test_data = pd.read_csv("data/dataset_6/dataset_6_test.csv")
# ```end

# ```python
# Drop columns with unique values
for col in train_data.columns:
    if len(train_data[col].unique()) == 1:
        train_data.drop(columns=[col], inplace=True)
        test_data.drop(columns=[col], inplace=True)
# ```end

# ```python
# Drop columns with high cardinality
for col in train_data.columns:
    if len(train_data[col].unique()) > 1000:
        train_data.drop(columns=[col], inplace=True)
        test_data.drop(columns=[col], inplace=True)
# ```end

# ```python
# Feature Engineering
# Add a new feature that is the ratio of the length of URL to the number of slashes in the URL
# Usefulness: This feature can provide information about the complexity of the URL, which can be useful for predicting 'relevance'.
train_data['url_complexity'] = train_data['Length_of_URL'] / train_data['Number_of_slash_in_URL']
test_data['url_complexity'] = test_data['Length_of_URL'] / test_data['Number_of_slash_in_URL']
# ```end

# ```python
# Prepare data for training
X_train = train_data.drop(columns=['relevance'])
y_train = train_data['relevance']
X_test = test_data.drop(columns=['relevance'])
y_test = test_data['relevance']
# ```end

# ```python
# Use a RandomForestClassifier technique
# Explanation: RandomForestClassifier is a robust and versatile classifier that can handle both categorical and numerical features. It also has built-in feature importance estimation, which can be useful for feature selection.
clf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
# ```end

# ```python
# Train the model using 10-fold cross validation
kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
for train_index, val_index in kfold.split(X_train, y_train):
    clf.fit(X_train.iloc[train_index], y_train.iloc[train_index])
# ```end

# ```python
# Predict the test set results
y_pred = clf.predict(X_test)
y_pred_proba = clf.predict_proba(X_test)
# ```end

# ```python
# Report evaluation based on only test dataset
Accuracy = accuracy_score(y_test, y_pred)
Log_loss = log_loss(y_test, y_pred_proba)
print(f"Accuracy:{Accuracy}")
print(f"Log_loss:{Log_loss}")
# ```end