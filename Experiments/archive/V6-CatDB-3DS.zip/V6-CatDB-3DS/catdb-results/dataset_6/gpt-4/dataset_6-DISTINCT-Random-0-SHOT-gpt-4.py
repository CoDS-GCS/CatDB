# ```python
# Import all required packages
import pandas as pd
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
# ```end

# ```python
# Load the training and test datasets
train_data = pd.read_csv("data/dataset_6/dataset_6_train.csv")
test_data = pd.read_csv("data/dataset_6/dataset_6_test.csv")
# ```end

# ```python
# Drop columns with unique values for each row, as they do not provide any useful information for the model
# Also drop columns with a single unique value, as they do not provide any variance for the model
for column in train_data.columns:
    if train_data[column].nunique() == 1 or train_data[column].nunique() == len(train_data):
        train_data.drop(columns=[column], inplace=True)
        test_data.drop(columns=[column], inplace=True)
# ```end

# ```python
# Feature Engineering
# Add a new feature that is the ratio of the length of URL to the number of slashes in the URL
# This could be useful as it might indicate the complexity of the website structure, which could be related to the relevance
train_data['URL_to_slash_ratio'] = train_data['Length_of_URL'] / train_data['Number_of_slash_in_URL']
test_data['URL_to_slash_ratio'] = test_data['Length_of_URL'] / test_data['Number_of_slash_in_URL']
# ```end

# ```python
# Prepare the data for the model
X_train = train_data.drop(columns=['relevance'])
y_train = train_data['relevance']
X_test = test_data.drop(columns=['relevance'])
y_test = test_data['relevance']
# ```end

# ```python
# Use a RandomForestClassifier technique
# RandomForestClassifier is a robust and versatile classifier that works well on a wide range of datasets
# It can handle a large number of features and it's less likely to overfit than other classifiers
clf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
# ```end

# ```python
# Use 10-folds cross-validation for model training
skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
for train_index, val_index in skf.split(X_train, y_train):
    clf.fit(X_train.iloc[train_index], y_train.iloc[train_index])
# ```end

# ```python
# Predict the test set results
y_pred = clf.predict(X_test)
y_pred_proba = clf.predict_proba(X_test)
# ```end

# ```python
# Report evaluation based on only test dataset
Accuracy = accuracy_score(y_test, y_pred)
Log_loss = log_loss(y_test, y_pred_proba)
print(f"Accuracy: {Accuracy}")
print(f"Log loss: {Log_loss}")
# ```end