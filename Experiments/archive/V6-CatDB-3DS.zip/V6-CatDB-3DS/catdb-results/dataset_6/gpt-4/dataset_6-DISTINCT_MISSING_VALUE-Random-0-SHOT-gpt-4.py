# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
# ```end

# ```python
# Load the training and test datasets
train_data = pd.read_csv("data/dataset_6/dataset_6_train.csv")
test_data = pd.read_csv("data/dataset_6/dataset_6_test.csv")
# ```end

# ```python
# Drop columns with unique values as they do not contribute to the model
for col in train_data.columns:
    if len(train_data[col].unique()) == 1:
        train_data.drop(col,inplace=True,axis=1)
        test_data.drop(col,inplace=True,axis=1)
# ```end

# ```python
# Feature Engineering
# Add new column 'total_term_frequency' which is the sum of term frequencies in url, anchor, title, body and whole document
# Usefulness: This feature gives an overall idea of the term frequency in the document which can be useful in determining the relevance
train_data['total_term_frequency'] = train_data['sum_of_term_frequency-url'] + train_data['sum_of_term_frequency-anchor'] + train_data['sum_of_term_frequency-title'] + train_data['sum_of_term_frequency-body'] + train_data['sum_of_term_frequency-whole_document']
test_data['total_term_frequency'] = test_data['sum_of_term_frequency-url'] + test_data['sum_of_term_frequency-anchor'] + test_data['sum_of_term_frequency-title'] + test_data['sum_of_term_frequency-body'] + test_data['sum_of_term_frequency-whole_document']
# ```end

# ```python
# Prepare data for training
X_train = train_data.drop('relevance', axis=1)
y_train = train_data['relevance']
X_test = test_data.drop('relevance', axis=1)
y_test = test_data['relevance']
# ```end

# ```python
# Use a RandomForestClassifier technique
# Explanation: RandomForestClassifier is a robust and versatile classifier that works well on multiclass classification problems. It also handles feature interactions well.
clf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
# ```end

# ```python
# Use 10-folds cross-validation for model construction
skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
for train_index, val_index in skf.split(X_train, y_train):
    clf.fit(X_train.iloc[train_index], y_train.iloc[train_index])
# ```end

# ```python
# Predict on the test set
y_pred = clf.predict(X_test)
y_pred_proba = clf.predict_proba(X_test)
# ```end

# ```python
# Report evaluation based on only test dataset
# Calculate the model accuracy
Accuracy = accuracy_score(y_test, y_pred)
# Calculate the model log loss
Log_loss = log_loss(y_test, y_pred_proba)
# Print the accuracy result
print(f"Accuracy:{Accuracy}")
# Print the log loss result
print(f"Log_loss:{Log_loss}")
# ```end