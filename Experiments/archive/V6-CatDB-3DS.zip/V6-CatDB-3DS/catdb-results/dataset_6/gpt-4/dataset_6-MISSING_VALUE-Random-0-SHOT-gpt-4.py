# ```python
# Import all required packages
import pandas as pd
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.preprocessing import LabelEncoder
# ```end

# ```python
# Load the training and test datasets
train_data = pd.read_csv('data/dataset_6/dataset_6_train.csv')
test_data = pd.read_csv('data/dataset_6/dataset_6_test.csv')
# ```end

# ```python
# Feature Engineering
# Adding a new feature 'total_term_frequency' which is the sum of term frequencies in url, anchor, title, body and whole document
# Usefulness: This feature can provide a holistic view of term frequency across all parts of the document which can be useful in determining 'relevance'
train_data['total_term_frequency'] = train_data['sum_of_term_frequency-url'] + train_data['sum_of_term_frequency-anchor'] + train_data['sum_of_term_frequency-title'] + train_data['sum_of_term_frequency-body'] + train_data['sum_of_term_frequency-whole_document']
test_data['total_term_frequency'] = test_data['sum_of_term_frequency-url'] + test_data['sum_of_term_frequency-anchor'] + test_data['sum_of_term_frequency-title'] + test_data['sum_of_term_frequency-body'] + test_data['sum_of_term_frequency-whole_document']
# ```end

# ```python-dropping-columns
# Dropping 'QualityScore' and 'QualityScore2' columns as they might be redundant and can lead to overfitting
train_data.drop(columns=['QualityScore', 'QualityScore2'], inplace=True)
test_data.drop(columns=['QualityScore', 'QualityScore2'], inplace=True)
# ```end-dropping-columns

# ```python
# Preprocessing
# Encoding boolean columns
bool_cols = ['boolean_model-anchor', 'boolean_model-whole_document', 'boolean_model-url', 'boolean_model-title', 'boolean_model-body']
le = LabelEncoder()
for col in bool_cols:
    train_data[col] = le.fit_transform(train_data[col])
    test_data[col] = le.transform(test_data[col])

# Separating features and target variable
X_train = train_data.drop('relevance', axis=1)
y_train = train_data['relevance']
X_test = test_data.drop('relevance', axis=1)
y_test = test_data['relevance']
# ```end

# ```python 
# Use a RandomForestClassifier technique
# RandomForestClassifier is selected because it can handle large datasets with high dimensionality and can model complex relationships.
clf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
clf.fit(X_train, y_train)
# ```end

# ```python
# Report evaluation based on only test dataset
y_pred = clf.predict(X_test)
y_pred_proba = clf.predict_proba(X_test)

# Calculate the model accuracy
Accuracy = accuracy_score(y_test, y_pred)

# Calculate the model log loss
Log_loss = log_loss(y_test, y_pred_proba)

# Print the accuracy result
print(f"Accuracy:{Accuracy}")

# Print the log loss result
print(f"Log_loss:{Log_loss}")
# ```end