# ```python
# Import all required packages
import pandas as pd
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.preprocessing import LabelEncoder
# ```end

# ```python
# Load the training and test datasets
train_data = pd.read_csv("data/dataset_6/dataset_6_train.csv")
test_data = pd.read_csv("data/dataset_6/dataset_6_test.csv")
# ```end

# ```python
# Remove low ration, static, and unique columns by getting statistic values
for column in train_data.columns:
    if len(train_data[column].unique()) < 2:
        train_data.drop(columns=[column], inplace=True)
        test_data.drop(columns=[column], inplace=True)
# ```end

# ```python
# Convert boolean columns to int
for column in train_data.columns:
    if train_data[column].dtype == 'bool':
        train_data[column] = train_data[column].astype(int)
        test_data[column] = test_data[column].astype(int)
# ```end

# ```python
# Label encoding for categorical columns
le = LabelEncoder()
for column in train_data.columns:
    if train_data[column].dtype == 'object':
        train_data[column] = le.fit_transform(train_data[column])
        test_data[column] = le.transform(test_data[column])
# ```end

# ```python
# Define target and features
target = 'relevance'
features = [col for col in train_data.columns if col != target]

X_train = train_data[features]
y_train = train_data[target]
X_test = test_data[features]
y_test = test_data[target]
# ```end

# ```python
# Use a RandomForestClassifier technique
# RandomForestClassifier is selected because it is a robust and versatile classifier that works well on both linear and non-linear problems.
clf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
# ```end

# ```python
# Use 10-folds multiclass classification technique for constructing the model
kfold = StratifiedKFold(n_splits=10)
for train_index, test_index in kfold.split(X_train, y_train):
    clf.fit(X_train.iloc[train_index], y_train.iloc[train_index])
# ```end

# ```python
# Report evaluation based on only test dataset
y_pred = clf.predict(X_test)
y_pred_proba = clf.predict_proba(X_test)

# Calculate the model accuracy
Accuracy = accuracy_score(y_test, y_pred)

# Calculate the model log loss
Log_loss = log_loss(y_test, y_pred_proba)

# Print the accuracy result
print(f"Accuracy:{Accuracy}")

# Print the log loss result
print(f"Log_loss:{Log_loss}")
# ```end
