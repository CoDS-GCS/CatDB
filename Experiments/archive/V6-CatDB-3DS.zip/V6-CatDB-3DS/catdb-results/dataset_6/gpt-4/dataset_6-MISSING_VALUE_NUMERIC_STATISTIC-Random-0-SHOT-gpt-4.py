# ```python
# Import all required packages
import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
# ```end

# ```python
# Load the training and test datasets
train_data = pd.read_csv("data/dataset_6/dataset_6_train.csv")
test_data = pd.read_csv("data/dataset_6/dataset_6_test.csv")
# ```end

# ```python
# Feature Engineering
# Adding new features that might be useful for the downstream multiclass classification algorithm predicting "relevance"

# Feature: URL_Length_Ratio
# Usefulness: The length of the URL might be indicative of the relevance of the page. Longer URLs might be less relevant.
train_data['URL_Length_Ratio'] = train_data['Length_of_URL'] / train_data['Length_of_URL'].max()
test_data['URL_Length_Ratio'] = test_data['Length_of_URL'] / test_data['Length_of_URL'].max()

# Feature: Term_Frequency_Ratio
# Usefulness: The term frequency in the anchor, body, title, and URL might be indicative of the relevance of the page.
for column in ['anchor', 'body', 'title', 'url']:
    train_data[f'Term_Frequency_Ratio_{column}'] = train_data[f'sum_of_term_frequency-{column}'] / train_data[f'sum_of_term_frequency-{column}'].max()
    test_data[f'Term_Frequency_Ratio_{column}'] = test_data[f'sum_of_term_frequency-{column}'] / test_data[f'sum_of_term_frequency-{column}'].max()
# ```end

# ```python
# Dropping columns that might be redundant and hurt the predictive performance of the downstream classifier

# Dropping 'Length_of_URL' as we have created a new feature 'URL_Length_Ratio' which normalizes this feature
# Dropping 'sum_of_term_frequency-anchor', 'sum_of_term_frequency-body', 'sum_of_term_frequency-title', 'sum_of_term_frequency-url' as we have created new features 'Term_Frequency_Ratio_anchor', 'Term_Frequency_Ratio_body', 'Term_Frequency_Ratio_title', 'Term_Frequency_Ratio_url' which normalize these features
train_data.drop(columns=['Length_of_URL', 'sum_of_term_frequency-anchor', 'sum_of_term_frequency-body', 'sum_of_term_frequency-title', 'sum_of_term_frequency-url'], inplace=True)
test_data.drop(columns=['Length_of_URL', 'sum_of_term_frequency-anchor', 'sum_of_term_frequency-body', 'sum_of_term_frequency-title', 'sum_of_term_frequency-url'], inplace=True)
# ```end-dropping-columns

# ```python
# Preparing the data for the model
X_train = train_data.drop(columns=['relevance'])
y_train = train_data['relevance']
X_test = test_data.drop(columns=['relevance'])
y_test = test_data['relevance']
# ```end

# ```python
# Use a RandomForestClassifier technique
# RandomForestClassifier is a robust and versatile classifier that works well on a large range of datasets. It can handle a large number of features, and it's helpful for estimating which of your variables are important in the underlying data being modeled.
clf = RandomForestClassifier(n_jobs=-1, random_state=42)
# ```end

# ```python
# Training the model using 10-folds cross-validation
skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
for train_index, val_index in skf.split(X_train, y_train):
    clf.fit(X_train.iloc[train_index], y_train.iloc[train_index])
# ```end

# ```python
# Predicting the test set results and calculating the accuracy and log loss
y_pred = clf.predict(X_test)
y_pred_proba = clf.predict_proba(X_test)
Accuracy = accuracy_score(y_test, y_pred)
Log_loss = log_loss(y_test, y_pred_proba)
# ```end

# ```python
# Report evaluation based on only test dataset
print(f"Accuracy: {Accuracy}")
print(f"Log loss: {Log_loss}")
# ```end
