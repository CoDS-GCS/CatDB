# Import all required packages
import pandas as pd
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
from sklearn.preprocessing import LabelEncoder

# Load the training and test datasets
train_data = pd.read_csv("data/dataset_6/dataset_6_train.csv")
test_data = pd.read_csv("data/dataset_6/dataset_6_test.csv")

# Feature Engineering
# Adding new column 'url_length_category' based on 'Length_of_URL'
# Usefulness: Longer URLs are often associated with less relevant pages, this categorization can help the model to understand the relevance better.
train_data['url_length_category'] = pd.cut(train_data['Length_of_URL'], bins=[0,50,100,1500], labels=['short','medium','long'])
test_data['url_length_category'] = pd.cut(test_data['Length_of_URL'], bins=[0,50,100,1500], labels=['short','medium','long'])

# Dropping columns
# Explanation: Dropping 'Inlink_number' as it has negative values which is not possible in real world scenario. It might be due to data collection error.
train_data.drop(columns=['Inlink_number'], inplace=True)
test_data.drop(columns=['Inlink_number'], inplace=True)

# Convert categorical data to numerical data
le = LabelEncoder()
train_data['url_length_category'] = le.fit_transform(train_data['url_length_category'])
test_data['url_length_category'] = le.transform(test_data['url_length_category'])

# Use a RandomForestClassifier technique
# Explanation: RandomForestClassifier is a robust and versatile classifier that works well on multiclass classification problems. It can handle high dimensional data and its feature importance can give us good insight.
clf = RandomForestClassifier(n_estimators=100, random_state=42)

# Prepare the datasets for the model
X_train = train_data.drop('relevance', axis=1)
y_train = train_data['relevance']
X_test = test_data.drop('relevance', axis=1)
y_test = test_data['relevance']

# Fit the model
clf.fit(X_train, y_train)

# Report evaluation based on only test dataset
# Calculate the model accuracy
y_pred = clf.predict(X_test)
Accuracy = accuracy_score(y_test, y_pred)

# Calculate the model log loss
y_pred_proba = clf.predict_proba(X_test)
Log_loss = log_loss(y_test, y_pred_proba)

# Print the accuracy result
print(f"Accuracy:{Accuracy}")

# Print the log loss result
print(f"Log_loss:{Log_loss}")