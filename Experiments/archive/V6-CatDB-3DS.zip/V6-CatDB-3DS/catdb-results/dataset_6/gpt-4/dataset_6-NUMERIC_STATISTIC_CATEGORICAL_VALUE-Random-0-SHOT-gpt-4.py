# Import all required packages

import pandas as pd
import numpy as np
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss

# Load the training and test datasets
train_data = pd.read_csv("data/dataset_6/dataset_6_train.csv")
test_data = pd.read_csv("data/dataset_6/dataset_6_test.csv")

# Drop columns with unique values
for col in train_data.columns:
    if len(train_data[col].unique()) == 1:
        train_data.drop(col,inplace=True,axis=1)
        test_data.drop(col,inplace=True,axis=1)

# Drop columns with high correlation
corr_matrix = train_data.corr().abs()
upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
to_drop = [column for column in upper.columns if any(upper[column] > 0.95)]
train_data.drop(to_drop, axis=1, inplace=True)
test_data.drop(to_drop, axis=1, inplace=True)

# Define target and features
target = 'relevance'
features = [col for col in train_data.columns if col != target]

# Prepare data for training
X_train = train_data[features]
y_train = train_data[target]
X_test = test_data[features]
y_test = test_data[target]

# Use a RandomForestClassifier technique
clf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)

# Use 10-folds cross-validation for model construction
skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
for train_index, test_index in skf.split(X_train, y_train):
    X_train_fold, X_test_fold = X_train.iloc[train_index], X_train.iloc[test_index]
    y_train_fold, y_test_fold = y_train.iloc[train_index], y_train.iloc[test_index]
    clf.fit(X_train_fold, y_train_fold)

# Predict on test data
y_pred = clf.predict(X_test)
y_pred_proba = clf.predict_proba(X_test)

# Calculate accuracy and log loss
Accuracy = accuracy_score(y_test, y_pred)
Log_loss = log_loss(y_test, y_pred_proba)

# Print the accuracy and log loss
print(f"Accuracy: {Accuracy}")
print(f"Log loss: {Log_loss}")