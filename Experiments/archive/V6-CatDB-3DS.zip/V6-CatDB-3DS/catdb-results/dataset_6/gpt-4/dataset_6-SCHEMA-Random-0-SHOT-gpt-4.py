# ```python
# Import all required packages
import pandas as pd
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, log_loss
# ```end

# ```python
# Load the training and test datasets
train_data = pd.read_csv("data/dataset_6/dataset_6_train.csv")
test_data = pd.read_csv("data/dataset_6/dataset_6_test.csv")
# ```end

# ```python
# Remove low ration, static, and unique columns by getting statistic values
train_data = train_data.loc[:, train_data.apply(pd.Series.nunique) != 1]
# ```end

# ```python
# Add new columns
# Feature name and description: URL_Length_Ratio
# Usefulness: This feature can provide information about the complexity of the URL, which can be a useful feature for predicting 'relevance'.
train_data['URL_Length_Ratio'] = train_data['Length_of_URL'] / train_data['Length_of_URL'].max()
test_data['URL_Length_Ratio'] = test_data['Length_of_URL'] / test_data['Length_of_URL'].max()
# ```end

# ```python-dropping-columns
# Explanation why the column 'Length_of_URL' is dropped: The 'Length_of_URL' column is dropped because we have created a new feature 'URL_Length_Ratio' which normalizes this feature and provides better predictive power.
train_data.drop(columns=['Length_of_URL'], inplace=True)
test_data.drop(columns=['Length_of_URL'], inplace=True)
# ```end-dropping-columns

# ```python
# Use a RandomForestClassifier technique
# Explanation why the solution is selected: RandomForestClassifier is a robust and versatile classifier that can handle both categorical and numerical features. It also has features to prevent overfitting.
X_train = train_data.drop('relevance', axis=1)
y_train = train_data['relevance']
X_test = test_data.drop('relevance', axis=1)
y_test = test_data['relevance']

clf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
clf.fit(X_train, y_train)
# ```end

# ```python
# Report evaluation based on only test dataset
y_pred = clf.predict(X_test)
y_pred_proba = clf.predict_proba(X_test)

# Calculate the model accuracy
Accuracy = accuracy_score(y_test, y_pred)

# Calculate the model log loss
Log_loss = log_loss(y_test, y_pred_proba)

# Print the accuracy result
print(f"Accuracy:{Accuracy}")

# Print the log loss result
print(f"Log_loss:{Log_loss}")
# ```end