# Import all required packages
import pandas as pd
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import LabelEncoder

# Load the training and test datasets
train_data = pd.read_csv("data/credit-g/credit-g_train.csv")
test_data = pd.read_csv("data/credit-g/credit-g_test.csv")

# Fill missing values in 'other_payment_plans', 'own_telephone', and 'other_parties' with the most frequent value
for column in ['other_payment_plans', 'own_telephone', 'other_parties']:
    train_data[column].fillna(train_data[column].mode()[0], inplace=True)
    test_data[column].fillna(test_data[column].mode()[0], inplace=True)

# Feature: 'age_group' 
# Usefulness: This feature categorizes 'age' into different groups, which can provide more detailed information about the age distribution of the customers.
train_data['age_group'] = pd.cut(train_data['age'], bins=[0, 20, 30, 40, 50, 60, 70, 80], labels=False)
test_data['age_group'] = pd.cut(test_data['age'], bins=[0, 20, 30, 40, 50, 60, 70, 80], labels=False)

# Explanation why the column 'residence_since' is dropped: The 'residence_since' column is dropped because it has a low correlation with the target variable 'class'.
train_data.drop(columns=['residence_since'], inplace=True)
test_data.drop(columns=['residence_since'], inplace=True)

# Encode categorical features
le = LabelEncoder()
for column in train_data.columns:
    if train_data[column].dtype == 'object':
        train_data[column] = le.fit_transform(train_data[column])
        test_data[column] = le.transform(test_data[column])

# Use a RandomForestClassifier technique
# Explanation why the solution is selected: RandomForestClassifier is a robust and versatile classifier that can handle both numerical and categorical features. It also has a good performance on imbalanced datasets.
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(train_data.drop('class', axis=1), train_data['class'])

# Report evaluation based on only test dataset
predictions = clf.predict(test_data.drop('class', axis=1))
Accuracy = accuracy_score(test_data['class'], predictions)
F1_score = f1_score(test_data['class'], predictions)

print(f"Accuracy:{Accuracy}")   
print(f"F1_score:{F1_score}")