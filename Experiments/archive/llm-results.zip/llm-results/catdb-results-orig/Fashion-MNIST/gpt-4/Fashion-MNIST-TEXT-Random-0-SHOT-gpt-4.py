# python-import
# Import all required packages
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
# end-import

# python-load-dataset
# load train and test datasets (csv file formats) here
train = pd.read_csv("data/Fashion-MNIST/Fashion-MNIST_train.csv")
test = pd.read_csv("data/Fashion-MNIST/Fashion-MNIST_test.csv")
# end-load-dataset

# python-added-column
# Feature name: pixel_mean
# Usefulness: The mean value of all pixel values can provide information about the overall brightness of the image, which can be a useful feature for classifying the clothing item.
train['pixel_mean'] = train.mean(axis=1)
test['pixel_mean'] = test.mean(axis=1)
# end-added-column

# python-added-column
# Feature name: pixel_std
# Usefulness: The standard deviation of all pixel values can provide information about the contrast of the image, which can be a useful feature for classifying the clothing item.
train['pixel_std'] = train.std(axis=1)
test['pixel_std'] = test.std(axis=1)
# end-added-column

# python-dropping-columns
# Explanation why the column XX is dropped
# We will not drop any columns as all pixel values can potentially contribute to the classification of the clothing item.
# end-dropping-columns

# python-training-technique
# Use a multiclass classification technique
# Explanation why the solution is selected
# RandomForestClassifier is a popular and powerful ensemble method that can handle multiclass classification problems. It is also robust to overfitting.

# Separating features and target
X_train = train.drop('class', axis=1)
y_train = train['class']
X_test = test.drop('class', axis=1)
y_test = test['class']

# Standardizing the features
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

# Applying PCA
pca = PCA(n_components=0.95)
X_train = pca.fit_transform(X_train)
X_test = pca.transform(X_test)

# Training the RandomForestClassifier
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)
# end-training-technique

# python-evaluation
# Report evaluation based on only test dataset
y_pred = clf.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy*100:.2f}%")
# end-evaluation