# python-import
# Import all required packages
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
# end-import

# python-load-dataset
# load train and test datasets (csv file formats) here
train_df = pd.read_csv("data/car/car_train.csv")
test_df = pd.read_csv("data/car/car_test.csv")
# end-load-dataset

# python-added-column
# Feature name and description: doors_per_person
# Usefulness: This feature provides information about the ratio of doors to persons, which could be useful in determining the class of a car. 
train_df['doors_per_person'] = train_df['doors'] / train_df['persons']
test_df['doors_per_person'] = test_df['doors'] / test_df['persons']
# end-added-column

# python-dropping-columns
# Explanation: The columns 'buying', 'maint', 'lug_boot' are dropped because they are natural language text and could introduce noise in the model.
train_df.drop(columns=['buying', 'maint', 'lug_boot'], inplace=True)
test_df.drop(columns=['buying', 'maint', 'lug_boot'], inplace=True)
# end-dropping-columns

# python-other
# Explanation: Label encoding is required to convert categorical variables into numerical ones for the model to process.
le = LabelEncoder()
for col in ['persons', 'doors', 'safety', 'class']:
    train_df[col] = le.fit_transform(train_df[col])
    test_df[col] = le.transform(test_df[col])
# end-other

# python-training-technique
# Use a multiclass classification technique
# Explanation: Random Forest is a versatile and robust algorithm that can handle both continuous and categorical variables. It also works well with large datasets and can handle overfitting.
X_train = train_df.drop('class', axis=1)
y_train = train_df['class']
X_test = test_df.drop('class', axis=1)
y_test = test_df['class']

clf = RandomForestClassifier(n_estimators=100, random_state=0)
clf.fit(X_train, y_train)
# end-training-technique

# python-evaluation
# Report evaluation based on only test dataset
y_pred = clf.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy*100:.2f}%")
# end-evaluation