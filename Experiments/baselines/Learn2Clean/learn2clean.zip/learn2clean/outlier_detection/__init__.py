from .outlier_detector import Outlier_detector
__all__ = ['Outlier_detector', ]
